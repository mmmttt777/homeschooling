# Hearth & Home — Orthodox Homeschool Companion

## Deploy to Netlify (3 steps)

### Option A: Drag & Drop (easiest — no Git needed)

1. On your computer, open a terminal in this folder and run:
   ```
   npm install
   npm run build
   ```
   This creates a `dist/` folder.

2. Go to **app.netlify.com** → your site → **Deploys** tab

3. Drag the entire `dist/` folder onto the deploy drop zone.

Done! Your app is live.

---

### Option B: Connect GitHub (auto-deploys on every change)

1. Push this folder to a GitHub repository.

2. In Netlify: **Add new site** → **Import an existing project** → choose your repo.

3. Set build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`

4. Click **Deploy site**. Done!

---

## Local development

```bash
npm install
npm run dev
```

Opens at http://localhost:5173

---

## What's in this app

- 36-week Orthodox homeschool planner
- 11 subjects × 36 lessons for ages 6–10
- 11 subjects × 9–12 lessons for ages 2–5 (Little Learners)
- 12 Orthodox saints (one per month)
- Family reading, podcast & video library
- Child profiles with progress tracking
- Resumes where each child left off on login
