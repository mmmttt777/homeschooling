import { useState, useEffect, useMemo } from "react";
import { ChevronRight, ChevronLeft, CheckCircle2, Circle, Play,
  X, Edit3, Trash2, ExternalLink, BookMarked, Plus, Clock, Star } from "lucide-react";

const FONT = `@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Nunito:wght@400;600;700;800&family=Caveat:wght@600;700&display=swap');`;
const P = {
  cream:"#FAF6EE",parch:"#F0E6D0",ink:"#1C1209",gold:"#B8963E",
  byz:"#702963",forest:"#2D5A27",navy:"#1B3A5C",rose:"#8B3A52",
  sage:"#4A7C59",sky:"#2E6B8A",terra:"#8B4513",ochre:"#C4822A"
};

const SAINTS = [
{m:"January",n:"St Basil the Great",f:"1 January",
 life:"Basil was born ~330 AD in Caesarea into a family of saints. After studying in Athens alongside St Gregory of Nazianzus, he gave away his fortune, founded one of history's first hospitals, and became Archbishop of Caesarea. He stood alone against emperors and bishops promoting Arianism (the denial of Christ's full divinity). He wrote the Divine Liturgy still celebrated on major feasts. He died 1 January 379 AD, exhausted by fasting and ceaseless labour for the poor.",
 lesson:"Education must lead to service. Basil was the most learned man of his age — yet used every gift to help the sick and poor. This week: identify one person outside your family you can help. Write a brief plan. Pray the Prayer of St Basil each morning.",
 prayer:"O Lord our God, teach us to pass this day without sin. Preserve us from all temptation and deliver us from all evil. Amen.",
 vid:"St Basil the Great for children Orthodox",res:"https://www.oca.org/saints/lives/saint-basil-the-great"},
{m:"February",n:"St Symeon the God-Receiver",f:"3 February",
 life:"Symeon was an elderly righteous priest promised by the Holy Spirit that he would not die until he had seen the Lord's Christ. When Mary and Joseph brought the infant Jesus to the Temple forty days after His birth, Symeon took Him in his arms and spoke the words now sung at every Orthodox Vespers: Lord, now lettest Thou Thy servant depart in peace, for mine eyes have seen Thy salvation. He had waited his entire long life for one moment — and was found ready.",
 lesson:"Symeon waited his whole life for one moment — and was ready when it came. Memorise the Nunc Dimittis (Luke 2:29-32). Practise patient waiting for one thing you want, with trust and without complaint.",
 prayer:"Lord, now lettest Thou Thy servant depart in peace according to Thy word; for mine eyes have seen Thy salvation.",
 vid:"Presentation of Christ in the Temple Orthodox feast",res:"https://www.oca.org/saints/lives/saint-symeon-the-god-receiver"},
{m:"March",n:"St Mary of Egypt",f:"5th Sunday of Great Lent",
 life:"Mary left home at twelve and lived in deep sin in Alexandria for seventeen years. At thirty, she tried to enter the Church of the Holy Sepulchre and was stopped by an invisible force three times. She fell weeping before an icon of the Theotokos and received forgiveness. A voice sent her to the desert beyond the Jordan, where she lived alone for 47 years in prayer and repentance. The monk Zosimas found her — she walked on water to receive Holy Communion from him. The following year he found her body with a message scratched in the sand: Bury the body of the humble Mary.",
 lesson:"No sin is too great for God's mercy. The greatest sinners can become the greatest saints. This week: make a sincere confession of something you have done wrong, to God and to a parent. Accept forgiveness completely.",
 prayer:"O Holy Mother Mary, pray for us sinners who flee to thee with repentant hearts.",
 vid:"St Mary of Egypt story for children Orthodox",res:"https://www.oca.org/saints/lives/saint-mary-of-egypt"},
{m:"April",n:"St George the Great Martyr",f:"23 April",
 life:"George was a senior Roman army officer under Emperor Diocletian. When Diocletian issued his great persecution of Christians in 303 AD, George publicly declared his faith and refused to sacrifice to idols. He endured terrible tortures over seven days — yet each morning was found whole and praising God. He was beheaded 23 April 303 AD. The dragon legend that developed is an allegory: the dragon is evil, the princess is the Church, and George — the Christian soldier — defeats evil through faith in Christ, not worldly power.",
 lesson:"George chose Christ over the Emperor when the two came into conflict. Name one area where you are tempted to compromise your faith. What would St George do? What will you do?",
 prayer:"O holy Great Martyr George, intercede for us before God.",
 vid:"St George the Great Martyr for children Orthodox",res:"https://www.oca.org/saints/lives/saint-george-the-great-martyr"},
{m:"May",n:"Ss Cyril & Methodius, Equals-to-the-Apostles",f:"11 May",
 life:"Cyril and his brother Methodius were Greek brothers from Thessalonica. In 863 AD they were sent to bring Christianity to the Slavic peoples of Moravia. The Slavs had no written language, so Cyril invented one — the Glagolitic alphabet, ancestor of Cyrillic. He translated the entire Bible and the Divine Liturgy into Slavic so people could worship God in their own tongue. Their work spread Christianity to Russia, Serbia, Bulgaria, Romania and beyond. They are titled Equal-to-the-Apostles because their missionary work rivalled the original Twelve in scope.",
 lesson:"Cyril invented an entire alphabet as an act of love so people could know God in their own language. This week: look up the Cyrillic alphabet. Write three Greek words in Cyrillic. How many modern nations use St Cyril's alphabet?",
 prayer:"O holy Equals-to-the-Apostles Cyril and Methodius, enlighteners of the Slavic peoples, pray for us.",
 vid:"Ss Cyril and Methodius story for children",res:"https://www.oca.org/saints/lives/saint-cyril-teacher-of-the-slavs"},
{m:"June",n:"St John the Baptist, Forerunner",f:"24 June (Nativity)",
 life:"John was born six months before Jesus to Elizabeth and Zechariah, miraculously — Elizabeth was barren and both were old. He grew up in the desert eating locusts and wild honey, wearing camel hair. He preached at the Jordan calling Israel to repent. When Jesus came to be baptised, John said: I need to be baptised by You — yet he obeyed. At that moment the Holy Trinity was revealed: the Son in the water, the Spirit as a dove, the Father speaking from heaven. John was later imprisoned and beheaded at the request of Herod's stepdaughter Salome.",
 lesson:"John prepared the way for Jesus with his entire life. Choose one area where you need to clear something out to make room for something better. How could you simplify your life the way John simplified his?",
 prayer:"O holy Forerunner and Baptist of the Lord, pray for us sinners.",
 vid:"St John the Baptist Orthodox for children",res:"https://www.oca.org/saints/lives/the-nativity-of-the-holy-forerunner"},
{m:"July",n:"Ss Peter & Paul, Chief Apostles",f:"29 June",
 life:"Peter was a fisherman — impulsive, bold, beloved. After his triple denial, Jesus restored him with three questions: Do you love Me? He became the first leader of the Jerusalem Church. Paul was a Pharisee who persecuted Christians until the risen Christ appeared to him on the road to Damascus. He became Christianity's greatest missionary, planting churches across the Roman Empire. Both were martyred in Rome under Nero ~67 AD: Paul beheaded, Peter crucified upside down at his own request.",
 lesson:"Peter and Paul were utterly different — fisherman and scholar — yet God used both powerfully. Write one way you are like Peter (bold but sometimes wrong) and one way you are like Paul (gifted but needing redirection by God).",
 prayer:"O holy and glorious Apostles Peter and Paul, pray to God for us.",
 vid:"Holy Apostles Peter and Paul Orthodox for children",res:"https://www.oca.org/saints/lives/the-holy-glorious-and-all-praised-leaders-of-the-apostles-peter-and-paul"},
{m:"August",n:"Dormition of the Theotokos",f:"15 August",
 life:"The Orthodox Church celebrates the Dormition (Falling Asleep) of the Theotokos on 15 August — the greatest of Mary's feasts. According to holy Tradition, the Apostles were miraculously gathered from across the world to be with her at her death. She died peacefully. When the Apostle Thomas arrived three days after burial and the tomb was opened, her body was already gone — taken up by her Son. The Dormition is called the Pascha of Summer because it proclaims death defeated through union with Christ.",
 lesson:"Mary's entire life was one yes to God. This week: learn the Theotokion — More honourable than the Cherubim... Memorise and sing it each evening this week.",
 prayer:"Theotokos and Virgin, rejoice, O Mary full of grace, the Lord is with thee. Blessed art thou among women, and blessed is the Fruit of thy womb.",
 vid:"Dormition of the Theotokos Great Feast Orthodox explained",res:"https://www.oca.org/feasts-and-saints/lives/the-dormition-of-our-most-holy-lady-the-theotokos"},
{m:"September",n:"St John Chrysostom, Golden Mouth",f:"13 November",
 life:"John Chrysostom (Golden Mouth) was born in Antioch ~347 AD. As Archbishop of Constantinople he sold the bishop's palace and its treasures to build hospitals for the poor, and preached fearlessly against corruption at court. The Empress Eudoxia had him exiled twice. He died in exile in 407 AD. His last recorded words: Glory to God for all things. His Divine Liturgy is celebrated most Sundays of the year in every Orthodox church worldwide.",
 lesson:"Chrysostom said Glory to God for all things even in exile, even dying. Memorise those six words. Say them aloud whenever something goes wrong this week.",
 prayer:"O holy John Chrysostom, golden-mouthed preacher of repentance, pray for us.",
 vid:"St John Chrysostom for children Orthodox",res:"https://www.oca.org/saints/lives/the-repose-of-our-father-among-the-saints-john-the-archbishop-of-constantinople-chrysostom"},
{m:"October",n:"St Luke of Crimea, Surgeon & Archbishop",f:"11 June",
 life:"Valentin Voyno-Yasenetsky was born in 1877 in Russia and became one of Russia's finest surgeons. When the Bolsheviks began destroying the Church after 1917, he was ordained deacon, priest, then bishop — taking the name Luke. He was arrested eleven times, sent to Siberian labour camps — yet continued surgery and preaching wherever he was sent. In World War II he directed hospitals saving thousands of lives. He received the Stalin Prize for medicine while wearing a bishop's cross. He was glorified (canonised) in 1996.",
 lesson:"St Luke was a surgeon and a bishop — showing that faith and science are partners. This week: research one medical discovery and ask how it might be a gift from God to alleviate suffering.",
 prayer:"O holy hierarch and unmercenary physician Luke, heal our infirmities of soul and body.",
 vid:"Saint Luke of Crimea surgeon bishop saint story",res:"https://www.oca.org/saints/lives/saint-luke-archbishop-of-simferopol-and-crimea"},
{m:"November",n:"St Spyridon of Trimythous",f:"12 December",
 life:"Spyridon was a simple shepherd on Cyprus in the early 300s AD — uneducated by the world's standards and deeply holy. He became Bishop of Trimythous. At the First Council of Nicaea (325 AD), sophisticated philosophers argued against the full divinity of Christ. Spyridon silenced them: holding a clay tile he said In the name of the Father — fire shot upward. In the name of the Son — water poured down. In the name of the Holy Spirit — earth crumbled in his hand. Thus, one God in three Persons. The philosophers converted.",
 lesson:"The simplest believer who truly knows Christ knows the most important thing. This week: practise explaining the Holy Trinity to a younger child using only simple everyday words.",
 prayer:"O holy Spyridon, simple shepherd and great bishop, pray for us.",
 vid:"Saint Spyridon of Trimythous miracle story for children",res:"https://www.oca.org/saints/lives/saint-spyridon-bishop-of-trimythous-wonderworker"},
{m:"December",n:"St Nicholas the Wonderworker",f:"6 December",
 life:"Nicholas was born ~270 AD in Patara, Lycia to wealthy Christian parents who died in a plague, leaving him their fortune. He gave it all away secretly — including tossing bags of gold through the window of three sisters whose impoverished father was about to sell them into slavery. He became Bishop of Myra and attended the First Council of Nicaea (325 AD), where he is said to have struck the heretic Arius in defence of Christ's full divinity. He is the most beloved saint of the Orthodox world. His relics rest in Bari, Italy, where they still exude fragrant myrrh.",
 lesson:"Nicholas gave secretly and constantly. This week: plan one completely anonymous act of giving. Tell no one. Pray for the person you gave to. Ask St Nicholas to help you become a secret giver.",
 prayer:"O holy Nicholas, swift helper and wonderworker, pray to God for us.",
 vid:"Saint Nicholas the Wonderworker Orthodox children",res:"https://www.oca.org/saints/lives/nicholas-bishop-of-myra-in-lycia-the-wonderworker"},
];

const SUBJECTS = [
{id:"greek",name:"Greek Language",emoji:"🏛️",color:P.byz,tagline:"The language of the Gospel, the Fathers, and the Liturgy.",
lessons:[
{id:"g1",title:"The Greek Alphabet",age:"6–10",dur:"30 min",
 content:"The New Testament was written in Koinē Greek — the universal language of the Roman world. 24 letters: Α α (alpha), Β β (beta), Γ γ (gamma), Δ δ (delta), Ε ε (epsilon), Ζ ζ (zeta), Η η (eta), Θ θ (theta), Ι ι (iota), Κ κ (kappa), Λ λ (lambda), Μ μ (mu), Ν ν (nu), Ξ ξ (xi), Ο ο (omicron), Π π (pi), Ρ ρ (rho), Σ σ (sigma), Τ τ (tau), Υ υ (upsilon), Φ φ (phi), Χ χ (chi), Ψ ψ (psi), Ω ω (omega).",
 vsearch:"Greek alphabet song kids",res:"https://www.youtube.com/results?search_query=Greek+alphabet+song+kids",
 act:"Write the alphabet 3 times. Write your name in Greek. Write Χριστός (Christ) and Θεός (God). Every Orthodox icon uses these letters — IC XC = ΙΗΣΟΥΣ ΧΡΙΣΤΟΣ (Jesus Christ).",
 ff:"Every Orthodox icon has Greek letters. IC XC = Jesus Christ. MP ΘΥ = Μήτηρ Θεοῦ, Mother of God. Learning Greek unlocks a world of sacred meaning."},
{id:"g2",title:"Basic Greek Greetings",age:"5–10",dur:"30 min",
 content:"Hello: Γεια σου (yia sou). Good morning: Καλημέρα. Good evening: Καλησπέρα. How are you?: Τι κάνεις; I am fine: Καλά, ευχαριστώ. Thank you: Ευχαριστώ. Goodbye: Αντίο. Christ is Risen!: Χριστὸς Ἀνέστη! — Truly He is Risen!: Ἀληθῶς Ἀνέστη! The great Paschal greeting exchanged worldwide.",
 vsearch:"learn Greek greetings for beginners",res:"https://www.youtube.com/results?search_query=learn+Greek+greetings",
 act:"60-second Greek-only conversation with a family member — three days in a row. Learn to say and respond to Χριστὸς Ἀνέστη! enthusiastically.",
 ff:"When Orthodox Christians greet each other at Pascha they say Christ is Risen in Greek — connecting you to every Orthodox Christian who has celebrated Pascha for 2,000 years."},
{id:"g3",title:"Greek Numbers 1–20",age:"6–10",dur:"30 min",
 content:"Ένα (1), Δύο (2), Τρία (3), Τέσσερα (4), Πέντε (5), Έξι (6), Επτά (7), Οκτώ (8), Εννέα (9), Δέκα (10), Έντεκα (11), Δώδεκα (12). The number 12 is sacred: 12 Apostles, 12 Tribes, 12 Great Feasts of the Orthodox year.",
 vsearch:"Greek numbers 1 to 20 kids",res:"https://www.youtube.com/results?search_query=Greek+numbers+1+to+20",
 act:"Count 1–20 in Greek aloud. Find Greek number roots in English: pentagon (5), hexagon (6), octopus (8 feet), decade (10 years), Pentecost (50th day).",
 ff:"The Orthodox Church celebrates Twelve Great Feasts (Δώδεκα Δεσποτικές Εορτές) every year. Knowing Greek numbers lets you count through the feasts in their original language."},
{id:"g4",title:"Liturgical Greek: Kyrie Eleison",age:"6–10",dur:"30 min",
 content:"Κύριε ἐλέησον (Kyrie eleison) — Lord have mercy — is the most repeated phrase in Orthodox worship. Κύριε = Lord (Κύριος). Ἐλέησον = have mercy (ἔλεος = tender compassion, loyal love — richer than mere mercy). Sung dozens of times in every Divine Liturgy.",
 vsearch:"Kyrie Eleison Orthodox chant children",res:"https://www.youtube.com/results?search_query=Kyrie+eleison+Orthodox",
 act:"Learn to sing Kyrie eleison. Say it slowly 40 times (a traditional number). Learn also: Χριστέ ἐλέησον (Christ have mercy).",
 ff:"St John Chrysostom wrote: If you cannot fast or pray long prayers, say only Kyrie eleison — and this alone is sufficient when said from the heart."},
{id:"g5",title:"Greek Word Roots in English",age:"7–10",dur:"30 min",
 content:"Church words from Greek: Theo + logos = theology. Ortho + doxa = Orthodox (correct glory, right worship). Hagio + graphy = hagiography. Baptizo = to immerse. Eucharistia = thanksgiving. Liturgy = public work. Theotokos = God-bearer.",
 vsearch:"Greek roots English words for kids",res:"https://www.youtube.com/results?search_query=Greek+roots+English+words+kids",
 act:"Make a poster of Church words and their Greek roots. Include: Eucharist, Liturgy, Baptism, Theotokos, Icon, Patristic, Orthodox. Define each from its Greek roots.",
 ff:"Orthodox means correct glory or right worship — Ὀρθοδοξία. Heresy comes from hairesis (choice) — because heretics chose their own opinion over the holy Tradition handed down from the Apostles."},
{id:"g6",title:"The Lord's Prayer in Greek",age:"7–10",dur:"45 min",
 content:"Πάτερ ἡμῶν ὁ ἐν τοῖς οὐρανοῖς (Our Father who art in heaven). Ἁγιασθήτω τὸ ὄνομά σου (Hallowed be Thy name). Ἐλθέτω ἡ βασιλεία σου (Thy kingdom come). This prayer has been prayed in Greek since the Apostles — 2,000 years of unbroken continuity.",
 vsearch:"Orthodox Lord's Prayer Greek Pater Imon",res:"https://www.youtube.com/results?search_query=Orthodox+Lord%27s+Prayer+Greek",
 act:"Learn the first two lines in Greek. Write them in a prayer journal. Begin morning prayers with these lines in Greek every day this week.",
 ff:"Jesus prayed in Aramaic using Abba (Daddy) — showing God's intimate closeness. But the Apostles recorded His prayer in Greek so the whole Roman world could use it."},
{id:"g7",title:"Alexander the Great & the New Testament",age:"8–10",dur:"45 min",
 content:"Alexander the Great (356–323 BC) spread Greek language across the known world. By Christ's time, everyone from Greece to Egypt to Persia spoke Koinē Greek. This was God's providence: when the Apostles preached, they could reach the entire Roman Empire in one language. The Septuagint (LXX) — Greek OT (~250 BC) — was the Bible Jesus and the Apostles quoted.",
 vsearch:"Alexander the Great Simple History kids",res:"https://www.youtube.com/results?search_query=Alexander+the+Great+for+kids",
 act:"Trace Alexander's empire on a world map. Then trace Paul's missionary journeys (Acts 13–20). How much do they overlap? God used Alexander's roads and language for the Gospel 300 years later.",
 ff:"When the NT writers quote the OT they almost always quote the Septuagint Greek translation — not the Hebrew. This Greek translation prepared the entire Mediterranean world to receive the Gospel."},
{id:"g8",title:"Greek Philosophy: Shadows of the Truth",age:"7–10",dur:"45 min",
 content:"The ancient Greeks searched for truth — Socrates, Plato, Aristotle. Some of their insights echo Christian truth. St Justin Martyr wrote that wherever the Greeks found truth, it was because the Logos — who is Christ — is the source of all truth, present in the world even before the Incarnation.",
 vsearch:"Socrates Plato Aristotle for kids philosophy",res:"https://www.youtube.com/results?search_query=Socrates+Plato+Aristotle+kids",
 act:"Read John 1:1-14 — In the beginning was the Word (Logos). The Greeks searched for the Logos. Jesus IS the Logos. Write a paragraph explaining this connection in your own words.",
 ff:"St Clement of Alexandria wrote: Philosophy was given to the Greeks as a schoolmaster to bring them to Christ — just as the Law was given to the Jews. Both were preparations for the Gospel."},

{id:"g9",title:"Greek Colours & Everyday Objects",age:"5–9",dur:"30 min",
 content:"Colours in Greek: kokkino (red), ble (blue), prasino (green), kitrino (yellow), aspro (white), mavro (black), portokali (orange). Common objects: spiti (house), nero (water), psomi (bread), vivlio (book), trapezi (table). Written in Greek: κόκκινο, μπλε, πράσινο, κίτρινο, άσπρο, μαύρο, πορτοκαλί.",
 vsearch:"Greek colours and objects vocabulary for kids",res:"https://www.youtube.com/results?search_query=Greek+colours+vocabulary+kids",
 act:"Put sticky notes on 10 objects around your home with their Greek names. Include the colour of each object. Keep them up for a week. Remove and test.",
 ff:"The Greek word for orange (portokali) literally means 'from Portugal' — because the Portuguese introduced the orange fruit to Greece. Language often carries history inside it like this."},
{id:"g10",title:"Greek Family Words",age:"5–9",dur:"30 min",
 content:"Family in Greek: mama (mum), babas (dad), adelfos (brother), adelfi (sister), pappous (grandfather), yiayia (grandmother), theios (uncle), theia (aunt). My family: i ikogenia mou. Written: μαμά, μπαμπάς, αδελφός, αδελφή, παππούς, γιαγιά, θείος, θεία.",
 vsearch:"Greek family words for kids vocabulary",res:"https://www.youtube.com/results?search_query=Greek+family+words+kids",
 act:"Make a family tree and label everyone in Greek. Practise saying: O adelfos mou legetai... (My brother's name is...). Tell each family member their Greek title today.",
 ff:"The word 'theology' comes from Greek theos (God) + logos (word/reason). The Cappadocian Fathers who defined the Trinity in the 4th century were speaking and writing in Greek."},
{id:"g11",title:"Body Parts in Greek",age:"5–9",dur:"30 min",
 content:"Head: kefali. Eyes: matia. Ears: aftia. Nose: myti. Mouth: stoma. Hands: cheria. Feet: podia. Heart: kardia. Written: κεφάλι, μάτια, αυτιά, μύτη, στόμα, χέρια, πόδια, καρδιά. Remember: cardio comes from kardia. Cephalic comes from kefali. Greek body words are in medicine everywhere.",
 vsearch:"body parts in Greek for kids",res:"https://www.youtube.com/results?search_query=body+parts+in+Greek+kids",
 act:"Play Simon Says in Greek: O Simon legei — aggizte tin kefali! (Simon says — touch your head!) Go through all body parts with the family.",
 ff:"The medical prefixes 'cardio' (heart), 'cephalo' (head), 'osteo' (bone), 'neuro' (nerve), 'derma' (skin), 'gastro' (stomach) all come directly from Greek. A doctor speaks Greek all day without knowing it."},
{id:"g12",title:"Greek Food & Mealtimes",age:"5–9",dur:"30 min",
 content:"Food: psomi (bread), nero (water), gala (milk), elies (olives), psari (fish). Mealtimes: proino (breakfast), mesimeriano (lunch), deipno (dinner). Before eating: Kali orexi (good appetite). Blessing: Doxa si o Theos — glory to you, O God. Written: ψωμί, νερό, γάλα, ελιές, ψάρι.",
 vsearch:"Greek food words for kids",res:"https://www.youtube.com/results?search_query=Greek+food+words+kids",
 act:"Tonight at dinner, say the meal blessing in Greek: Doxa si o Theos (Δόξα σοι, ο Θεός). Name everything on the table in Greek as best you can.",
 ff:"The Greek word doxa (δόξα) means glory. The final words of the Divine Liturgy are Doxa si o Theos — Glory to Thee, O God. From the meal table to the altar, the same words connect ordinary life to worship."},
{id:"g13",title:"Counting to 100 in Greek",age:"6–10",dur:"30 min",
 content:"Teens: dekatria (13), dekatessera (14), dekapente (15). Tens: ikosi (20), trianta (30), saranta (40), peninta (50), exinta (60), ebdominta (70), ogdonta (80), eneninta (90), ekato (100). Notice: 40 days of Lent = saranta. Pentecost = 50 days = peninta.",
 vsearch:"counting to 100 in Greek for kids",res:"https://www.youtube.com/results?search_query=counting+100+in+Greek+kids",
 act:"Count to 100 in Greek by 10s. Then count the days of Great Lent (40) and the days to Pentecost (50). Practise counting objects around you in Greek.",
 ff:"When the Divine Liturgy refers to the 40 days of Christ's fast (Lent) or the 50 days to Pentecost, these are the very Greek words used in the New Testament. Counting in Greek is counting in the language of the Apostles."},
{id:"g14",title:"Days, Months & the Church Calendar in Greek",age:"6–10",dur:"30 min",
 content:"Days: Deftera (Monday), Triti (Tuesday), Tetarti (Wednesday — 4th day, fasting day), Pempti (Thursday), Paraskevi (Friday — fasting day), Savvato (Saturday — Sabbath), Kyriaki (Sunday — Lord's Day). Kyriaki (Κυριακή) comes from Kyrios — it literally means 'Day of the Lord.'",
 vsearch:"days of the week in Greek for kids",res:"https://www.youtube.com/results?search_query=days+of+the+week+Greek+kids",
 act:"Write out the weekly schedule in Greek — all 7 days. Mark Wednesday and Friday as fast days (Tetarti and Paraskevi). Mark Sunday as Kyriaki — Lord's Day. Say today's day in Greek each morning.",
 ff:"In Greek, Wednesday (Tetarti) simply means 'the Fourth.' But the Orthodox fasting tradition gives it sacred meaning — it is the day of Christ's betrayal. The calendar holds theology inside its bones."},
{id:"g15",title:"Simple Greek Sentences & Word Order",age:"7–10",dur:"30 min",
 content:"A basic Greek sentence: Subject + Verb + Object. O skyllos tro-i kreas (The dog eats meat). O (masculine the), I (feminine the), To (neuter the). Greek word order is more flexible than English because Greek uses endings (cases) to show grammatical relationships.",
 vsearch:"simple Greek sentences for beginners",res:"https://www.youtube.com/results?search_query=simple+Greek+sentences+for+beginners",
 act:"Build 5 simple Greek sentences using vocabulary you have already learned. Try: To psomi ine kalo (The bread is good). O pateras mou ine edo (My father is here).",
 ff:"Ancient Greek had 5 cases (nominative, genitive, dative, accusative, vocative) that showed each noun's role through its ending. This is why Homer could arrange words in any order for poetic effect and the meaning stayed clear."},
{id:"g16",title:"Greek Verbs: Present Tense",age:"7–10",dur:"45 min",
 content:"The verb 'to be' (eime): ego eime (I am), esy eisai (you are), aftos/afti/afto ine (he/she/it is), emeis imaste (we are), eseis iste (you all are), aftoi/aftes ine (they are). Written: είμαι, είσαι, είναι, είμαστε, είστε, είναι. The verb 'I eat' (tro-o): tro-o, tros, tro-i, trome, trote, trone.",
 vsearch:"Greek verb conjugation for beginners present tense",res:"https://www.youtube.com/results?search_query=Greek+verb+conjugation+beginners",
 act:"Conjugate both 'to be' (eime) and 'to eat' (tro-o) in full. Then create 6 sentences, one for each person: Ego eime... Esy eisai... etc.",
 ff:"The New Testament verb form estin (he/she/it is) appears hundreds of times. When Jesus says 'This IS my body' at the Last Supper, the Greek word used is the same ordinary present tense: estin."},
{id:"g17",title:"Greek in the New Testament: Key Verses",age:"7–10",dur:"45 min",
 content:"John 3:16 in Greek: Houtos gar igapisen o Theos ton kosmon (For God so loved the world). The word for love here is agape — unconditional, self-giving love — not eros (romantic) or philia (friendship). John 1:1: En archi in o Logos (In the beginning was the Word).",
 vsearch:"Greek New Testament key verses for children",res:"https://www.youtube.com/results?search_query=Greek+New+Testament+key+verses+kids",
 act:"Write out John 3:16 in both Greek and English. Highlight every word you already know. Look up the Greek words agape, logos, pneuma (spirit), pater (father), zoe (life).",
 ff:"The Greek word zoe (ζωή) means deep, full, eternal life. English uses it in zoology. Jesus says: I am the way, the truth, and the zoe (John 14:6). This is not biological life (bios) but divine, abundant life."},
{id:"g18",title:"Ancient Greek vs Modern Greek",age:"8–10",dur:"30 min",
 content:"Ancient Greek (Koine, used in the New Testament) and Modern Greek are related but different — like Latin and Italian. Key differences: pronunciation changed significantly; many vocabulary words are different; grammar is simplified in Modern Greek. Orthodox worship uses both: the Liturgy uses Koine Greek.",
 vsearch:"ancient Greek vs modern Greek differences",res:"https://www.youtube.com/results?search_query=ancient+Greek+vs+modern+Greek",
 act:"Compare John 1:1 in ancient (Koine) Greek and Modern Greek. Note: 'In the beginning was the Word' — En archi in o Logos (ancient). The differences are subtle but significant.",
 ff:"Modern Greek speakers can read the New Testament with some effort — like an English speaker reading Shakespeare. This continuity of 2,500 years in one language is remarkable."},
{id:"g19",title:"Greek Proverbs & Their Wisdom",age:"7–10",dur:"30 min",
 content:"Greek proverbs: Gnothi seauton (Know thyself) — inscribed at Delphi. Panta rhei (Everything flows) — Heraclitus on constant change. Hen oida hoti ouden oida (I know that I know nothing) — Socrates. These ideas were absorbed into Christian wisdom: humility, awareness of change, acceptance of limitations.",
 vsearch:"Greek proverbs and sayings for kids",res:"https://www.youtube.com/results?search_query=Greek+proverbs+sayings+kids",
 act:"Learn all three Greek proverbs above. Write them in Greek and English. Discuss: how does each connect to Christian spiritual wisdom? Can you find a Proverb or Psalm that echoes each one?",
 ff:"The phrase 'Know thyself' (Gnothi seauton) was inscribed in the forecourt of the Temple of Apollo at Delphi. St John Chrysostom quoted it in a sermon, arguing that true self-knowledge leads to knowledge of God."},
{id:"g20",title:"Greek Mythology & the Church Fathers",age:"8–10",dur:"45 min",
 content:"The Church Fathers engaged directly with Greek mythology and philosophy rather than ignoring it. St Clement of Alexandria wrote that the myths contained shadows of truth that the Greeks dimly perceived. The Logos of the Stoics prefigured the Logos of the Gospel. Greek mythology was a preparation for the Gospel.",
 vsearch:"Church Fathers and Greek mythology philosophy",res:"https://www.youtube.com/results?search_query=Church+Fathers+Greek+mythology+philosophy",
 act:"Choose one Greek myth. Identify the moral or truth it contains. Then find a corresponding Christian teaching, parable or saint's story that fulfils or completes it.",
 ff:"St Justin Martyr wrote: Whatever has been said aright by any man belongs to us Christians — for next to God, we worship and love the Logos (Reason) who is from the unborn and ineffable God."},
{id:"g21",title:"The Greek Orthodox Church Today",age:"7–10",dur:"30 min",
 content:"The Ecumenical Patriarchate of Constantinople (Istanbul, Turkey) — led by Patriarch Bartholomew — is the centre of honour of the entire Orthodox Church, holding the 'first among equals' position. The Greek Orthodox Archdiocese of America has over 450 parishes. There is a growing Greek Orthodox community in NZ.",
 vsearch:"Greek Orthodox Church today Ecumenical Patriarchate",res:"https://www.oca.org",
 act:"Find the location of your nearest Orthodox church. Research: which jurisdiction does it belong to? Is there a Greek Orthodox parish near you? Look up the Ecumenical Patriarchate at ec-patr.org.",
 ff:"The Ecumenical Patriarchate is located in Istanbul, Turkey (formerly Constantinople). The Patriarch's official building has just 3 staff members — yet he is the spiritual leader of approximately 300 million Orthodox Christians worldwide."},
{id:"g22",title:"Learning Greek Through Orthodox Hymns",age:"6–10",dur:"45 min",
 content:"The Trisagion: Hagios o Theos, Hagios Ischyros, Hagios Athanatos, eleison imas (Holy God, Holy Mighty, Holy Immortal, have mercy on us). Written: Ἅγιος ὁ Θεός, Ἅγιος Ἰσχυρός, Ἅγιος Ἀθάνατος, ἐλέησον ἡμᾶς. Hagios = holy. Ischyros = mighty. Athanatos = immortal (a = not, thanatos = death).",
 vsearch:"Trisagion Orthodox hymn Greek for children",res:"https://www.youtube.com/results?search_query=Trisagion+Orthodox+hymn+Greek",
 act:"Learn to say and sing the Trisagion in Greek. Break it into vocabulary: hagios (holy — hagiography?), ischyros (mighty), athanatos (immortal — euthanasia contains thanatos).",
 ff:"The Trisagion has been sung in the Orthodox Church since at least the 5th century. According to Tradition, it was revealed by angels to a child lifted up to heaven during an earthquake in Constantinople (447 AD)."},
{id:"g23",title:"Greek in Science & Medicine",age:"7–10",dur:"30 min",
 content:"Greek has given science most of its vocabulary. Biology (bios + logos — study of life). Astronomy (astron + nomos — law of stars). Physics (physis — nature). Chemistry: molecule, atom, electron, proton, neutron, nucleus are all Greek origin. Psychology (psyche + logos — study of the soul). Theology (theos + logos — study of God).",
 vsearch:"Greek roots in science vocabulary for kids",res:"https://www.youtube.com/results?search_query=Greek+roots+science+vocabulary+kids",
 act:"For each of the following sciences, identify 3 technical terms that come from Greek: biology, chemistry, astronomy, psychology, medicine. Total: 15 Greek-origin technical terms.",
 ff:"The word 'atom' comes from Greek atomos (indivisible, uncuttable). The ancient Greek philosopher Democritus proposed that all matter was made of indivisible particles — around 460 BC, about 2,300 years before physics proved him right."},
{id:"g24",title:"Greek Conversations: Shopping & Directions",age:"7–10",dur:"30 min",
 content:"Shopping: Poso kanei? (How much does it cost?) Poly akrivo! (Too expensive!). Directions: Pou ine i ekklisia? (Where is the church?) Pigainete eftheia (Go straight). Aristera (left). Dexia (right). Ekklisia (church — the assembly of believers called out of the world).",
 vsearch:"Greek shopping and directions for beginners",res:"https://www.youtube.com/results?search_query=Greek+shopping+directions+beginners",
 act:"Role play: one person asks directions to the church in Greek, the other gives directions using left, right, straight. Then do a shopping scene with prices.",
 ff:"The Greek word ekklesia (εκκλησία) means 'assembly' or 'those called out.' The New Testament uses it for the Church. The same word is used in Acts 19:32 for a riotous mob — context determines whether it is holy or not."},
{id:"g25",title:"Greek Liturgical Phrases",age:"8–10",dur:"30 min",
 content:"Key liturgical phrases: Doxa si o Theos (Glory to Thee, O God — St John Chrysostom's last words). Devte proskynisomen (Come, let us worship — opening of many Orthodox services). Sofia proshomen (Wisdom! Let us attend! — said before the Epistle reading). Written: Δόξα σοι ο Θεός, Δεῦτε προσκυνήσωμεν, Σοφίᾳ πρόσχωμεν.",
 vsearch:"Orthodox liturgical Greek phrases for children",res:"https://www.youtube.com/results?search_query=Orthodox+liturgical+Greek+phrases",
 act:"Memorise all three phrases above. Research what happens in the Liturgy when each phrase is spoken. Why does the deacon shout 'Wisdom! Let us attend!' before the reading?",
 ff:"'Wisdom! Let us attend!' (Sofia proshomen) is the deacon's call for complete silence before Scripture. It has been said in Orthodox churches for over 1,500 years. When you hear it, everyone in the building stops and turns their full attention to God's Word."},
{id:"g26",title:"The Sermon on the Mount in Greek",age:"8–10",dur:"45 min",
 content:"Key Greek terms in the Sermon on the Mount: makarioi (blessed, flourishing, deeply happy). Tapeinoi (humble, poor in spirit). Eirinopoioi (peacemakers — literally peace-makers). Phos (light). Teleiosis (perfection, completion, becoming what you were made to be).",
 vsearch:"Sermon on the Mount explained Greek words children",res:"https://www.youtube.com/results?search_query=Sermon+on+the+Mount+Greek+words",
 act:"Look up Matthew 5:3-12 in both English and a Greek interlinear Bible (free online). For each Beatitude, find the Greek word for the virtue or blessing. Write each Greek word with its meaning.",
 ff:"The Greek word makarios (blessed) used in the Beatitudes is the same word used in ancient Greek for the state of the gods — a condition of deep flourishing. Jesus used it for the poor in spirit, the mourning and the meek. This was shocking."},
{id:"g27",title:"Greek Architecture & the Church as Cosmos",age:"8–10",dur:"45 min",
 content:"Greek architectural terms in church design: narthex (porch, entrance), naos (the nave — literally 'ship'), hieron (the sanctuary, holy place), troulos (the dome, representing heaven), apsida (the apse, the rounded eastern end). Every part of the church has both a functional and a theological meaning.",
 vsearch:"Orthodox church architecture explained Greek terms children",res:"https://www.youtube.com/results?search_query=Orthodox+church+architecture+Greek",
 act:"Draw a floor plan of a Byzantine Orthodox church. Label each section in Greek. Note: the church faces east (towards the rising sun — symbolising the Resurrection). Why is the sanctuary elevated?",
 ff:"The nave (naos) literally means 'ship' in Greek. The early Church saw itself as a ship sailing through the stormy sea of the world toward the haven of the Kingdom of God. The bishop's chair (throne) at the back of the apse is called the kathedra — giving us the word 'cathedral.'"},
{id:"g28",title:"Conversational Greek Review & Role Play",age:"All",dur:"45 min",
 content:"Review of all conversational Greek learned this year: greetings, numbers, family, food, colours, directions, church vocabulary, liturgical phrases, the Lord's Prayer opening lines, Kyrie eleison, the Paschal greeting, the Trisagion. This is your vocabulary treasury — keep adding to it for life.",
 vsearch:"Greek conversation practice for beginners",res:"https://www.youtube.com/results?search_query=Greek+conversation+practice+beginners",
 act:"Full family Greek conversation: greet each other, discuss what day it is and what you are eating, describe colours and objects around you, say a meal blessing, and close with the Paschal greeting. How much can you do from memory?",
 ff:"The Greek phrase used to close the Divine Liturgy — Di efchon ton agion pateron imon, Kyrie Iisou Christe o Theos imon, eleison kai soson imas — means Through the prayers of our holy fathers, Lord Jesus Christ our God, have mercy on us and save us."},

{id:"g29",title:"Greek Vocabulary: Weather & Seasons",age:"6–9",dur:"30 min",
 content:"Seasons in Greek: anoixi (spring), kalokeri (summer), fthinoporo (autumn), cheimona (winter). Weather: ilios (sun), vrochi (rain), aeras (wind), chioni (snow), oraia (beautiful — of weather). Written: άνοιξη, καλοκαίρι, φθινόπωρο, χειμώνας, ήλιος, βροχή, αέρας, χιόνι, ωραία.",
 vsearch:"Greek weather and seasons vocabulary for kids",res:"https://www.youtube.com/results?search_query=Greek+weather+seasons+vocabulary+kids",
 act:"Write a simple Greek weather report for today: Simera einai (Today is)... Echei ilio (It has sun) / Echei vrochi (It has rain). Practise with a family member asking 'Ti kairo echei simera?' (What is the weather today?)",
 ff:"The four seasons in Greek connect to the Church calendar beautifully. Spring (anoixi — opening) corresponds to Pascha. Summer (kalokeri — good summer) to the Apostles Fast period. Autumn (fthinoporo — withering) to preparation. Winter (cheimona — winter, from cheimon meaning storm) to the Nativity Fast and Advent."},
{id:"g30",title:"Greek Adjectives & Describing Things",age:"7–10",dur:"30 min",
 content:"Adjectives in Greek change their ending to agree with the noun's gender. Masculine: o kalos (the good). Feminine: i kali. Neuter: to kalo. Common adjectives: kalos/kali/kalo (good), kakos/kaki/kako (bad), mikros/mikri/mikro (small), megalos/megali/megalo (big), agathos/agathi/agatho (good, virtuous — used in Church texts).",
 vsearch:"Greek adjectives for beginners",res:"https://www.youtube.com/results?search_query=Greek+adjectives+for+beginners",
 act:"Describe 5 objects around you using a Greek adjective. Try: To vivlio einai mikro (The book is small). O itheos einai megalos (God is great — a common Byzantine proclamation). Which adjective appears most in the Divine Liturgy?",
 ff:"The phrase O Theos agapos estin (God is love — 1 John 4:8) uses the Greek word agape for love. In Greek agathos (good) and agape (love) share the same root. Goodness and love are inseparable in the Greek Christian tradition."},
{id:"g31",title:"Greek Reading: The Nicene Creed",age:"7–10",dur:"45 min",
 content:"The Nicene Creed in Greek: Pistevo eis ena Theon (I believe in one God). Patera Pantokratora (Father Almighty). Piiten ouranou ke gis (Maker of heaven and earth). Oraton te panton ke aoraton (of all things visible and invisible). Each phrase is dense with theological meaning — and every word is Greek you can now begin to recognise.",
 vsearch:"Nicene Creed Greek Orthodox text pronunciation",res:"https://www.youtube.com/results?search_query=Nicene+Creed+Greek+Orthodox+pronunciation",
 act:"Obtain a copy of the Nicene Creed in Greek transliteration (pronunciation guide). Say the first three lines slowly, word by word. Identify every Greek word you already know from previous lessons.",
 ff:"The Nicene Creed was written in Greek by 318 bishops gathered at Nicaea in 325 AD. Every word was chosen with extraordinary care — some debates came down to a single letter (homoousios vs homoiousios — one iota of difference, yet it defined whether Christ is fully God or merely like God). That one letter changed history."},
{id:"g32",title:"Greek Through Music: Byzantine Chant",age:"6–10",dur:"30 min",
 content:"Byzantine chant (psaltiki) is the ancient sung prayer tradition of the Orthodox Church, dating to the early centuries. It uses 8 modes (echoi) rather than the Western major/minor system. The chant is monophonic (one melodic line, no harmony) and is meant to embody the text's meaning in sound. Learning even a few phrases of Byzantine chant connects you to 1,500 years of sung prayer.",
 vsearch:"Byzantine chant Orthodox music for children",res:"https://www.youtube.com/results?search_query=Byzantine+chant+Orthodox+music+for+children",
 act:"Listen to a recording of Byzantine chant (many free on YouTube). Close your eyes and listen for 5 minutes. What do you notice? Then try to sing Kyrie eleison in a simple Byzantine melody with your family.",
 ff:"Byzantine chant has been continuously sung in Orthodox churches for approximately 1,500 years without interruption. Unlike Western plainchant, Byzantine chant uses quarter-tones (intervals smaller than a semitone) that give it a distinctive sound unlike anything in Western music."},
{id:"g33",title:"Greek Place Names in Aotearoa & the Pacific",age:"7–10",dur:"30 min",
 content:"Greek language appears in surprising places. Antarctica (anti + arktos = opposite the bear constellation). Pacific Ocean (from Latin pacificus = peaceful — but Latin took pax from Greek eirene). New Zealand's botanical and zoological names are almost all Greek and Latin: Nothofagus (southern beech), Agathis australis (kauri). Greek gave science a universal naming language.",
 vsearch:"Greek scientific names plants animals for kids",res:"https://www.youtube.com/results?search_query=Greek+scientific+names+plants+animals+kids",
 act:"Look up the scientific (Latin/Greek) name of 5 NZ native species. Break each name into its Greek or Latin parts and define it. The kauri's name — Agathis australis — means southern good resin. What does your favourite NZ bird's scientific name mean?",
 ff:"Carl Linnaeus (1707-1778) established the binomial naming system for all living things using Latin and Greek — so that scientists of every language and nation could communicate precisely about the same organism. Today over 8.7 million species are named using this system."},
{id:"g34",title:"Greek Roots: -ology Words",age:"7–10",dur:"30 min",
 content:"The suffix -logia (logos = word, reason, study) + a subject = the study of that subject. Theology (God), biology (life), archaeology (ancient things), geology (earth), meteorology (weather), psychology (soul/mind), ornithology (birds — ornis in Greek), ichthyology (fish — ichthys in Greek). Note: ichthys (fish) was an early Christian symbol — its letters stand for Iesous Christos Theou Yios Soter (Jesus Christ Son of God Saviour).",
 vsearch:"ology words Greek roots for kids",res:"https://www.youtube.com/results?search_query=ology+words+Greek+roots+for+kids",
 act:"List 15 -ology words. For each, break it into roots and define it from the roots. Which one would you most like to study? The -ology words in Orthodox theology include: eschatology (study of last things), soteriology (study of salvation), ecclesiology (study of the Church).",
 ff:"The Greek word ichthys (ΙΧΘΥΣ — fish) was used as a secret sign by early Christians during periods of persecution. The five Greek letters form an acrostic: Iesous Christos Theou Yios Soter — Jesus Christ, God's Son, Saviour. When two strangers met, one would draw a curved line in the sand; if the other completed the fish, they knew each other to be Christian."},
{id:"g35",title:"Greek Conversations: At the Church",age:"7–10",dur:"30 min",
 content:"Church-related Greek conversation: Pame stin ekklisia (Let's go to the church). I Theia Leitourgia (The Divine Liturgy). O Papas (the Priest). O Diakonos (the Deacon). To Thysiastirio (the Altar). I Eikonostasi (the Iconostasis — icon screen). To Prosphoro (the offering bread). To Amnos (the Lamb — the central portion of the Prosphoro that becomes the Body of Christ at the Liturgy).",
 vsearch:"Greek church vocabulary Orthodox for beginners",res:"https://www.youtube.com/results?search_query=Greek+church+vocabulary+Orthodox+beginners",
 act:"Make a labelled diagram of an Orthodox church interior using Greek terms. Include: the narthex, nave, iconostasis, altar, ambo (pulpit), bishop's throne, candles, icons. Practise the names with a family member.",
 ff:"The word Liturgy comes from Greek leitourgia — leit (people) + ergon (work). The Divine Liturgy is literally the work of the people of God — not something done for us but something we participate in together. Every person present is a liturgist."},
{id:"g36",title:"Greek Year in Review: Our Language Journey",age:"All",dur:"1 hour",
 content:"Over this year we have learned: the Greek alphabet, basic greetings and conversation, numbers to 100, days and months, family words, food words, body parts, colours, liturgical phrases, key New Testament verses, Church terminology, Greek roots in English and science, and connections between Greek and Orthodox worship. This is a living language — keep using it.",
 vsearch:"Greek language review vocabulary practice",res:"https://www.youtube.com/results?search_query=Greek+language+review+vocabulary+practice",
 act:"Write a one-page letter in Greek (using transliteration if needed) to St John Chrysostom, the golden-mouthed preacher who wrote the Divine Liturgy. Tell him what you have learned in Greek this year and how it has helped you understand the Liturgy better.",
 ff:"When you attend the Divine Liturgy and hear Kyrie eleison, Doxa si o Theos, Pistevo, or Christos Anesti — you are now hearing those words in the language they were first spoken and prayed. The gap of 2,000 years closes every time you recognise a Greek word in worship."},
]},
{id:"maori",name:"Te Reo Māori & NZ History",emoji:"🥝",color:P.sage,tagline:"Aotearoa: land of the long white cloud.",
lessons:[
{id:"nz1",title:"Kia Ora! Te Reo Basics",age:"4–10",dur:"30 min",
 content:"Te reo Māori vowels: A (ah), E (eh), I (ee), O (oh), U (oo) — always exact, never varying. Greetings: Kia ora (hi/welcome), Tēnā koe (formal, 1 person), Tēnā kōrua (2 people), Tēnā koutou (3+), Mōrena (good morning), Pō mārie (good night), Haere rā (goodbye to those leaving).",
 vsearch:"learn te reo Maori greetings kids",res:"https://www.youtube.com/results?search_query=learn+te+reo+Maori+greetings",
 act:"Greet every family member only in te reo Māori all day. Add one new word each day this week.",
 ff:"Te reo Māori has only 15 sounds: 10 consonants (H,K,M,N,P,R,T,W,Wh,Ng) and 5 vowels. Once the vowels are mastered, the language is beautifully regular."},
{id:"nz2",title:"Whakapapa & Pepeha",age:"5–10",dur:"45 min",
 content:"Whakapapa is genealogy — knowing where you come from. A Māori pepeha: Ko [mountain] te maunga. Ko [river] te awa. Ko [waka] te waka. Ko [iwi] te iwi. Ko [name] tōku ingoa. Identity is rooted in land, people and ancestry.",
 vsearch:"whakapapa for kids NZ pepeha",res:"https://www.youtube.com/results?search_query=whakapapa+for+kids+NZ",
 act:"Write your own pepeha — even if not Māori: what mountain, river and place is meaningful to your family? Research where your ancestors came from.",
 ff:"Many Māori can recite their whakapapa back 30+ generations to the original ancestors on the waka that arrived from Hawaiki approximately 700 years ago."},
{id:"nz3",title:"Kupe & The Discovery of Aotearoa",age:"6–10",dur:"45 min",
 content:"About 1,000 years ago, the great navigator Kupe sailed from Hawaiki following a giant wheke (octopus). His wife Kuramārōtini saw a long white cloud and cried: He ao! He ao! He aotea! He aotearoa! Kupe returned with navigational instructions for others to follow.",
 vsearch:"Kupe discovery Aotearoa NZ story for kids",res:"https://www.youtube.com/results?search_query=Kupe+story+Aotearoa+kids",
 act:"Build a model waka hourua (double-hulled canoe) from cardboard, sticks and natural materials. Research how Polynesian navigators crossed thousands of kilometres of open ocean without instruments.",
 ff:"Māori navigators used star positions, ocean swells, cloud patterns, bird flight, wave refraction, and the colour and taste of the water. This knowledge was encoded in chants and passed from master to apprentice."},
{id:"nz4",title:"Te Tiriti o Waitangi (1840)",age:"8–10",dur:"1 hour",
 content:"On 6 February 1840 at Waitangi, 512 Māori chiefs and British representatives signed Te Tiriti. Article 1: governance (kawanatanga). Article 2: protection of Māori land and taonga. Article 3: equal rights. The English and Māori versions differ significantly — a difference debated for 180+ years.",
 vsearch:"Treaty Waitangi for kids NZ explained",res:"https://www.youtube.com/results?search_query=Treaty+Waitangi+for+kids",
 act:"Read both versions of the Treaty (they are short). List 3 differences. Discuss: if you were a Māori chief in 1840, what would concern you most?",
 ff:"The original Treaty document exists in the National Library in Wellington — water-damaged and rat-chewed, but intact. 6 February is Waitangi Day, NZ's national day."},
{id:"nz5",title:"Māori Myths: Maui & Rangi-Papa",age:"5–10",dur:"45 min",
 content:"Ranginui (sky father) and Papatūānuku (earth mother) were locked in eternal embrace. Their children pushed them apart to let in light. Maui fished up the North Island (Te Ika-a-Māui) using his grandmother's magic jawbone hook; he lassoed the sun to slow it; he stole fire from Mahuika.",
 vsearch:"Maui Maori legend NZ for kids animated",res:"https://www.youtube.com/results?search_query=Maui+Maori+legend+NZ+kids",
 act:"Draw one Maui story as a 4-panel comic with one caption per panel in English and one Māori word.",
 ff:"Te Punga-o-Māui (Māui's anchor) is also the Māori name for the Southern Cross constellation — which points south. The same stars that guided Māui's waka guide navigators today."},
{id:"nz6",title:"Te Reo Numbers, Colours & Daily Words",age:"All",dur:"30 min",
 content:"Numbers: tahi (1), rua (2), toru (3), whā (4), rima (5), ono (6), whitu (7), waru (8), iwa (9), tekau (10). Colours: whero (red), kōwhai (yellow), kākāriki (green), kikorangi (blue), mā (white), mangu (black). Phrases: He aha tō ingoa? (What is your name?) Ko [name] tōku ingoa.",
 vsearch:"te reo Maori numbers colours kids",res:"https://www.youtube.com/results?search_query=te+reo+Maori+numbers+colours",
 act:"Label 10 household items in Māori with sticky notes. Count in Māori during meals. By week's end remove the notes and test from memory.",
 ff:"After UNESCO declared te reo Māori endangered in the 1980s, the kōhanga reo (language nests) movement began. Today over 185,000 New Zealanders speak te reo to some degree."},
{id:"nz7",title:"NZ Land Wars & Their Legacy",age:"9–10",dur:"1 hour",
 content:"The NZ Land Wars (1845–1872) were fought in Northland, the Waikato, Taranaki, Bay of Plenty and Hawke's Bay. The Crown confiscated vast tracts of Māori land (raupatu) — a wound still being addressed through Treaty settlements today.",
 vsearch:"NZ Land Wars for kids overview",res:"https://www.youtube.com/results?search_query=NZ+Land+Wars+for+kids",
 act:"On a NZ map, mark the main conflict regions. Research one specific battle or leader. Connect land confiscations to present-day Treaty settlements.",
 ff:"In 2019, NZ Parliament officially named the NZ Wars as a required school curriculum topic for the first time."},
{id:"nz8",title:"NZ Native Wildlife & Conservation",age:"6–10",dur:"45 min",
 content:"NZ separated from Gondwana 85 million years ago. Without land mammals, birds filled every niche. Know: kiwi (nocturnal, flightless), kea (alpine parrot, extraordinarily intelligent), tūī (honey-eater), kererū (wood pigeon — gets drunk on fermented berries), morepork/ruru (native owl). Predator Free NZ 2050 aims to eliminate rats, stoats and possums.",
 vsearch:"NZ native birds for kids kiwi tui kea DOC",res:"https://www.youtube.com/results?search_query=NZ+native+birds+for+kids",
 act:"Go on a bird-spotting walk with binoculars. Record every species seen and heard. Use the Merlin Bird app (free) to identify songs.",
 ff:"The kakapo is the world's heaviest parrot (up to 4 kg), the only flightless parrot. In 1995 only 51 remained. By 2024 there are over 250 — an extraordinary conservation success."},

{id:"nz9",title:"Matariki: The Maori New Year",age:"5–10",dur:"45 min",
 content:"Matariki is the Maori New Year, celebrated when the Pleiades star cluster (Matariki) rises on the horizon before dawn in late June or early July. It is a time to remember those who have died since the last Matariki, to celebrate the present, and to plan for the future. Since 2022, Matariki has been a public holiday in New Zealand — the first public holiday based on Maori tradition.",
 vsearch:"Matariki Maori New Year for kids NZ",res:"https://www.youtube.com/results?search_query=Matariki+Maori+New+Year+for+kids",
 act:"Look up when Matariki rises this year. Go outside before dawn on that morning and try to spot the Pleiades (Seven Sisters). Research the nine stars of Matariki and what each one represents.",
 ff:"Each of the nine stars of Matariki is associated with a different aspect of life: Matariki (health and environment), Puaka (animals and birds), Tupuanuku (food grown in soil), Tupuarangi (food from above), Waititi (freshwater), Waipuna-a-Rangi (rain), Ururangi (wind), Hiwa-i-te-rangi (wishes and aspirations), and Pohutukawa (those who have died)."},
{id:"nz10",title:"Maori Proverbs: Ko wai au?",age:"7–10",dur:"30 min",
 content:"Whakatauaki (proverbs) encode Maori wisdom in a few words. Ko au te awa, ko te awa ko au (I am the river, the river is me — identity connected to environment). Ehara taku toa i te toa takitahi, engari he toa takitini (My strength is not mine alone, but the strength of many — teamwork). Ma te huruhuru ka rere ai te manu (By the feathers the bird flies — by knowledge we achieve).",
 vsearch:"Maori proverbs whakatauaki for kids",res:"https://www.youtube.com/results?search_query=Maori+proverbs+whakatauaki+for+kids",
 act:"Memorise one whakatauaki this week. Write it in te reo and in English. Draw an illustration. Discuss: how does it connect to your family's values?",
 ff:"The whakatauaki Ko au te awa, ko te awa ko au (I am the river, the river is me) was quoted in a landmark New Zealand court case in 2017 when the Whanganui River was granted the legal status of a person — the first river in the world to receive this status."},
{id:"nz11",title:"Carving, Weaving & Maori Arts",age:"7–10",dur:"1 hour",
 content:"Whakairo (carving): intricate designs carved in wood, stone and bone, encoding genealogy and sacred stories. Raranga (weaving): traditional flax (harakeke) weaving creating baskets, mats and cloaks. Ta moko (tattooing): unique facial and body designs telling your whakapapa. Each art form encodes identity, history and belief in visual form.",
 vsearch:"Maori arts carving weaving ta moko for kids NZ",res:"https://www.youtube.com/results?search_query=Maori+arts+carving+weaving+kids+NZ",
 act:"Try finger-weaving with wool or flax strips. Create a simple 2-colour geometric pattern. Research: what does the koru (spiralling fern frond) symbolise? What do you see it on today?",
 ff:"The koru (spiralling fern frond) — seen in ta moko, weaving and the Air NZ logo — symbolises new life, growth and awakening. The silver fern (ponga) is NZ's most recognised national symbol — all NZ sports teams use it."},
{id:"nz12",title:"Haka: The Power of Performance",age:"5–10",dur:"45 min",
 content:"Haka is a ceremonial dance and chant combining powerful movement, stomping, chest-beating, and chanting. It was used to welcome guests, challenge enemies, celebrate victories and mark important occasions. The Ka Mate haka (composed by chief Te Rauparaha around 1820) is the most famous and is performed by the All Blacks before rugby matches.",
 vsearch:"haka for kids NZ All Blacks Ka Mate",res:"https://www.youtube.com/results?search_query=haka+for+kids+NZ",
 act:"Watch a performance of Ka Mate. Learn the first verse: Ka mate! Ka mate! Ka ora! Ka ora! Ka mate! Ka mate! Ka ora! Ka ora! Tenei te tangata puhuruhuru nana nei i tiki mai whakawhiti te ra! Practise the movements.",
 ff:"The word 'haka' comes from ha (breath) and ka (to ignite). When properly performed, a haka is said to make the participants feel their own power and connection to their ancestors. The All Blacks' pre-match haka has been performed since 1888."},
{id:"nz13",title:"Maori Navigation & Traditional Knowledge",age:"7–10",dur:"45 min",
 content:"The Maori who settled Aotearoa came from Eastern Polynesia, navigating by the stars, ocean currents, birds and clouds. This navigational knowledge (matauranga moana) was encoded in chants memorised over generations. Tohunga kohara (navigation experts) could identify their latitude and longitude by reading the ocean and sky without instruments.",
 vsearch:"Maori navigation traditional knowledge waka hourua NZ",res:"https://www.youtube.com/results?search_query=Maori+navigation+traditional+knowledge+NZ",
 act:"Research the voyaging waka Hokule'a — a traditional Hawaiian double-hulled canoe that sailed the Pacific without modern instruments. Watch a video of traditional navigation being demonstrated.",
 ff:"The Polynesian Voyaging Society revived traditional navigation in the 1970s. In 1976, the voyaging canoe Hokule'a sailed from Hawaii to Tahiti (3,800 km) guided only by stars, waves and birds — the first such voyage in 600 years. The navigator, Mau Piailug from Micronesia, carried the knowledge in his memory."},
{id:"nz14",title:"The Maori Economy: Traditional & Modern",age:"8–10",dur:"30 min",
 content:"Traditional Maori economy was based on: fishing, growing kumara and other crops, hunting birds (including the now-extinct moa), gathering forest resources, and trade between tribes. The Maori economy today is estimated to be worth over $70 billion. Major Maori economic sectors: farming, fisheries, tourism, property and finance.",
 vsearch:"Maori economy traditional modern NZ",res:"https://www.youtube.com/results?search_query=Maori+economy+traditional+modern+NZ",
 act:"Research one major Maori business or enterprise in NZ. What does it do? Who owns it? How does it connect to Maori values of kaitiakitanga (guardianship) and whanaungatanga (relationships)?",
 ff:"The Treaty of Waitangi settlement process has returned over $2 billion in assets to Maori tribes since 1975. This includes land, forests, fisheries and financial compensation. The process is ongoing."},
{id:"nz15",title:"Famous Maori Leaders & Their Legacy",age:"8–10",dur:"45 min",
 content:"Important Maori leaders: Hone Heke (led the Flagstaff War 1845-1846, first of the Land Wars). Te Kooti Arikirangi (religious leader, founded Ringatu faith, military leader). Dame Whina Cooper (led the 1975 land march from Te Hapua to Wellington, 80 km, grandmother of the nation). Sir Apirana Ngata (first Maori to graduate from a NZ university, revived Maori arts).",
 vsearch:"famous Maori leaders NZ history for kids",res:"https://www.youtube.com/results?search_query=famous+Maori+leaders+NZ+history",
 act:"Choose one of these leaders. Research their life. Write a one-paragraph biography. What challenge did they face? What did they sacrifice? What did they achieve?",
 ff:"Dame Whina Cooper was 79 years old when she led the 1975 Maori Land March — walking 80 km from the top of the North Island to Parliament in Wellington to protest the loss of Maori land. She became a symbol of Maori land rights and was honoured on the NZ $10 note."},
{id:"nz16",title:"Kaitiakitanga: Guardianship of Creation",age:"6–10",dur:"30 min",
 content:"Kaitiakitanga is the Maori concept of guardianship — the responsibility humans have to care for the natural world. It comes from the belief that humans are not owners of the land, sea and sky, but kaitiaki (guardians). This view closely parallels the Orthodox Christian understanding of humans as stewards of God's creation (Genesis 2:15).",
 vsearch:"kaitiakitanga Maori guardianship environment NZ",res:"https://www.youtube.com/results?search_query=kaitiakitanga+Maori+guardianship+environment",
 act:"Compare kaitiakitanga with the Orthodox concept of stewardship. What do they have in common? How are they different? How might your family practise both this week?",
 ff:"The Resource Management Act 1991 (NZ) specifically includes kaitiakitanga as a principle that resource managers must recognise and provide for. This was the first time a traditional Maori concept was embedded in national environmental law."},
{id:"nz17",title:"Te Reo at Home: Building a Habit",age:"All",dur:"15 min daily",
 content:"Research shows that language learning requires consistent daily exposure over time. Even 15 minutes per day of intentional te reo practice is far more effective than one hour per week. Strategies: label household items in Maori, count in Maori at meals, use greetings exclusively in te reo, watch Maori Television, use the Kupu app.",
 vsearch:"te reo Maori daily practice for families NZ",res:"https://www.youtube.com/results?search_query=te+reo+Maori+daily+practice+families",
 act:"Design your family's 15-minute daily te reo routine. Include: one mealtime activity (counting, naming food), one greeting practice, one new word learned. Write the routine out and post it on the wall.",
 ff:"Children who grow up hearing two languages from birth develop stronger executive function (planning, focus, task-switching) compared to monolingual children. This advantage persists throughout life regardless of which languages are learned."},
{id:"nz18",title:"Papatūānuku: The Earth Mother",age:"5–10",dur:"30 min",
 content:"Papatūānuku (Earth Mother) is a central figure in Maori cosmology. She and Ranginui (Sky Father) were the first parents — the progenitors of all gods and all life. When Tane and his brothers pushed Rangi and Papa apart to let in light, the tears of their separation became the rain. Papatūānuku's body is the earth itself — mountains are her spine, rivers her blood, forests her hair.",
 vsearch:"Papatūānuku Earth Mother Maori story for kids",res:"https://www.youtube.com/results?search_query=Papatūānuku+Earth+Mother+Maori+story",
 act:"Draw Papatūānuku as a figure with the landscape features of Aotearoa as parts of her body. Label each feature in both Maori and English. Connect this to Orthodox creation theology: how does each tradition express human responsibility for the earth?",
 ff:"When Maori say 'Ko Papatūānuku te whenua' (Papatūānuku is the land), this is not merely metaphor — it is an expression of relationship. The land is not a resource to be used but a mother to be respected. This view has shaped NZ environmental law significantly."},
{id:"nz19",title:"NZ History Timeline: 1840 to Today",age:"9–10",dur:"1 hour",
 content:"Key NZ milestones after the Treaty: 1848-1860: mass European immigration. 1845-1872: NZ Land Wars. 1893: women's suffrage (first in world). 1907: NZ becomes a Dominion. 1915: Gallipoli, ANZAC Day. 1935-1938: welfare state established. 1947: NZ fully independent. 1975: Waitangi Tribunal. 1987: te reo Maori official language. 2004: Maori Television. 2022: Matariki public holiday.",
 vsearch:"NZ history timeline 1840 to today for kids",res:"https://www.youtube.com/results?search_query=NZ+history+timeline+1840+today+for+kids",
 act:"Make a detailed timeline of NZ history from 1840 to today on a long piece of paper. Use different colours for Maori history, European settlement, women's rights, international events. Add one small illustration per event.",
 ff:"New Zealand is considered one of the world's youngest nations to be settled by humans. The first Maori arrived approximately 700 years ago. This means NZ had no human beings living in it while Genghis Khan was conquering Asia, while Chartres Cathedral was being built, and while Rumi was writing poetry."},
{id:"nz20",title:"Whanaungatanga: The Power of Belonging",age:"5–10",dur:"30 min",
 content:"Whanaungatanga is the principle of family and community connectedness — the relationships and responsibilities that bind a group together. It encompasses: whanau (family), hapu (subtribe), iwi (tribe), and the wider community. In Maori culture, the individual exists in relationship — identity is collective, not individual. Ko tou rourou, ko toku rourou, ka ora ai te iwi (With your food basket and my food basket, the people will thrive).",
 vsearch:"whanaungatanga Maori family community for kids NZ",res:"https://www.youtube.com/results?search_query=whanaungatanga+Maori+community+kids",
 act:"Identify 5 different communities or groups you belong to (family, neighbourhood, church, sports team, etc.). For each, write one way you contribute and one way you receive. This is whanaungatanga in practice.",
 ff:"The Maori proverb Ehara taku toa i te toa takitahi, engari he toa takitini (My strength is not mine alone, but the strength of many) was quoted by Prime Minister Jacinda Ardern after the Christchurch mosque attacks in 2019, expressing the idea that NZ's response to tragedy was collective, not individual."},

{id:"nz21",title:"Te Reo: Basic Sentence Structures",age:"7–10",dur:"30 min",
 content:"Basic Maori sentence patterns. He [noun] a [name] (He/She is a [noun]): He kaiako ia (He/She is a teacher). Ko [name] toku [relation] ([Name] is my [relation]): Ko Hemi toku tungane (James is my brother). Kei hea a [name]? (Where is [name]?): Kei te kainga ia (He/She is at home). E [verb] ana ia (He/She is [doing something]): E mahi ana ia (He/She is working).",
 vsearch:"basic Maori sentence structures for learners",res:"https://www.youtube.com/results?search_query=basic+Maori+sentence+structures+learners",
 act:"Build 5 simple Maori sentences about your family using the patterns above. Practise until you can say them without looking at your notes.",
 ff:"Unlike English which uses word order (subject-verb-object) to convey meaning, Maori uses particles (little words like ko, kei, he, i, ka, e...ana) to show grammatical relationships. This means Maori sentences can be restructured more flexibly than English ones."},
{id:"nz22",title:"Hui: The Art of Meeting",age:"7–10",dur:"30 min",
 content:"A hui is a formal gathering or meeting following traditional Maori protocols. Key elements: Powhiri (welcome ceremony including karanga — call — and whaikorero — formal speeches), Hongi (pressing noses together, sharing the breath of life), Koha (gift or contribution), Kai (food, shared after the formal proceedings). A marae (meeting ground) is the setting for most important hui.",
 vsearch:"hui powhiri Maori meeting ceremony for kids NZ",res:"https://www.youtube.com/results?search_query=hui+powhiri+Maori+meeting+ceremony+kids",
 act:"Research the powhiri process step by step. Write a simple guide: what happens first? Who does what? What is each element for? If possible, visit a local marae or attend a powhiri.",
 ff:"The hongi (pressing of noses) literally shares breath between two people. Breath (hau) carries life force in Maori understanding. When you press noses, you are sharing your life with the other person. This is why hongi was traditionally reserved for important meetings — it establishes a deep connection."},
{id:"nz23",title:"Raranga: Flax Weaving",age:"7–10",dur:"1.5 hours",
 content:"Raranga (weaving) is a fundamental Maori art form using harakeke (New Zealand flax). The central shoot of the flax bush (rito) is never cut — it represents the heart of the family. Traditional Maori weavers observe protocols around harvesting, preparation and weaving. Products include kete (baskets), whāriki (mats), and korowai (cloaks decorated with feathers).",
 vsearch:"Maori flax weaving raranga for beginners kids NZ",res:"https://www.youtube.com/results?search_query=Maori+flax+weaving+raranga+beginners+kids",
 act:"Try simple flax weaving using strips of flax (or paper if flax is not available). Start with a simple checker-weave pattern. Research the protocol around cutting harakeke: why is the central shoot never cut?",
 ff:"The metaphor of the harakeke bush is central to Maori thinking about family. The central shoot (rito) is the child, surrounded by the parent shoots (matua), which are surrounded by the outer shoots (tūāhine). Each has a role. You cannot remove the rito without destroying the bush."},
{id:"nz24",title:"Tohu: Signs in Nature",age:"6–10",dur:"30 min",
 content:"Maori understood the natural world as full of tohu (signs) that gave information about weather, seasons, fish runs, and spiritual conditions. Kuaka (godwits) arriving signals the coming of summer. The cry of the morepork (ruru) at certain times can be an omen. The pohutukawa flowering signals Christmas. This attentiveness to natural signs is a form of ecological knowledge built up over 700 years of observation in Aotearoa.",
 vsearch:"Maori signs in nature tohu ecological knowledge NZ",res:"https://www.youtube.com/results?search_query=Maori+signs+nature+tohu+ecological+knowledge",
 act:"Keep a nature observation journal for 2 weeks. Record what you see and hear each day. Look for patterns: what appears before rain? What signals a change in season? Build your own local knowledge of natural signs.",
 ff:"Maori fishing calendars were based on natural signs rather than fixed calendar dates: fish ran when certain plants flowered; eels moved when the moon was in a particular phase. This knowledge, refined over generations, was often more accurate than a fixed calendar at predicting local conditions."},
{id:"nz25",title:"Te Ao Marama: The World of Light",age:"7–10",dur:"30 min",
 content:"In Maori cosmology, creation began in Te Kore (the void), moved through Te Po (the darkness), and emerged into Te Ao Marama (the world of light). This progression from void to darkness to light resonates with the creation account in Genesis 1, and with the Paschal service where the church moves from complete darkness to the blaze of the Paschal candle — from death to Resurrection.",
 vsearch:"Maori cosmology creation Te Kore Te Po Te Ao for kids",res:"https://www.youtube.com/results?search_query=Maori+cosmology+creation+for+kids",
 act:"Draw the progression: Te Kore (void — blank paper) to Te Po (darkness — black) to Te Ao Marama (world of light — colours). Then compare side by side with Genesis 1:1-4. What parallels do you notice?",
 ff:"Many Christian missionaries in the 19th century used the Maori creation narrative as a starting point for sharing the Gospel — pointing out the parallels between Te Ao Marama (the world of light) and the Christian God who is Light, in whom there is no darkness at all (1 John 1:5)."},
{id:"nz26",title:"The Tohunga: Priests, Experts & Specialists",age:"8–10",dur:"30 min",
 content:"A tohunga (expert, priest, specialist) was a person of highly specialised knowledge in traditional Maori society. Types of tohunga: tohunga whakairo (carving expert), tohunga ta moko (tattooing expert), tohunga kohara (navigation expert), tohunga makutu (spiritual practitioner). Tohunga were trained from childhood in whare wananga (houses of learning) — specialist institutions where sacred knowledge was transmitted.",
 vsearch:"tohunga Maori specialist priest expert NZ",res:"https://www.youtube.com/results?search_query=tohunga+Maori+specialist+expert+NZ",
 act:"Research the whare wananga (house of learning) — how was knowledge transmitted in traditional Maori society? Compare with the Orthodox tradition of spiritual formation under an elder (geronta/gerondissa). What similarities do you notice?",
 ff:"The Tohunga Suppression Act of 1907 made it illegal for Maori tohunga to practice their traditional healing and spiritual roles. This act was not repealed until 1962. It caused enormous damage to traditional Maori knowledge, much of which was lost permanently during this period."},
{id:"nz27",title:"NZ Geography: Mountains, Rivers & Regions",age:"6–10",dur:"30 min",
 content:"NZ key geography: North Island (Te Ika-a-Maui) and South Island (Te Waka-a-Maui) separated by Cook Strait. Key mountains: Aoraki/Mt Cook (3,724 m — highest peak, South Island), Ruapehu (2,797 m — active volcano, North Island), Tongariro. Key rivers: Waikato (longest, 425 km), Clutha (highest volume, South Island). Key regions: Northland, Auckland, Waikato, Bay of Plenty, Hawke's Bay, Wellington, Canterbury, Otago, Southland.",
 vsearch:"NZ geography mountains rivers regions for kids",res:"https://www.youtube.com/results?search_query=NZ+geography+mountains+rivers+regions+for+kids",
 act:"Draw a map of NZ from memory, labelling: the two main islands, Cook Strait, Aoraki/Mt Cook, Ruapehu, the Waikato River, Wellington, Christchurch, Auckland, Dunedin. Check against a real map and fill in what you missed.",
 ff:"Aoraki (Mt Cook) is considered the ancestor of the South Island Maori people (Ngai Tahu) — the mountain is their tipuna (ancestor). When the mountain was given its dual name Aoraki/Mt Cook in 1998, this was an acknowledgement of the mountain's identity as a living ancestor, not merely a geographical feature."},
{id:"nz28",title:"He Waka Eke Noa: We Are All In This Together",age:"5–10",dur:"30 min",
 content:"He waka eke noa (a canoe we are all in together without exception) is a powerful Maori proverb about collective responsibility and shared destiny. It expresses that all people in a community — whatever their differences — are in the same vessel and must work together. It is used in business, government and community settings to describe shared responsibility. NZ's emissions trading scheme was even named He Waka Eke Noa.",
 vsearch:"He waka eke noa Maori proverb meaning NZ",res:"https://www.youtube.com/results?search_query=He+waka+eke+noa+Maori+proverb+meaning",
 act:"Discuss as a family: what is the waka (canoe) that your family is all in together? What keeps you moving forward? What could cause it to sink? How does each person contribute to the voyage?",
 ff:"When the first waka arrived in Aotearoa from Hawaiki approximately 700 years ago, everyone on that canoe was entirely dependent on everyone else. The proverb He waka eke noa was born from the lived experience of ocean voyaging — a collective endeavour where individual failure could mean collective death."},
{id:"nz29",title:"Treaty Settlements & Reconciliation",age:"9–10",dur:"45 min",
 content:"Since 1975 the Waitangi Tribunal has investigated Crown breaches of the Treaty of Waitangi. When a breach is confirmed, negotiations lead to a Treaty settlement — the return of land, forests, waterways, or financial compensation to the affected iwi. By 2024, over $2 billion has been settled. Major settlements: Waikato-Tainui (1995), Ngai Tahu (1998), Tuhoe (2014), Whanganui River (2017). Reconciliation is ongoing work.",
 vsearch:"Treaty Waitangi settlements reconciliation NZ for kids",res:"https://www.youtube.com/results?search_query=Treaty+Waitangi+settlements+reconciliation+NZ",
 act:"Research one Treaty settlement in depth. Which iwi was involved? What was the breach? What was returned or compensated? How did the iwi use what they received? Is reconciliation ever complete?",
 ff:"The settlement between the Crown and Ngai Tahu (1998) included the return of 247,000 hectares of land, the right to commercially fish the sea around the South Island, and financial compensation. The settlement also formally acknowledged Crown wrongdoing — which many Ngai Tahu elders said was more important than the money."},
{id:"nz30",title:"Nga Morehu: The Survivors",age:"9–10",dur:"30 min",
 content:"Nga Morehu (the survivors, the remnant) refers to elderly Maori kaumatua and kuia (elders) who are the living repositories of traditional knowledge, language and tikanga (customs). As each elder dies, a library of knowledge goes with them — which is why the Maori say Ka hinga he totara i te wao nui (When a totara falls in the great forest — a great elder has died). Preserving this knowledge is urgent work.",
 vsearch:"Maori elders kaumatua traditional knowledge NZ",res:"https://www.youtube.com/results?search_query=Maori+elders+kaumatua+traditional+knowledge+NZ",
 act:"Interview an older person in your family or community. Ask them: what do they know that younger people do not? What skills or knowledge might be lost when they are gone? Record the conversation.",
 ff:"Every two weeks, on average, a language dies somewhere in the world — taking with it a unique way of seeing, categorising and relating to the world. Of approximately 7,000 languages spoken in the 20th century, fewer than half are expected to survive to 2100. Te reo Maori is one of the languages fighting to survive."},
{id:"nz31",title:"Manaakitanga in Practice",age:"5–10",dur:"30 min",
 content:"Manaakitanga (showing care, respect and generosity to others, especially guests) is one of the most important values in Maori culture. It is expressed through hospitality: offering food, giving your best, making visitors feel valued. This value connects directly to the Christian teaching of hospitality: Do not forget to show hospitality to strangers, for by so doing some people have shown hospitality to angels (Hebrews 13:2).",
 vsearch:"manaakitanga Maori hospitality value for kids NZ",res:"https://www.youtube.com/results?search_query=manaakitanga+Maori+hospitality+value+kids",
 act:"This week, practise one act of manaakitanga toward a visitor or someone outside your family: offer the best seat, the best food, your full attention. Notice how it feels to give your best.",
 ff:"In the Orthodox tradition, St John Chrysostom taught: The table of the poor is the altar of God. Both manaakitanga and Orthodox hospitality treat the guest as sacred — as someone through whom God himself might appear. The golden thread between these traditions is genuine."},
{id:"nz32",title:"Nga Taonga Tuku Iho: Treasures Passed Down",age:"7–10",dur:"30 min",
 content:"Nga taonga tuku iho (treasures passed down from ancestors) includes: physical taonga (pounamu/greenstone, carvings, woven cloaks), but also intangible taonga — te reo Maori, tikanga (customs), matauranga (knowledge), waiata (songs), kawa (ceremonial protocols). The Treaty of Waitangi guarantees the protection of Maori taonga — tangible and intangible. What taonga does your family pass down?",
 vsearch:"Maori taonga treasures cultural heritage NZ kids",res:"https://www.youtube.com/results?search_query=Maori+taonga+treasures+cultural+heritage+NZ",
 act:"Make a list of your family's taonga — both physical (objects, photographs, places) and intangible (stories, skills, values, traditions, faith). Which are most at risk of being lost? What will you do to preserve them?",
 ff:"Pounamu (greenstone/jade) found only on the West Coast of the South Island is one of the most taonga materials in Maori culture. It was used for tools, ornaments and weapons. The Ngai Tahu iwi have guardianship (kaitiakitanga) over pounamu as part of their 1998 Treaty settlement — the first time a natural resource was legally returned to its traditional guardians."},
{id:"nz33",title:"E Tu Whanau: Families Standing Strong",age:"5–10",dur:"30 min",
 content:"E Tu Whanau (families standing together) is a Maori-led programme promoting strong family values. Its five values: aroha (love and compassion), manaakitanga (caring for others), whanaungatanga (family connection), kia tika (doing what is right), and kia pono (being honest and truthful). These values deeply align with Christian family teaching — love, hospitality, belonging, righteousness and truthfulness.",
 vsearch:"E Tu Whanau Maori family values programme NZ",res:"https://www.youtube.com/results?search_query=E+Tu+Whanau+Maori+family+values+NZ",
 act:"Compare the five E Tu Whanau values with the nine Fruits of the Spirit (Galatians 5:22-23). How many direct parallels can you find? Create a chart showing both lists side by side with notes on where they connect.",
 ff:"E Tu Whanau began as a grassroots Maori community initiative in 2009 in response to family violence statistics in Maori communities. It has since become a nationally recognised programme. Its core insight is that the solution to family breakdown is found in traditional values, not imported programmes."},
{id:"nz34",title:"Ko Tahi Tatou: We Are One",age:"5–10",dur:"30 min",
 content:"Ko tahi tatou (we are one) expresses the Maori vision of unity across diversity. NZ's identity as a bicultural and increasingly multicultural nation is shaped by the Treaty partnership between Maori and the Crown. More than 200 languages are spoken in NZ today. The challenge — and the opportunity — is to be genuinely one people while honouring the distinct identity and taonga of each culture.",
 vsearch:"NZ biculturalism multiculturalism identity for kids",res:"https://www.youtube.com/results?search_query=NZ+biculturalism+multiculturalism+kids",
 act:"Research your own family's ethnic and cultural heritage. Where did each ancestor come from? What languages did they speak? What faith did they hold? How did they come to be in NZ? Make a map showing your family's origins.",
 ff:"At the 2018 NZ census, over 160 different languages were recorded as being spoken at home. The five most common: English, Maori, Samoan, Hindi, and Mandarin. NZ is one of the most linguistically diverse small nations on Earth — a living example of Ko tahi tatou, we are one."},
{id:"nz35",title:"Maori Land & the Mountain That Is a Person",age:"8–10",dur:"30 min",
 content:"In Maori law and cosmology, land is not property to be owned but an ancestor to be related to. The Whanganui River was granted legal personhood in 2017. Mount Taranaki was granted legal personhood in 2023. This means they have legal rights — they can sue and be sued, must be considered in decisions that affect them. This challenges Western legal concepts of property and personhood.",
 vsearch:"Whanganui River legal personhood Maori NZ",res:"https://www.youtube.com/results?search_query=Whanganui+River+legal+personhood+Maori+NZ",
 act:"Research the Whanganui River settlement. What does it mean for a river to be a legal person? Who speaks for the river in court? How is this connected to the Maori whakatauaki Ko au te awa, ko te awa ko au?",
 ff:"Bolivia, Ecuador and India have also granted legal rights to rivers and ecosystems. New Zealand's Whanganui settlement was the first in the world to grant a river the full status of a legal person — but the idea had been in Maori law for centuries before it entered Western legal systems."},
{id:"nz36",title:"Te Reo Year in Review: Our Language Journey",age:"All",dur:"45 min",
 content:"Over this year we have learned: vowels and pronunciation, greetings and pepeha, numbers and colours, daily words, whakapapa, Maori myths, NZ history from Kupe to today, key cultural values (manaakitanga, whanaungatanga, kaitiakitanga), proverbs, arts, the Treaty, Treaty settlements, and Maori cosmology. Te reo Maori is a taonga — cherish it and keep growing.",
 vsearch:"te reo Maori language review reflection year NZ",res:"https://www.youtube.com/results?search_query=te+reo+Maori+language+review+year",
 act:"Write a pepeha that includes everything you have learned about your identity this year. Recite it to your family in te reo. Then make a commitment: one thing you will do every week next year to keep growing in te reo.",
 ff:"He aha te mea nui o te ao? He tangata, he tangata, he tangata (What is the greatest thing in the world? It is people, it is people, it is people). This is perhaps the most famous Maori proverb. All the language, history, art and culture we have studied this year exists because of, for, and through people — people made in the image of God."},
]},
{id:"nature",name:"Survival & Nature Science",emoji:"🌿",color:P.forest,tagline:"God's world — learn to read it, live in it, care for it.",
lessons:[
{id:"n1",title:"The Five Senses in Creation",age:"4–7",dur:"30 min",
 content:"God gave us five senses to know His world. Sit outside in silence 2 minutes: list 5 things seen, 4 heard, 3 smelled, 2 felt, 1 safe to taste. Psalm 34:8 — Taste and see that the Lord is good. The Church Fathers called the natural world the Second Book of God alongside Scripture.",
 vsearch:"five senses song Free School kids",res:"https://www.youtube.com/results?search_query=five+senses+song+kids",
 act:"Blindfolded smell test: 6 jars with lemon, mint, cinnamon, soap, vinegar, soil. Identify each without looking. Then write one verse about something you observed with your senses, as the Psalmists did.",
 ff:"Psalm 19: The heavens declare the glory of God. The early Fathers called the natural world the Second Book of God — alongside Scripture. All creation speaks of God if we have eyes to see."},
{id:"n2",title:"Building a Shelter",age:"6–10",dur:"1.5 hrs",
 content:"Survival Rule of 3s: 3 minutes without air, 3 hours without shelter in severe weather, 3 days without water, 3 weeks without food. A lean-to uses a ridge pole between two trees with branches leaned at 45° and leaves packed thickly to shed rain.",
 vsearch:"how to build lean to shelter kids survival",res:"https://www.youtube.com/results?search_query=lean+to+shelter+kids+survival",
 act:"Build a lean-to in the back yard using sticks, natural materials or a tarp. Crawl inside. Would you stay dry in light rain? What would you improve?",
 ff:"The Desert Fathers built cells (small shelters) in the Egyptian wilderness and stayed in them for years in prayer. A cell can be shelter for the body and for the soul simultaneously."},
{id:"n3",title:"Clouds & Weather Reading",age:"5–9",dur:"30 min",
 content:"Cumulus (puffy white) = fine weather. Stratus (flat grey) = drizzle. Cumulonimbus (tall anvil tower) = thunderstorm. Cirrus (high wispy streaks) = weather change within 24 hours. Jesus rebuked the Pharisees: You know how to read the sky — why can you not read the signs of the times? (Matthew 16:2-3)",
 vsearch:"SciShow Kids types of clouds",res:"https://www.youtube.com/results?search_query=types+of+clouds+for+kids",
 act:"Cloud journal for 7 days: morning — draw the cloud type and predict the weather. Evening — record what actually happened. Accuracy rate?",
 ff:"A single small cumulus cloud weighs about 500 tonnes. It floats because its water droplets are so tiny that air resistance holds them up — even clouds obey the laws God built into creation."},
{id:"n4",title:"Edible & Poisonous Plants (NZ)",age:"7–10",dur:"1 hour",
 content:"RULE: Never eat any plant unless an adult confirms it is safe. Safe NZ wild edibles: puha (sow thistle), kawakawa (peppery leaves), watercress (clean running water only). DANGEROUS: tutu (all parts — can kill), hemlock, deadly nightshade, foxglove. When in doubt, leave it out.",
 vsearch:"wild edible plants beginners safety foraging NZ",res:"https://www.youtube.com/results?search_query=wild+edible+plants+beginners+NZ",
 act:"Walk with a parent. Identify 3 plants using iNaturalist (free app). Research: safe, edible, or avoid?",
 ff:"St John the Baptist ate locusts and wild honey in the desert. The Desert Fathers often ate wild plants and herbs. Knowing what is edible in the wild has been a holy skill across many traditions."},
{id:"n5",title:"Animal Tracking",age:"6–10",dur:"1 hour",
 content:"Animals leave evidence: footprints, scat (droppings), scratched bark, fur, nibbled vegetation, feathers. A hopping bird leaves two parallel prints; a walking bird leaves alternating singles. Possum prints have 5 long fingers on the back foot.",
 vsearch:"animal tracking for kids nature mentor",res:"https://www.youtube.com/results?search_query=animal+tracking+for+kids",
 act:"Sprinkle flour on a tray, leave bait (cat food) outside overnight. In the morning, photograph and identify the tracks. Which direction was the animal moving?",
 ff:"The Desert Fathers became so still in prayer that wild animals came to them without fear. St Gerasimos of the Jordan kept a tame lion. St Seraphim of Sarov fed a bear by hand from his woodland cell."},
{id:"n6",title:"Fire Safety & the Fire Triangle",age:"8–10 with adult",dur:"1.5 hrs",
 content:"Fire needs fuel, heat and oxygen — the fire triangle. Remove any one and the fire dies. Build a teepee: tinder (dry grass, cotton ball), kindling (pencil-thin twigs), fuel (thumb-thick sticks). Always: with an adult, on bare soil, with water nearby. Māori used hika ahi — rubbing hardwood in a groove of softer wood.",
 vsearch:"how to build campfire kids safety",res:"https://www.youtube.com/results?search_query=campfire+safety+for+kids",
 act:"With an adult: gather tinder, kindling and fuel. Build (don't light) a teepee. Practice: what would you remove from the fire triangle to extinguish each type of fire?",
 ff:"The Burning Bush of Exodus — which burned and was not consumed — is a central Orthodox image. The Theotokos is called the Burning Bush: she bore the fire of God without being consumed."},
{id:"n7",title:"Finding, Filtering & Purifying Water",age:"7–10",dur:"45 min",
 content:"Humans survive ~3 days without water. Even clear water can carry pathogens. Boiling (1 min at sea level, 3 min at altitude) kills all pathogens. Filtering removes particles but not bacteria — always filter AND boil.",
 vsearch:"how to purify water survival kids",res:"https://www.youtube.com/results?search_query=how+to+purify+water+survival",
 act:"Make a gravity filter: cut the bottom off a 2L bottle. Layer cotton/cloth, crushed charcoal, coarse sand, fine gravel. Pour muddy water through. Observe clarity. (Then boil before drinking.)",
 ff:"Jesus told the woman at the well: Whoever drinks the water I give them will never thirst again. The Fathers wrote that physical water is a sign of the living water of the Holy Spirit given in Baptism."},
{id:"n8",title:"The Night Sky & Navigation by Stars",age:"7–10",dur:"45 min",
 content:"Southern Cross (Te Punga) points south — extend the long axis 4.5× to find due south. Matariki (Pleiades) rising before dawn in late June signals Māori New Year. The Three Wise Men (Magi) followed a star — astronomer-priests who recognised an extraordinary sign. God spoke to them in the language they already knew.",
 vsearch:"find south Southern Cross navigation kids",res:"https://www.youtube.com/results?search_query=Southern+Cross+navigation+kids",
 act:"Clear night: locate the Southern Cross. Find south using the 4.5× rule. Identify the Milky Way (Te Ikaroa — the long fish).",
 ff:"Psalm 8: When I look at Thy heavens, the work of Thy fingers, the moon and the stars... The same stars that awed David still guide navigators today."},

{id:"n9",title:"The Water Cycle",age:"5–9",dur:"30 min",
 content:"Water moves in an endless cycle: evaporation (sun heats water, it rises as vapour), condensation (cools and forms clouds), precipitation (falls as rain, snow or hail), collection (in rivers, lakes, oceans, groundwater), then evaporation again. Transpiration: plants also release water vapour through their leaves — forests are rain-makers.",
 vsearch:"the water cycle for kids SciShow Kids",res:"https://www.youtube.com/results?search_query=water+cycle+for+kids",
 act:"In a ziplock bag: draw a sun, cloud, ocean and rain with a marker. Add 1/4 cup water and tape to a sunny window. Watch the water cycle happen inside the bag over a few hours.",
 ff:"All the water on Earth today was already here when the dinosaurs were alive. The water in your glass may once have flowed through the Nile, been drunk by a mammoth, or fallen as rain on Noah's ark."},
{id:"n10",title:"Photosynthesis: Plants as Solar Panels",age:"6–9",dur:"30 min",
 content:"Photosynthesis: carbon dioxide (from air) + water (from soil) + sunlight (energy) produces glucose (food for the plant) + oxygen (released into the air). Every breath you take depends on photosynthesis. Every meal you eat ultimately comes from a plant that captured sunlight.",
 vsearch:"photosynthesis for kids SciShow Kids",res:"https://www.youtube.com/results?search_query=photosynthesis+for+kids",
 act:"Place a healthy green leaf in a glass of water in strong sunlight. After an hour, look closely — tiny bubbles should appear on the leaf. These are oxygen bubbles from photosynthesis.",
 ff:"Aristotle believed for 2,000 years that plants got their food from soil. Jan Baptista van Helmont disproved this in 1648 by growing a willow tree in weighed soil — the tree gained 76 kg but the soil lost only 60 g."},
{id:"n11",title:"Insects: The Overlooked Majority",age:"5–9",dur:"45 min",
 content:"About 80% of all animal species are insects. There are approximately 10 quintillion individual insects alive at any moment. Insects have 3 body parts (head, thorax, abdomen), 6 legs, and usually 2 pairs of wings. They pollinate crops, decompose organic matter, feed birds and fish, and are the foundation of most food chains.",
 vsearch:"insects for kids SciShow Kids",res:"https://www.youtube.com/results?search_query=insects+for+kids",
 act:"Set up an insect observation journal. Each day for one week, draw one insect you observe. Identify it using iNaturalist (free app). Record: where it was, what it was doing, what it was eating.",
 ff:"If all insects on Earth disappeared, almost every ecosystem would collapse within a few decades. Birds, fish, reptiles, amphibians and small mammals — which feed on insects — would largely follow them into extinction."},
{id:"n12",title:"Rocks, Minerals & Soil Formation",age:"6–10",dur:"45 min",
 content:"Rocks form three ways: igneous (cooled from magma — basalt, granite), sedimentary (layered from compressed sediment — sandstone, limestone, coal), metamorphic (changed by heat or pressure — marble, slate). Soil forms when rocks break down over thousands of years, combined with decomposed organic matter.",
 vsearch:"types of rocks for kids igneous sedimentary metamorphic",res:"https://www.youtube.com/results?search_query=types+of+rocks+kids",
 act:"Start a rock collection. Find 5 different rocks. Hardness test: can a fingernail scratch it? A coin? A knife? Use a field guide or app to identify each one.",
 ff:"It takes about 500 years to form 2.5 cm of healthy topsoil. NZ loses an estimated 200 million tonnes of topsoil to erosion every year — mostly from deforested hill country."},
{id:"n13",title:"Fungi & Decomposers: Nature's Recyclers",age:"6–9",dur:"30 min",
 content:"Fungi are neither plants nor animals — they are their own kingdom. Mushrooms are just the fruiting body; the main organism is the mycelium, a vast network of threads underground. Fungi break down dead wood, leaves and animals into nutrients that plants can absorb. Without decomposers, the nutrients locked inside dead matter would be unavailable to living things.",
 vsearch:"fungi and decomposers for kids",res:"https://www.youtube.com/results?search_query=fungi+decomposers+for+kids",
 act:"Find a fallen log in a damp area. Look underneath for fungal threads (white or cream coloured filaments). Look for mushrooms nearby. How far has decomposition progressed?",
 ff:"The world's largest living organism is a honey fungus in Oregon, USA. Its underground mycelium covers approximately 8.9 km2 — about the size of 1,350 rugby fields — and is estimated to be 8,650 years old."},
{id:"n14",title:"Life Cycles: Butterfly, Frog & Plant",age:"5–8",dur:"45 min",
 content:"All living things have a life cycle. Butterfly: egg to caterpillar (larva) to chrysalis (pupa) to adult butterfly to eggs. Frog: egg (spawn) to tadpole to froglet to adult frog. Plant: seed to seedling to plant to flower to seed. Metamorphosis is a complete change of body form — one of nature's greatest miracles.",
 vsearch:"life cycles butterfly frog plant for kids",res:"https://www.youtube.com/results?search_query=life+cycles+butterfly+frog+plant+kids",
 act:"Find frog spawn near a creek or pond in spring. Observe in a jar for 2 weeks, feeding with algae. Release the froglets back into their habitat. Draw each stage of the life cycle.",
 ff:"A caterpillar inside its chrysalis does not slowly grow wings. It completely dissolves into a liquid protein soup and then reorganises into an entirely new creature. The butterfly shares DNA with the caterpillar but almost no physical structure."},
{id:"n15",title:"Weather Patterns & Climate in NZ",age:"6–10",dur:"30 min",
 content:"New Zealand has very changeable weather because of its location in the Roaring Forties (strong westerly winds), its mountainous spine (the Southern Alps create a rain shadow), and its exposure to both subtropical warmth from the north and Antarctic cold from the south. The west coast of the South Island receives over 6,000 mm of rain per year; Central Otago receives under 400 mm.",
 vsearch:"NZ weather and climate for kids",res:"https://www.youtube.com/results?search_query=NZ+weather+climate+for+kids",
 act:"Keep a daily weather record for 2 weeks: temperature, rainfall, wind direction, cloud type and description. Look for patterns. Which days were rainiest? What cloud type preceded rain?",
 ff:"NZ's weather is so unpredictable that the saying 'four seasons in one day' is genuinely true in many places. The Southern Alps can receive 10 metres of snow in winter while the east coast remains sunny and dry."},
{id:"n16",title:"Trees: The Lungs of Creation",age:"6–9",dur:"30 min",
 content:"Trees are the largest living organisms on land. A single large tree can absorb up to 22 kg of CO2 per year and release 100 kg of oxygen. Trees cool the air through transpiration, prevent soil erosion with their roots, provide habitat for thousands of species, and produce food. NZ's native trees include kauri, totara, rimu, kahikatea and pohutukawa.",
 vsearch:"trees and forests for kids SciShow Kids",res:"https://www.youtube.com/results?search_query=trees+forests+for+kids",
 act:"Find 3 trees near your home. Measure the circumference of each trunk at chest height. Look up a formula to estimate age from circumference. Find one native and one introduced tree.",
 ff:"The oldest tree in NZ is a kauri in the Waipoua Forest named Tane Mahuta (Lord of the Forest). It is estimated to be 1,500-2,500 years old, 51 metres tall, with a trunk circumference of 13.8 metres."},
{id:"n17",title:"Birds: Migration & Navigation",age:"6–10",dur:"30 min",
 content:"Many birds migrate enormous distances each year. The bar-tailed godwit migrates non-stop from Alaska to NZ — approximately 11,000 km in about 8 days without landing, eating or drinking. They double their body weight in fat before departing. They navigate using: Earth's magnetic field, star positions, the sun's position, landmarks and infrasound.",
 vsearch:"bird migration for kids how birds navigate",res:"https://www.youtube.com/results?search_query=bird+migration+for+kids",
 act:"Look up the NZ shorebird calendar. When do godwits arrive in NZ? When do they depart? Track them on eBird (free app). Can you spot one at a local estuary?",
 ff:"In 2022, a bar-tailed godwit set the non-stop flight distance record: 13,560 km from Alaska to Australia in 11 days 1 hour. It was tracked by satellite. The longest non-stop flight of any animal ever recorded."},
{id:"n18",title:"Seeds & Seed Dispersal",age:"5–8",dur:"30 min",
 content:"Seeds need to move away from the parent plant to avoid competition. Dispersal methods: wind (dandelion, totara — tiny, fluffy, lightweight), water (coconuts float), animals eating fruit (seeds pass through unharmed), animals carrying (burs stick to fur), ballistic (squirting cucumber explodes its seeds up to 12 metres). Each method is perfectly matched to the plant's environment.",
 vsearch:"seed dispersal for kids",res:"https://www.youtube.com/results?search_query=seed+dispersal+for+kids",
 act:"Collect 5 different seeds from around your home or garden. Identify which dispersal method each uses. Drop them from different heights and observe how they travel.",
 ff:"The coco-de-mer palm of the Seychelles produces the world's largest seed — up to 25 kg, the size of a child. The seeds float and can survive for years at sea, occasionally washing up on the shores of other islands."},
{id:"n19",title:"The Ocean: NZ's Backyard",age:"5–10",dur:"45 min",
 content:"New Zealand has one of the largest exclusive economic zones in the world — 4.1 million km2 of ocean, larger than the landmass of Australia. The ocean regulates the planet's temperature, produces about half of all oxygen (from marine algae), absorbs about 30% of global CO2, and drives weather systems globally.",
 vsearch:"NZ ocean marine life for kids",res:"https://www.youtube.com/results?search_query=NZ+ocean+marine+life+for+kids",
 act:"Visit a beach or estuary if possible. Identify 5 different species (use iNaturalist). Make a tidal zone diagram showing which creatures live where: splash zone, high tide zone, mid tide zone, low tide zone.",
 ff:"The Kermadec Trench north of NZ is one of the deepest places on Earth — 10,047 metres deep. In 2017 a new species of snailfish was discovered there living at 8,143 metres — the deepest fish ever recorded."},
{id:"n20",title:"Volcanoes & Earthquakes in Aotearoa",age:"7–10",dur:"45 min",
 content:"New Zealand sits on the boundary between the Pacific and Australian tectonic plates — the Pacific Ring of Fire. This means: active volcanoes (Tongariro, Ruapehu, White Island), frequent earthquakes, geothermal energy (Wairakei), and hot springs (Rotorua). The 2011 Christchurch earthquake killed 185 people.",
 vsearch:"volcanoes and earthquakes NZ for kids",res:"https://www.youtube.com/results?search_query=volcanoes+earthquakes+NZ+for+kids",
 act:"Research the tectonic plates NZ sits on. Draw a map showing the Pacific Ring of Fire. Mark NZ's active volcanoes: Ruapehu, Tongariro, Ngauruhoe, Tarawera, Taupo (supervolcano), White Island.",
 ff:"The Taupo supervolcano had the most powerful eruption in the last 5,000 years (around 186 AD). It ejected about 120 km3 of material, turned the sky red as far away as Rome and China, and devastated all of the North Island."},
{id:"n21",title:"Simple Machines in Nature & the Body",age:"7–10",dur:"45 min",
 content:"Nature uses all six simple machines. Lever: your forearm bones pivot at the elbow — lifting your hand. Wedge: bird beaks, claws, teeth. Pulley: the knee and ankle use tendons like ropes over pulleys. Inclined plane: DNA's double helix is a curved inclined plane (a screw). Wheel and axle: the hip joint is a ball and socket.",
 vsearch:"simple machines in nature human body for kids",res:"https://www.youtube.com/results?search_query=simple+machines+in+nature+body+kids",
 act:"Identify one example of each simple machine in the human body or in an animal. Sketch each with a label showing the fulcrum, load or axis of rotation.",
 ff:"The human knee is the most complex joint in the body — it acts as both a hinge and a rotational joint simultaneously. Engineers have spent over 60 years trying to build a mechanical knee that matches it. None have fully succeeded."},
{id:"n22",title:"The Human Brain & Memory",age:"7–10",dur:"30 min",
 content:"The human brain contains approximately 86 billion neurons. The estimated number of possible connections in one human brain is greater than the number of atoms in the observable universe. Memory is stored in patterns of neural connections — each time you recall something, you strengthen those connections.",
 vsearch:"the human brain for kids SciShow Kids",res:"https://www.youtube.com/results?search_query=human+brain+for+kids+SciShow",
 act:"Test your memory: read a list of 20 words once, then write as many as you can remember. Then try again using a story linking all 20 words. Which method works better?",
 ff:"The Orthodox practice of memorising Scripture, the Psalter, and the Liturgy is not just piety — it literally changes the brain's structure. Repeated memorisation grows the hippocampus and improves focus."},
{id:"n23",title:"Light, Colour & Rainbows",age:"5–9",dur:"30 min",
 content:"White light is made up of all colours of the visible spectrum: red, orange, yellow, green, blue, indigo, violet (ROY G BIV). A prism or water droplet splits white light into its colours by bending each colour at a slightly different angle. A rainbow is sunlight refracted and reflected inside millions of water droplets.",
 vsearch:"light and colour rainbows for kids SciShow Kids",res:"https://www.youtube.com/results?search_query=light+colour+rainbows+for+kids",
 act:"Make a rainbow using a garden hose in bright sunlight — stand with the sun behind you and mist toward the sun. Or put a glass of water on white paper in strong sunlight and trace the colours.",
 ff:"God gave the rainbow as a covenant sign after the Flood (Genesis 9:13) — promising never again to destroy the earth by water. The rainbow is the first sign given in Scripture."},
{id:"n24",title:"Sound, Hearing & Birdsong",age:"5–8",dur:"30 min",
 content:"Sound is a pressure wave travelling through air. The speed of sound in air is about 343 m/s. Frequency determines pitch — higher frequency equals higher pitch. Our ears detect frequencies between about 20 Hz and 20,000 Hz. The tui produces two sounds simultaneously because it has two independent voice boxes.",
 vsearch:"sound and hearing for kids SciShow Kids",res:"https://www.youtube.com/results?search_query=sound+hearing+for+kids",
 act:"Sound walk: sit outside and close your eyes for 3 minutes. Write down every sound you hear and estimate its distance. Use the Merlin Bird app (free) to identify birdsongs you hear.",
 ff:"The tui is one of the most musically sophisticated birds in the world. It has two voice boxes (syrinx) that operate independently — meaning it can sing a duet with itself. Each tui has its own dialect learned from its local group."},
{id:"n25",title:"Electricity: Static & Current",age:"7–10",dur:"45 min",
 content:"Static electricity: electrons transferred by friction (rub a balloon on your hair — the balloon gains electrons and becomes negatively charged, attracting your positively charged hair). Current electricity: electrons flowing through a conductor in a complete circuit. A simple circuit needs a power source, a conductor and a load (bulb, motor or buzzer).",
 vsearch:"electricity for kids circuits static SciShow Kids",res:"https://www.youtube.com/results?search_query=electricity+circuits+for+kids",
 act:"Build a simple circuit using a 9V battery, wire, and an LED (from a hardware store, approximately $2). Add a paper-clip switch. Then rub a balloon on your hair and investigate static electricity.",
 ff:"Lightning is a massive static electricity discharge — the voltage can reach 300 million volts. Benjamin Franklin's famous kite experiment (1752) demonstrated that lightning and static electricity are the same phenomenon."},
{id:"n26",title:"Magnets & Magnetism",age:"5–8",dur:"30 min",
 content:"Magnets have two poles: north and south. Like poles repel; opposite poles attract. Earth is a giant magnet — its core is molten iron that creates a magnetic field. A compass needle is a tiny magnet aligned by Earth's field. Animals that navigate by magnetic field: migratory birds, sea turtles, honey bees, sharks.",
 vsearch:"magnets and magnetism for kids",res:"https://www.youtube.com/results?search_query=magnets+and+magnetism+for+kids",
 act:"Use a bar magnet to test 20 household objects for magnetic properties. Sort into magnetic and non-magnetic groups. Make a simple compass from a needle, a magnet, and a bowl of water.",
 ff:"Every migrating bird — including the bar-tailed godwit flying from Alaska to NZ — carries magnetite crystals in its beak that allow it to detect Earth's magnetic field with extraordinary precision."},
{id:"n27",title:"Human Systems: Skeletal & Circulatory",age:"7–10",dur:"45 min",
 content:"The skeletal system: 206 bones in an adult (babies have about 270, many fuse as we grow). Functions: support, protection of organs, movement (with muscles), red blood cell production (in bone marrow). The circulatory system: the heart pumps blood through approximately 96,000 km of blood vessels — enough to circle the Earth twice.",
 vsearch:"skeletal and circulatory system for kids",res:"https://www.youtube.com/results?search_query=skeletal+circulatory+system+kids",
 act:"Make a simple model skeleton using paper fasteners (brads) and cardboard bones. Label the major bones: skull, clavicle, sternum, ribs, spine, humerus, radius, ulna, pelvis, femur, tibia, fibula.",
 ff:"Bone is one of the strongest natural materials known. Weight for weight, cortical bone is stronger than steel in tension. Yet it is light, self-repairing, and grows throughout childhood. Engineers still cannot match it."},
{id:"n28",title:"Environmental Stewardship: Orthodox Perspective",age:"7–10",dur:"30 min",
 content:"The Orthodox Church has been at the forefront of environmental theology. Ecumenical Patriarch Bartholomew (the Green Patriarch) declared environmental destruction a sin in 1989. The creation is not ours — it is God's, entrusted to our care. Every species lost, every ecosystem destroyed, is a destruction of the handiwork of God.",
 vsearch:"Orthodox Christianity and environment creation care",res:"https://www.youtube.com/results?search_query=Orthodox+Christianity+environment+creation+care",
 act:"Research one native NZ species that is endangered. What threatens it? What conservation efforts exist? What could your family do to help? Write a short report or draw a poster.",
 ff:"Patriarch Bartholomew wrote: To commit a crime against the natural world is a sin. For humans to cause species to become extinct and to destroy the biological diversity of God's creation — these are sins."},

{id:"n29",title:"Forces: Gravity, Friction & Buoyancy",age:"7–10",dur:"45 min",
 content:"Gravity: the force that attracts all objects with mass toward each other. On Earth's surface, gravity pulls everything downward at 9.8 m/s2. Friction: the force that resists motion between surfaces in contact. Buoyancy: the upward force exerted by a fluid on an object in it. An object floats when buoyancy equals gravity. These three forces govern nearly everything we experience daily.",
 vsearch:"gravity friction buoyancy for kids SciShow Kids",res:"https://www.youtube.com/results?search_query=gravity+friction+buoyancy+for+kids",
 act:"Gravity test: drop a heavy and light object from the same height simultaneously. Do they land together? Friction test: slide a book along different surfaces. Buoyancy: make a ball of playdough float by shaping it into a boat.",
 ff:"Aristotle believed heavier objects fell faster than lighter ones. This was accepted for 1,900 years — until Galileo (allegedly) dropped two balls of different weights from the Tower of Pisa around 1590 and showed they landed at the same time. Experiment always trumps authority."},
{id:"n30",title:"Plants & Medicine: God's Pharmacy",age:"7–10",dur:"30 min",
 content:"Over 25% of modern pharmaceutical drugs are derived from plants. Aspirin from willow bark. Morphine from poppies. Digitalis (heart medicine) from foxglove. Quinine (malaria treatment) from cinchona bark. Penicillin from mould. The kawakawa plant used by Maori has antibacterial properties confirmed by modern science. The creation is full of medicines waiting to be discovered.",
 vsearch:"plants and medicine for kids herbal medicine",res:"https://www.youtube.com/results?search_query=plants+and+medicine+for+kids",
 act:"Research 3 common medicines and their plant origins. Then research kawakawa — how did Maori use it? What has modern science confirmed? Grow a small herb garden with plants known for medicinal properties.",
 ff:"St Luke of Crimea (our October saint) was a surgeon who also studied the traditional plant medicines used by the peoples of Siberia during his labour camp years. He integrated this knowledge into his surgical practice — faith, science and traditional knowledge working together."},
{id:"n31",title:"Soil Erosion & Conservation",age:"7–10",dur:"30 min",
 content:"Soil erosion is the removal of topsoil by water, wind or human activity. Causes: deforestation (tree roots hold soil), overgrazing (bare ground exposed to rain), cultivation on steep slopes, flood events. Prevention: planting trees and groundcover, contour planting, terracing, cover crops in winter. NZ loses approximately 200 million tonnes of topsoil per year — mostly from hill country farms.",
 vsearch:"soil erosion and conservation for kids",res:"https://www.youtube.com/results?search_query=soil+erosion+conservation+for+kids",
 act:"Erosion experiment: fill two trays with soil — one bare, one with grass growing. Tilt both and pour equal amounts of water from a watering can. Compare the runoff and erosion. Which lost more soil?",
 ff:"The Dust Bowl of the American Great Plains (1930s) was caused by decades of ploughing the native prairie grasses that held the soil. When drought came, the topsoil — some of it built over thousands of years — blew away in massive black blizzards. 2.5 million people fled their farms."},
{id:"n32",title:"The Human Immune System",age:"7–10",dur:"30 min",
 content:"The immune system is the body's defence force. First line: skin and mucous membranes (physical barrier). Second line: innate immunity — inflammation, fever, white blood cells that engulf invaders. Third line: adaptive immunity — T-cells and B-cells that recognise specific invaders and create antibodies that remember them. Vaccines work by training the adaptive immune system without causing the disease.",
 vsearch:"immune system for kids SciShow Kids",res:"https://www.youtube.com/results?search_query=immune+system+for+kids+SciShow",
 act:"Track your family's health for 4 weeks. When someone gets sick: what symptoms appeared? In what order? How long did it take to recover? This is your immune system's battle log.",
 ff:"The word 'vaccine' comes from vacca (Latin for cow) — because the first vaccine used cowpox to protect against smallpox. Edward Jenner noticed in 1796 that milkmaids who caught cowpox never seemed to get smallpox. This observation saved hundreds of millions of lives."},
{id:"n33",title:"Energy: Renewable vs Non-Renewable",age:"7–10",dur:"45 min",
 content:"Non-renewable energy: coal, oil, natural gas (fossil fuels formed over millions of years — once burned, gone). Renewable energy: solar (sunlight), wind, hydroelectric (flowing water), geothermal (earth's heat), tidal. NZ generates approximately 85% of its electricity from renewable sources — one of the highest proportions in the world, largely due to hydroelectric dams and geothermal plants.",
 vsearch:"renewable and non-renewable energy for kids",res:"https://www.youtube.com/results?search_query=renewable+non-renewable+energy+for+kids",
 act:"Survey your home's energy use: where does your electricity come from? How is your home heated? How is hot water heated? Calculate approximate weekly energy use and research ways to reduce it.",
 ff:"NZ's Wairakei geothermal power station (opened 1958) was the second geothermal power station in the world. It uses the earth's heat — the same volcanic energy that produced the Taupo eruption — to generate electricity cleanly and reliably 24 hours a day."},
{id:"n34",title:"Navigation by Sun & Shadow",age:"7–10",dur:"1 hour",
 content:"The sun rises roughly east and sets roughly west — roughly because its exact path varies by season and latitude. At noon, the sun is due north in the southern hemisphere (due south in the northern). Shadow stick method: mark shadow tip, wait 15 minutes, mark again — line between marks points west to east. This technique has been used by every culture in history that lived by the sun.",
 vsearch:"sun navigation shadow stick for kids outdoors",res:"https://www.youtube.com/results?search_query=sun+navigation+shadow+stick+for+kids",
 act:"Outside on a sunny day: place a 1-metre stick vertically in the ground. Mark the shadow tip at 10 am and again at 2 pm. Draw the line. Where does it point? Confirm with a compass.",
 ff:"Traditional Polynesian navigators crossing the Pacific used the sun's position, its arc through the sky, and the angle of its rise and set relative to known landmarks to maintain course over thousands of kilometres of open ocean. This was a living science carried in the navigator's memory."},
{id:"n35",title:"Ecosystems in Crisis & Hope",age:"8–10",dur:"45 min",
 content:"Ecosystems are threatened by: habitat loss (land clearing, urban sprawl), invasive species (rats, stoats, possums in NZ), pollution (plastic in oceans, pesticides in soil), climate change (shifting seasons, more extreme weather). But conservation works: kakapo numbers growing, kiwi populations stabilising, wetlands being restored. Hope and action together are more powerful than despair.",
 vsearch:"ecosystems in crisis conservation hope for kids",res:"https://www.youtube.com/results?search_query=ecosystems+conservation+hope+kids",
 act:"Research one NZ conservation success story in depth (kakapo, black robin, NZ sea lion, Chatham Islands taiko). What was the lowest population point? What actions were taken? What is the current population?",
 ff:"The black robin of the Chatham Islands was reduced to just 5 individuals in 1980 — including only one breeding female, 'Old Blue.' Through intensive conservation including cross-fostering eggs to other species, the population has recovered to over 300. Old Blue is the ancestor of every black robin alive today."},
{id:"n36",title:"Science & Faith: An Orthodox Perspective",age:"8–10",dur:"30 min",
 content:"The Orthodox Church has never taught that faith and science are enemies. The Fathers wrote that creation is a Second Book of God — readable alongside Scripture. Many great scientists were devout Orthodox Christians: Mendeleev (periodic table), Pavlov (conditioned reflexes), St Luke of Crimea (surgery). The Church's teaching: all truth is God's truth. Good science reveals the handiwork of the Creator.",
 vsearch:"science and faith Orthodox Christianity reconciliation",res:"https://www.youtube.com/results?search_query=science+and+faith+Orthodox+Christianity",
 act:"Research one Orthodox Christian scientist (Mendeleev, Pavlov, Georges Lemaitre who proposed the Big Bang, or St Luke of Crimea). Write a one-paragraph biography. How did their faith and science relate?",
 ff:"Georges Lemaitre (1894-1966) was a Belgian Catholic priest who first proposed what became the Big Bang Theory in 1927. Einstein initially resisted the idea but later accepted it. When asked if science contradicted his faith, Lemaitre said: There is no conflict — I have two ways of searching for truth, and I find them complementary."},
]},
{id:"maths",name:"Mathematics",emoji:"🔢",color:P.navy,tagline:"Numbers, shapes and the patterns woven into creation.",
lessons:[
{id:"m1",title:"Counting, Numbers & Number Lines",age:"4–6",dur:"30 min",
 content:"Count aloud to 100, then backwards from 20. Numbers carry meaning in Scripture: the Trinity is 3. Seven is the days of creation. 12 is the Apostles and tribes. 40 is the days of Lent and Christ's fast. 50 is Pentecost. Numbers are not merely calculation — they carry sacred meaning.",
 vsearch:"Numberblocks full episode BBC",res:"https://www.youtube.com/results?search_query=Numberblocks+full+episode",
 act:"Hopscotch grid 1–20 in chalk. Hop calling out each number. Then evens only, then odds. Find three sacred numbers in the Bible this week (3, 7, 12, 40, 50…).",
 ff:"The Romans had no zero — the concept came from India ~500 AD. Without zero, computing and modern science collapse. Zero is nothing that makes everything possible."},
{id:"m2",title:"Addition & Subtraction to 20",age:"5–7",dur:"45 min",
 content:"Adding is putting together; subtracting is taking away. Use concrete objects first. 7+3=10. Subtraction is addition in reverse: 10−3=7 because 7+3=10. Learn all number bonds to 10 by heart — as important to memorise as the Lord's Prayer.",
 vsearch:"Math Antics addition subtraction",res:"https://www.youtube.com/results?search_query=Math+Antics+addition+subtraction",
 act:"Roll two dice, add the numbers, keep score over 10 rounds. Then subtraction: bigger minus smaller. Who can get closest to 10 without going over?",
 ff:"The + and − signs were first used in print in 1489 by German mathematician Johannes Widmann. Before that, people wrote 'plus' and 'minus' out in full."},
{id:"m3",title:"Times Tables 2–12",age:"6–9",dur:"45 min",
 content:"Skip counting (2,4,6…; 5,10,15…) is the foundation of multiplication. 4×3 means four groups of three = 12. Times tables are the most practically useful things you will memorise in primary school — like knowing the Creed, you will use them every day of your life.",
 vsearch:"times tables songs kids Laugh Along Learn",res:"https://www.youtube.com/results?search_query=times+tables+songs+kids",
 act:"Make a 12×12 multiplication grid on graph paper. Complete over a week. Flashcards for weak spots. The 9 times table: digits always add to 9.",
 ff:"The ancient Babylonians used a base-60 number system — which is why we have 60 seconds, 60 minutes, and 360 degrees in a circle."},
{id:"m4",title:"Shapes, Symmetry & Sacred Geometry",age:"5–8",dur:"30 min",
 content:"Triangle (3 sides — the Trinity), quadrilateral (4), pentagon (5), hexagon (6), octagon (8 — the number of Resurrection: Christ rose on the eighth day, the first day of the new creation beyond the seven-day cycle). Orthodox church architecture is full of symbolic shapes.",
 vsearch:"2D shapes symmetry for kids",res:"https://www.youtube.com/results?search_query=2D+shapes+symmetry+kids",
 act:"Fold paper in half, paint one side, press — symmetrical design. Look at photos of Orthodox churches: what shapes do you see? What might they symbolise?",
 ff:"The octagon symbolises the Resurrection: Christ rose on the eighth day — the first day of the new week, beyond the regular cycle of time."},
{id:"m5",title:"Fractions: Halves, Quarters, Thirds",age:"7–10",dur:"45 min",
 content:"A fraction is part of a whole. The denominator (bottom) shows equal parts total; the numerator (top) shows how many you have. 2/4 = 1/2. Fractions are essential for cooking, building and farming — the practical work of any Christian household.",
 vsearch:"Math Antics fractions are parts",res:"https://www.youtube.com/results?search_query=Math+Antics+fractions",
 act:"Bake something requiring 1/2 cup, 1/4 tsp, 1/3 cup measures. Compare the volumes. Which is bigger: 1/3 or 1/4?",
 ff:"Ancient Egyptians only used unit fractions (1 on top): 1/2, 1/3, 1/5. To write 3/4 they wrote 1/2 + 1/4. Their fraction tables are on the Rhind Mathematical Papyrus — 3,600 years old."},
{id:"m6",title:"Money, Stewardship & Tithing",age:"6–9",dur:"45 min",
 content:"NZ coins: 10c, 20c, 50c, $1, $2. Notes: $5, $10, $20, $50, $100. 100 cents = $1. Understanding money is stewardship — how we use what God gives us is a spiritual matter. Tithing (giving 10%) has been practised since Abraham gave a tenth to Melchizedek (Genesis 14).",
 vsearch:"money making change kids NZ dollars",res:"https://www.youtube.com/results?search_query=money+making+change+kids+NZ",
 act:"Set up a shop. Practise counting back change. Calculate: if your family tithes 10% of income of $1,000/week, how much per year is that?",
 ff:"The Parable of the Talents (Matthew 25) is about money — but its deeper meaning is about using every gift God gives you faithfully."},
{id:"m7",title:"Telling Time & The Church Hours",age:"6–9",dur:"30 min",
 content:"Short hand = hours, long hand = minutes. 60 min = 1 hour, 24 hours = 1 day. The Orthodox Church marks time with Vespers (sunset), Compline (night), Orthros (dawn), and the Hours (First = 6am, Third = 9am, Sixth = noon, Ninth = 3pm — the hour of Christ's death).",
 vsearch:"telling time for kids Homeschool Pop",res:"https://www.youtube.com/results?search_query=telling+time+for+kids",
 act:"Make a paper-plate clock. Calculate: what are the Third and Ninth Hours in modern time? How many hours between Vespers (6 pm) and Orthros (6 am)?",
 ff:"Clocks run clockwise because ancient sundials in the northern hemisphere cast shadows moving left to right. The very direction of time comes from watching the sun — which God set in the heavens as a sign (Genesis 1:14)."},
{id:"m8",title:"Measurement & Practical Geometry",age:"7–10",dur:"1 hour",
 content:"Length: mm, cm, m, km. Mass: g, kg. Volume: mL, L. God gave precise measurements to Noah for the Ark (300 cubits × 50 × 30) and to Moses for the Tabernacle. Precision in building is a biblical value. Area = length × width. Perimeter = sum of all sides.",
 vsearch:"measurement length mass volume kids Free School",res:"https://www.youtube.com/results?search_query=measurement+for+kids",
 act:"Measure 10 household objects. Weigh 5 items. Measure your bedroom floor and calculate area and perimeter. The Ark was ~137m × 22.5m × 13.5m — calculate its floor area.",
 ff:"Before the metre (invented 1793), every village had its own measurements. A cubit was a forearm length — the unit used for the Ark, the Tabernacle, and the Temple."},

{id:"m9",title:"Long Multiplication",age:"8–10",dur:"1 hour",
 content:"To multiply a 2-digit number by a 2-digit number: use the grid method (partition both numbers, multiply each part, add). Or use the standard algorithm: multiply by ones, then by tens (shift one place left), then add the partial products. 23 x 47: work through every digit combination systematically.",
 vsearch:"long multiplication for kids Math Antics",res:"https://www.youtube.com/results?search_query=Math+Antics+long+multiplication",
 act:"Practise 10 long multiplication problems per day for a week. Start with 2x2 digit, progress to 3x2 digit. Check answers with a calculator — but try to beat the calculator's time.",
 ff:"Katherine Johnson at NASA calculated rocket flight trajectories by hand so reliably that astronaut John Glenn refused to fly until she verified the computer's figures. She was also a devout churchwoman."},
{id:"m10",title:"Division with Remainders",age:"7–10",dur:"45 min",
 content:"Division means sharing equally or finding how many groups fit. 17 / 4 = 4 remainder 1 (four groups of 4 with 1 left over). The remainder is always less than the divisor. Short division: write the answer digit by digit, carrying the remainder to the next column.",
 vsearch:"division with remainders Math Antics",res:"https://www.youtube.com/results?search_query=Math+Antics+division+with+remainders",
 act:"Divide a pile of 50 objects into different group sizes. Record the quotient and remainder each time. When does the remainder become 0?",
 ff:"Roman soldiers dividing battle spoils had to use an abacus — the Roman numeral system could not be used for division. Our decimal system changed everything."},
{id:"m11",title:"Angles: Right, Acute, Obtuse & Reflex",age:"7–10",dur:"45 min",
 content:"An angle is the amount of turn between two lines meeting at a point. Right angle = exactly 90 degrees. Acute = less than 90 degrees. Obtuse = between 90 and 180 degrees. Straight angle = exactly 180 degrees. Reflex = more than 180 degrees. Angles in any triangle always add to 180 degrees. In any quadrilateral: always 360 degrees.",
 vsearch:"types of angles for kids acute right obtuse",res:"https://www.youtube.com/results?search_query=types+of+angles+kids",
 act:"Use a protractor to measure 10 angles you find in photos or around the house. Classify each. Draw a triangle and measure all three angles — do they add to 180?",
 ff:"Navigators in the age of sail used a sextant to measure the angle between the sun and the horizon. From that one angle they could calculate their exact latitude anywhere on earth."},
{id:"m12",title:"Coordinate Grids",age:"8–10",dur:"45 min",
 content:"A coordinate grid has a horizontal x-axis and a vertical y-axis meeting at (0,0), the origin. A coordinate pair (x, y) tells you to go x along, then y up. Coordinates are used in maps, satellite navigation, video games and architecture.",
 vsearch:"coordinate grids for kids",res:"https://www.youtube.com/results?search_query=coordinate+grids+for+kids",
 act:"On squared paper, draw a hidden picture by connecting coordinates in order. Swap with a sibling to discover each other's pictures. Then locate your house on Google Maps and note the latitude and longitude.",
 ff:"GPS satellites know your location by measuring the time it takes a signal to travel from four satellites simultaneously. Your phone calculates your coordinates using equations based on coordinate geometry."},
{id:"m13",title:"Negative Numbers",age:"8–10",dur:"30 min",
 content:"Negative numbers are less than zero — written with a minus sign: -1, -5, -273. They go to the left of zero on a number line. Negative numbers appear in temperature, bank balances, altitude, and depth below sea level.",
 vsearch:"negative numbers for kids Math Antics",res:"https://www.youtube.com/results?search_query=Math+Antics+negative+numbers",
 act:"Draw a vertical number line from -10 to +10. Temperature game: what temp is 5 degrees colder than -2? How much warmer is +8 than -3?",
 ff:"Ancient China used red counting rods for positive numbers and black for negative. Negative numbers were not accepted as real in Europe until the 1700s."},
{id:"m14",title:"Roman Numerals",age:"7–10",dur:"30 min",
 content:"Roman numerals: I=1, V=5, X=10, L=50, C=100, D=500, M=1000. Rules: smaller before larger means subtract (IX=9, IV=4, XL=40, CM=900). Smaller after larger means add (XI=11, XV=15). They appear on clock faces, copyright dates and Orthodox church inscriptions.",
 vsearch:"Roman numerals for kids",res:"https://www.youtube.com/results?search_query=Roman+numerals+for+kids",
 act:"Convert your birthday to Roman numerals. Convert the year of Waitangi (1840) and the year NZ became a country (1907). Find 5 examples of Roman numerals in your home.",
 ff:"The Romans used an abacus for actual calculations — their numeral system was too clunky for arithmetic. Try multiplying XLVIII x XXIV without converting to modern numbers."},
{id:"m15",title:"Prime & Composite Numbers",age:"8–10",dur:"30 min",
 content:"A prime number has exactly two factors: 1 and itself (2, 3, 5, 7, 11, 13, 17, 19...). A composite number has more than two factors. 1 is neither prime nor composite. Every composite number can be broken into prime factors.",
 vsearch:"prime and composite numbers Math Antics",res:"https://www.youtube.com/results?search_query=Math+Antics+prime+composite+numbers",
 act:"Use the Sieve of Eratosthenes: write 1-100. Cross out multiples of 2, then 3, then 5, then 7. The uncrossed numbers (except 1) are all prime. How many are there?",
 ff:"The largest known prime number (as of 2024) has over 41 million digits. Finding large primes matters enormously for internet encryption — the security of your bank account depends on it."},
{id:"m16",title:"Factors & Multiples",age:"7–10",dur:"30 min",
 content:"A factor of a number divides it evenly with no remainder. Factors of 12: 1, 2, 3, 4, 6, 12. A multiple is what you get when you multiply: multiples of 4 are 4, 8, 12, 16, 20... LCM (Least Common Multiple) and HCF (Highest Common Factor) are used to add fractions and simplify problems.",
 vsearch:"factors and multiples for kids",res:"https://www.youtube.com/results?search_query=factors+and+multiples+for+kids",
 act:"Find all factor pairs of 36, 48, 60 and 100. List the first 10 multiples of 6, 7, 8 and 9. Find the LCM of 4 and 6. Find the HCF of 24 and 36.",
 ff:"Ancient Greeks knew that perfect numbers (where the sum of factors equals the number itself) were special. 6 (1+2+3=6) and 28 (1+2+4+7+14=28) are perfect numbers. Only 51 perfect numbers are known."},
{id:"m17",title:"Volume & Capacity",age:"7–10",dur:"45 min",
 content:"Volume is the amount of 3D space an object takes up (measured in cm3 or m3). Capacity is how much liquid a container holds (mL or L). Volume of a rectangular prism = length x width x height. 1 cm3 of water = 1 mL.",
 vsearch:"volume and capacity for kids",res:"https://www.youtube.com/results?search_query=volume+and+capacity+for+kids",
 act:"Fill a measuring jug with water. Pour into different shaped containers. Does the volume change? Calculate the volume of a tissue box using L x W x H.",
 ff:"Archimedes discovered how to measure the volume of irregular objects by noticing his bath overflowed when he got in. He reportedly ran through the streets shouting 'Eureka!' (I found it!)."},
{id:"m18",title:"Data: Bar Graphs, Tally Charts & Pie Charts",age:"7–10",dur:"45 min",
 content:"Tally charts collect data in groups of 5 (four lines, one diagonal cross). Bar graphs show data as columns. Pie charts show proportions as slices of a whole. All graphs need a title, labelled axes and a key. Data is how we tell stories with numbers.",
 vsearch:"bar graphs and pie charts Math Antics",res:"https://www.youtube.com/results?search_query=Math+Antics+bar+graphs+charts",
 act:"Survey your family: favourite colour, food, animal. Make a tally chart, then a bar graph on graph paper. Convert to a pie chart by calculating percentages.",
 ff:"Florence Nightingale invented the rose diagram (a type of pie chart) to convince Parliament to improve hospital sanitation — and it worked. She was as much a statistician as a nurse."},
{id:"m19",title:"Probability & Chance",age:"8–10",dur:"45 min",
 content:"Probability measures how likely something is — from 0 (impossible) to 1 (certain). A fair coin: 1/2 (50%) chance of heads. A standard die: 1/6 chance of rolling any number. Probability = favourable outcomes divided by total possible outcomes.",
 vsearch:"probability for kids Math Antics",res:"https://www.youtube.com/results?search_query=Math+Antics+probability",
 act:"Roll a die 60 times. Record results in a tally chart. Each number should appear roughly 10 times. How close were the actual results to the predicted probability?",
 ff:"The first mathematical study of probability came from a gambler asking Blaise Pascal why certain dice combinations came up less often than expected. Pascal solved it in letters with Pierre de Fermat in 1654."},
{id:"m20",title:"Introduction to Algebra",age:"8–10",dur:"45 min",
 content:"Algebra uses letters to represent unknown numbers. x + 5 = 12 means x = 7. To solve, do the same operation to both sides of the equation. Algebraic thinking is why maths suddenly explains everything — science, engineering and economics all run on algebra.",
 vsearch:"introduction to algebra for kids Khan Academy",res:"https://www.youtube.com/results?search_query=introduction+to+algebra+for+kids",
 act:"Solve 10 one-step equations (x + a = b; x - a = b; ax = b; x / a = b). Then write 5 word-problem equations from real situations.",
 ff:"The word 'algebra' comes from a 9th-century Arabic book by al-Khwarizmi. 'Al-jabr' means 'the restoration of broken parts' — which is exactly what solving for x does."},
{id:"m21",title:"Rounding & Estimation",age:"7–9",dur:"30 min",
 content:"Rounding makes numbers easier to work with. Round to nearest 10: look at the ones digit — 0-4 round down; 5-9 round up. 47 becomes 50; 43 becomes 40. Good estimators are valued in engineering, cooking, building and farming — precision matters, but so does quick judgement.",
 vsearch:"rounding numbers for kids Math Antics",res:"https://www.youtube.com/results?search_query=Math+Antics+rounding+numbers",
 act:"Round all the prices in a supermarket catalogue to the nearest $1 and nearest $10. Estimate your total shopping basket. How close are you to the real total?",
 ff:"Weather forecasters use rounding constantly — a forecast of '15-16 degrees' is more useful than '15.7 degrees' which implies a false precision."},
{id:"m22",title:"Problem-Solving Strategies",age:"7–10",dur:"1 hour",
 content:"Great mathematicians use strategies, not just formulas. Draw a diagram. Make a table. Look for a pattern. Work backwards. Try a simpler version first. Check your answer makes sense. These strategies work on problems no one has ever seen before.",
 vsearch:"maths problem solving strategies for kids",res:"https://www.youtube.com/results?search_query=maths+problem+solving+strategies+kids",
 act:"Solve 5 word problems using a different strategy each time. Write down which strategy you used and why. Which strategy do you naturally prefer?",
 ff:"George Polya wrote 'How to Solve It' in 1945. It is still considered the best book ever written about mathematical problem solving and has been translated into 17 languages."},
{id:"m23",title:"Mental Maths Tricks",age:"7–10",dur:"30 min",
 content:"Mental maths is faster with strategies. Multiply by 5: halve, then multiply by 10. Multiply by 9: multiply by 10, subtract the number. Add 9: add 10, subtract 1. Doubles and near-doubles. Compensating: 47+38 = 50+38-3. The best mental mathematicians see numbers as flexible, not fixed.",
 vsearch:"mental maths tricks for kids",res:"https://www.youtube.com/results?search_query=mental+maths+tricks+for+kids",
 act:"Mental maths speed drill: 20 questions in 2 minutes. No writing, no calculator. Track your score each day for a week. What improved most?",
 ff:"Shakuntala Devi, the 'human calculator' from India, mentally multiplied two 13-digit numbers in 28 seconds in 1980 — faster than the computer used to check her answer."},
{id:"m24",title:"3D Shapes: Prisms, Pyramids & Spheres",age:"6–9",dur:"30 min",
 content:"3D shapes have length, width and height. Cube (6 square faces), rectangular prism (6 rectangular faces), triangular prism (2 triangular + 3 rectangular faces), pyramid (1 square base + 4 triangular faces), cylinder (2 circular bases + 1 curved surface), sphere (1 curved surface, no edges or vertices).",
 vsearch:"3D shapes for kids prisms pyramids",res:"https://www.youtube.com/results?search_query=3D+shapes+for+kids",
 act:"Find one example of each 3D shape around your home or outside. Build models from cardboard nets. Look at photos of Orthodox churches — how many 3D shapes can you identify?",
 ff:"The Great Pyramid of Giza (2560 BC) is a square pyramid. Its base is level to within 2.1 cm despite covering 5.5 hectares. Ancient Egyptians achieved this using the mathematics of right-angled triangles."},
{id:"m25",title:"Speed, Distance & Time",age:"9–10",dur:"45 min",
 content:"Speed = Distance divided by Time. Distance = Speed x Time. Time = Distance divided by Speed. Three formulas, same relationship. A car at 60 km/h for 2 hours travels 120 km. If you need to travel 180 km in 3 hours, your average speed must be 60 km/h.",
 vsearch:"speed distance time for kids",res:"https://www.youtube.com/results?search_query=speed+distance+time+for+kids",
 act:"Calculate: (1) How far does a runner travel at 8 km/h for 45 minutes? (2) If a ship sails 300 km in 12 hours, what is its speed? (3) How long to drive 480 km at 80 km/h?",
 ff:"The first measured speed on land was achieved by a steam locomotive in 1825 — 24 km/h. Today's high-speed trains in France reach 320 km/h. The speed of light is approximately 300,000 km per second."},
{id:"m26",title:"Symmetry, Tessellation & Patterns",age:"6–9",dur:"45 min",
 content:"Symmetry: a shape has a line of symmetry if one half is the mirror image of the other. Rotational symmetry: a shape looks the same when rotated. Tessellation: shapes that fit together without gaps or overlaps (like floor tiles). The most common tessellating shapes are triangles, squares and hexagons.",
 vsearch:"symmetry and tessellation for kids",res:"https://www.youtube.com/results?search_query=symmetry+tessellation+for+kids",
 act:"Create a tessellation pattern using only one shape. Try an irregular shape — trace it, cut it out, and see if it tiles. The floor tiles or brickwork of your home may already show tessellation.",
 ff:"Islamic geometric art is based on tessellation. Muslim artists explored all 17 possible wallpaper symmetry groups in art approximately 500 years before mathematicians formally identified them."},
{id:"m27",title:"Ratios & Proportions",age:"8–10",dur:"45 min",
 content:"A ratio compares two quantities: 2:3 means 'for every 2 of one thing, there are 3 of another.' To scale a recipe up or down, you use ratios. If a recipe serves 4 and you want to serve 10, multiply all quantities by 10/4 = 2.5. Ratios are fundamental to cooking, building, mixing concrete and understanding scale models.",
 vsearch:"ratios and proportions for kids",res:"https://www.youtube.com/results?search_query=ratios+proportions+for+kids",
 act:"Scale a recipe from 4 servings to 10. Calculate: if cement mix is 1 part cement to 3 parts sand, how much sand do you need with 2 kg of cement?",
 ff:"The Golden Ratio (1:1.618) appears in the proportions of the Parthenon, many Renaissance paintings, the proportions of a nautilus shell, and arguably in the proportions of the human face."},
{id:"m28",title:"The History of Numbers & Zero",age:"8–10",dur:"45 min",
 content:"Tally marks were humanity's first numbers — found on bones 40,000 years old. Babylonians invented positional notation around 2000 BC. Indians invented zero around 500 AD. Arabs spread the decimal system to Europe around 900 AD. Without zero, computing, science and engineering as we know them are impossible.",
 vsearch:"history of numbers and zero for kids",res:"https://www.youtube.com/results?search_query=history+of+numbers+zero+kids",
 act:"Research how different ancient cultures wrote numbers: Egyptian hieroglyphic numbers, Babylonian cuneiform, Roman numerals, Mayan numbers. Write your age in three of them.",
 ff:"The concept of zero was so strange that some medieval European scholars called it 'the number of the devil' because it represented nothing. Today zero is the foundation of all computing."},

{id:"m29",title:"Symmetry in Nature & Architecture",age:"6–9",dur:"30 min",
 content:"Bilateral symmetry: one line divides a shape into two mirror halves (butterflies, human faces, most animals). Radial symmetry: multiple lines of symmetry from a centre point (flowers, starfish, snowflakes). Rotational symmetry: a shape looks the same after being rotated by less than 360 degrees. Orthodox icons and church architecture are deliberately symmetrical — reflecting the order and beauty of God.",
 vsearch:"symmetry in nature and architecture for kids",res:"https://www.youtube.com/results?search_query=symmetry+nature+architecture+kids",
 act:"Find 5 symmetrical objects in nature outside. Sketch each and draw in the lines of symmetry. Find a photo of an Orthodox church facade and count all lines of symmetry.",
 ff:"A snowflake always has exactly 6-fold rotational symmetry — never 5, never 7. This is because water molecules form hexagonal crystal structures at low temperatures. No two snowflakes are identical — yet every one follows the same mathematical rule."},
{id:"m30",title:"Long Division",age:"8–10",dur:"1 hour",
 content:"Long division: divide, multiply, subtract, bring down — repeat. To divide 852 by 4: how many 4s in 8? (2) Write 2 above, multiply 2x4=8, subtract 8-8=0, bring down 5. How many 4s in 5? (1) Write 1, multiply 1x4=4, subtract 5-4=1, bring down 2. How many 4s in 12? (3) Write 3, multiply 3x4=12, subtract 12-12=0. Answer: 213.",
 vsearch:"long division for kids step by step Math Antics",res:"https://www.youtube.com/results?search_query=Math+Antics+long+division",
 act:"Practise 10 long division problems. Start with 3-digit divided by 1-digit, then 3-digit divided by 2-digit. Check each answer by multiplying back: quotient x divisor should equal dividend.",
 ff:"Before calculators, every engineer, scientist, accountant and navigator performed long division by hand. The engineers who sent the Apollo 11 mission to the moon in 1969 checked critical calculations by hand. Long division builds a mental model of how numbers relate to each other that calculators cannot give."},
{id:"m31",title:"Converting Fractions, Decimals & Percentages",age:"8–10",dur:"45 min",
 content:"The three forms are the same value in different dress. To convert a fraction to a decimal: divide the numerator by the denominator (3/4 = 3 divided by 4 = 0.75). To convert a decimal to a percentage: multiply by 100 (0.75 = 75%). To convert a percentage to a fraction: write over 100 and simplify (75% = 75/100 = 3/4). All three represent parts of a whole.",
 vsearch:"converting fractions decimals percentages Math Antics",res:"https://www.youtube.com/results?search_query=Math+Antics+fractions+decimals+percentages",
 act:"Complete a conversion table: fill in all three forms for 1/2, 1/4, 3/4, 1/5, 2/5, 1/8, 3/8, 1/3, 2/3. Memorise the most common ones — you will use them every day.",
 ff:"Ancient Babylonians used fractions with denominators of 60 (a sexagesimal system). This is why we still divide hours into 60 minutes and minutes into 60 seconds — the Babylonian fraction system has been embedded in our timekeeping for 4,000 years."},
{id:"m32",title:"Averages: Mean, Median & Mode",age:"8–10",dur:"30 min",
 content:"Mean: add all values, divide by how many (the mathematical average). Median: the middle value when arranged in order. Mode: the most frequently occurring value. Range: highest minus lowest. Each measure tells you something different about a set of data. Statisticians use all four. When politicians say 'the average wage is X' they usually mean the mean — which can be misleading if a few very high earners skew the data.",
 vsearch:"mean median mode for kids",res:"https://www.youtube.com/results?search_query=mean+median+mode+for+kids",
 act:"Record the daily temperature for 7 days. Calculate mean, median, mode and range. Then survey 10 people: how many hours of sleep did you get last night? Calculate all four averages for the results.",
 ff:"Florence Nightingale is credited with revolutionising the use of statistics in medicine in the 1850s. She collected data on hospital deaths, calculated averages, and presented them visually to Parliament — changing public health policy and saving thousands of lives."},
{id:"m33",title:"Time: 24-Hour Clock & Time Zones",age:"7–10",dur:"30 min",
 content:"The 24-hour clock avoids AM/PM confusion: 0000 (midnight), 0600 (6 am), 1200 (noon), 1800 (6 pm), 2359 (one minute before midnight). Military and aviation use 24-hour time. NZ is in UTC+12 (or +13 in daylight saving) — 12-13 hours ahead of London. When it is noon in Auckland, it is midnight the previous night in London.",
 vsearch:"24-hour clock and time zones for kids",res:"https://www.youtube.com/results?search_query=24+hour+clock+time+zones+for+kids",
 act:"Convert 10 times between 12-hour and 24-hour format. Then calculate: if it is 10:00 am Tuesday in Auckland, what time and day is it in London? In New York (UTC-5)?",
 ff:"NZ is one of the first countries to see the New Year each year — ahead of Australia by 2-3 hours depending on daylight saving. The NZ town of Gisborne is consistently the first city in the world to see the New Year's sunrise."},
{id:"m34",title:"Geometry: Triangles & Their Properties",age:"8–10",dur:"45 min",
 content:"Triangles are the strongest shape in nature and engineering — they cannot be deformed without changing the length of a side. Types: equilateral (all sides equal, all angles 60 degrees), isosceles (two sides equal, two angles equal), scalene (no sides or angles equal), right-angled (one 90-degree angle). Angles in any triangle always add to exactly 180 degrees.",
 vsearch:"triangles and their properties for kids",res:"https://www.youtube.com/results?search_query=triangles+properties+for+kids",
 act:"Draw one of each triangle type. Measure all angles with a protractor — do they add to 180 degrees? Build triangles from straws and pipe cleaners. Try to deform them compared to a square frame — which is stronger?",
 ff:"The triangle is the structural element of every bridge, roof truss, Eiffel Tower and bicycle frame. The Great Pyramid of Giza has stood for 4,500 years in part because its triangular faces distribute load so efficiently. God built triangle-strength into the shoulder joint of the human body."},
{id:"m35",title:"Pythagoras' Theorem",age:"9–10",dur:"45 min",
 content:"In a right-angled triangle: the square of the hypotenuse (the longest side, opposite the right angle) equals the sum of the squares of the other two sides. a squared + b squared = c squared. A 3-4-5 triangle: 9 + 16 = 25. Ancient Egyptians used a 3-4-5 rope triangle to create perfect right angles when laying out building foundations. This theorem was known for 1,000 years before Pythagoras.",
 vsearch:"Pythagoras theorem for kids",res:"https://www.youtube.com/results?search_query=Pythagoras+theorem+for+kids",
 act:"Verify the theorem with a 3-4-5 triangle drawn on squared paper. Then use it to find the missing side: a=5, b=12, c=? (13). Also: a=8, b=15, c=? (17). These are called Pythagorean triples.",
 ff:"The 3-4-5 triangle was used by ancient Egyptian surveyors (called rope-stretchers or harpedonaptai) to create perfect right angles when laying out the pyramids and temples. They tied a rope into 12 equal sections and formed a 3-4-5 triangle by pegging it to the ground."},
{id:"m36",title:"Maths Through the Year: A Review",age:"All",dur:"1 hour",
 content:"Mathematics is the language in which God has written the universe (Galileo). Over this year we have explored: number operations, fractions, decimals, percentages, geometry, data, probability, algebra, measurement, and the history of numbers. All of mathematics is the study of patterns and relationships — and God is a God of pattern, order and relationship.",
 vsearch:"maths review year end reflection for kids",res:"https://www.youtube.com/results?search_query=maths+review+year+end+kids",
 act:"Make a maths mind-map of everything you have learned this year. Put 'Mathematics' in the centre. Branch out to every topic. For each topic, write one thing you remember and one question you still have.",
 ff:"Galileo Galilei wrote in 1623: The universe is written in the language of mathematics, and its characters are triangles, circles, and other geometrical figures, without which it is humanly impossible to understand a single word of it. The Orthodox Fathers would add: and the Author of that language is the Logos, Jesus Christ."},
]},
{id:"english",name:"English Language & Literature",emoji:"📚",color:P.rose,tagline:"Words carry the world — use them with care and beauty.",
lessons:[
{id:"e1",title:"Phonics: Alphabet & Letter Sounds",age:"4–6",dur:"30 min",
 content:"Every word begins with a sound. 26 letters each have a name AND a sound — sometimes more than one. In Revelation Jesus says: I am the Alpha and the Omega — the first and last letters of the Greek alphabet. All human language participates in the eternal Word of God.",
 vsearch:"Alphablocks full episode BBC phonics",res:"https://www.youtube.com/results?search_query=Alphablocks+full+episode",
 act:"Go on an A-hunt: find 5 things starting with A, then B, then C. Make a tray of objects sorted by starting sound.",
 ff:"In Revelation Jesus says: I am the Alpha and the Omega. The Fathers wrote that all letters, all words, all human language participates in the eternal Word of God who became flesh."},
{id:"e2",title:"Blending CVC Words & Early Reading",age:"5–7",dur:"45 min",
 content:"CVC words: Consonant-Vowel-Consonant: cat, dog, sun, hop. Stretch the sounds (c-a-t) then blend faster until you hear the word. St Basil the Great founded schools for poor children — reading was a Christian gift to the poor long before it was a government programme.",
 vsearch:"Jolly Phonics blending words",res:"https://www.youtube.com/results?search_query=Jolly+Phonics+blending",
 act:"Build 10 CVC words with letter cards. Swap the middle vowel: cat → cot → cut. Race to read them. Find one simple word in a children's Bible and sound it out.",
 ff:"St Basil the Great founded schools attached to his hospital in Caesarea — the first on record to teach literacy to poor children. Reading was a Christian gift to the poor long before it was a government programme."},
{id:"e3",title:"Sight Words: First 100",age:"5–8",dur:"30 min",
 content:"Some words break phonics rules: the, was, said, of. Knowing the first 100 sight words lets a child read 50% of all written English. Memorisation is an ancient holy skill — Orthodox monks memorise entire Psalters by heart.",
 vsearch:"Meet the sight words level 1",res:"https://www.youtube.com/results?search_query=Meet+the+Sight+Words+level+1",
 act:"Make 20 flashcards. Play Salute: hold a card on your forehead, third player calls the word, first to guess their own card wins.",
 ff:"The great memory of the Church is her liturgy — the same words, prayers and chants repeated for 2,000 years. Orthodox children who attend Liturgy regularly memorise vast amounts of sacred text simply by participation."},
{id:"e4",title:"Reading Aloud: Deep & Engaged Reading",age:"All",dur:"30 min daily",
 content:"Reading aloud grows vocabulary faster than any other activity. Choose a book one level above the child's ability. Stop and ask: What do you think happens next? Why did she do that? C.S. Lewis wrote Narnia to clothe Christian truth in story — so children might love Aslan before they met Christ.",
 vsearch:"Storyline Online free read alouds",res:"https://www.storylineonline.net",
 act:"Read one chapter of a classic this week: The Lion the Witch and the Wardrobe, Charlotte's Web, The Hobbit, or Little House in the Big Woods. Draw your favourite scene.",
 ff:"C.S. Lewis believed that a child who loved Aslan would be better prepared to love Christ when they met Him later. The best Christian children's literature does not preach — it shows."},
{id:"e5",title:"Grammar: Nouns, Verbs & Adjectives",age:"6–9",dur:"45 min",
 content:"A noun names a person, place, animal or thing. A verb shows action or being. An adjective describes a noun. Every sentence needs at least one noun and one verb. John 1:1 — In the beginning was the Word (Logos) — a noun that refers to the second Person of the Holy Trinity.",
 vsearch:"Schoolhouse Rock nouns verbs adjectives",res:"https://www.youtube.com/results?search_query=Schoolhouse+Rock+grammar",
 act:"Mad Libs: write a short story with 10 blanks labelled N, V, or ADJ. Ask a sibling to fill them. Read aloud. Then read John 1:1 and identify the nouns.",
 ff:"Shakespeare invented over 1,700 English words we still use: eyeball, lonely, gossip, bedroom, generous, obscene."},
{id:"e6",title:"Story Structure & the Parables of Jesus",age:"7–10",dur:"1 hour",
 content:"Every great story has a Beginning (characters, setting, problem introduced), Middle (conflict deepens, characters tested), and End (resolution, change). The Gospels follow exactly this structure. The Prodigal Son (Luke 15:11-32) is 500 words of perfect storytelling — plan your story with a 3-box storyboard first.",
 vsearch:"story structure for kids beginning middle end",res:"https://www.youtube.com/results?search_query=story+structure+for+kids",
 act:"Write a 1-page story using a 3-box storyboard. Read it aloud to a family member. Then read the Prodigal Son (Luke 15:11-32) and identify the three parts.",
 ff:"Fyodor Dostoevsky was a devout Orthodox Christian. His novels are among the greatest ever written. He wrote: Beauty will save the world."},
{id:"e7",title:"Poetry & the Psalms",age:"6–10",dur:"30 min",
 content:"The Psalms are the oldest continuously sung poetry in the world — 150 Hebrew poems sung in Jewish and Christian worship for 3,000 years. Every human feeling is expressed in the Psalms: joy, grief, anger, fear, gratitude, longing. God gave us these poems to teach us how to speak to Him.",
 vsearch:"A Child's Garden of Verses read aloud",res:"https://www.youtube.com/results?search_query=A+Child%27s+Garden+of+Verses+read+aloud",
 act:"Write an acrostic poem of your own name — each letter begins a line describing you. Then read Psalm 23 aloud as a poem. Which image is your favourite?",
 ff:"The Orthodox Church sings all 150 Psalms every week in monastic communities. The Psalter is the prayer book of the Church given to us by God through the Holy Spirit and the pen of King David."},
{id:"e8",title:"Persuasive Writing & Clear Thinking",age:"8–10",dur:"1 hour",
 content:"Persuasive writing: use PEEL — Point (claim), Evidence (facts/examples), Explanation (why it matters), Link (back to argument). Include a counter-argument and respond to it. The Apostle Paul was one of the greatest persuasive writers in history — his letters are masterclasses in structured argument.",
 vsearch:"persuasive writing for kids PEEL structure",res:"https://www.youtube.com/results?search_query=persuasive+writing+kids+PEEL",
 act:"Write 3 paragraphs arguing that all Orthodox families should learn Greek. Use PEEL. Include one counter-argument and respond to it.",
 ff:"Aristotle described three elements of persuasion in 350 BC: ethos (credibility), pathos (emotion), logos (reason). St Paul uses all three — especially in his defence before King Agrippa (Acts 26)."},

{id:"e9",title:"Compound & Complex Sentences",age:"7–10",dur:"30 min",
 content:"A simple sentence has one independent clause: The dog barked. A compound sentence joins two with a coordinating conjunction: The dog barked and the cat ran. A complex sentence has an independent and a dependent clause: When the dog barked, the cat ran. Varying sentence types makes writing flow naturally.",
 vsearch:"compound and complex sentences for kids",res:"https://www.youtube.com/results?search_query=compound+complex+sentences+kids",
 act:"Write 5 simple sentences about your day. Now combine pairs using 'and', 'but', 'so', 'because', 'when', 'although'. Notice how the meaning shifts with each joining word.",
 ff:"The average English sentence in the King James Bible (1611) is 22 words long. Modern plain-English guides recommend 15-20 words. Shorter sentences aid clarity; longer sentences add rhythm and weight."},
{id:"e10",title:"Apostrophes: Possession & Contraction",age:"7–10",dur:"30 min",
 content:"Apostrophes do two jobs. Contraction: replace missing letters (don't=do not, I've=I have, it's=it is). Possession: show belonging (the dog's bone; the children's books). Trick: 'its' always means belonging. 'It's' always means 'it is'. No exceptions. Test by substituting 'it is' — if it fits, you need the apostrophe.",
 vsearch:"apostrophes for kids possession contraction",res:"https://www.youtube.com/results?search_query=apostrophes+for+kids",
 act:"Edit a paragraph where all apostrophes have been removed. Add them back correctly. Then write 10 possessive phrases and 10 contractions side by side.",
 ff:"The apostrophe was introduced into English printing around 1590 and has caused confusion ever since. The Apostrophe Protection Society monitored public signage for errors for 18 years before disbanding in 2019."},
{id:"e11",title:"Prefixes & Suffixes",age:"7–9",dur:"30 min",
 content:"A prefix goes before a root word: un- (not), re- (again), pre- (before), mis- (wrongly), dis- (apart). A suffix goes after: -ing (happening), -ed (past), -ness (state of), -ful (full of), -less (without), -tion (the act of). One root word plus affixes creates dozens of new words.",
 vsearch:"prefixes and suffixes for kids",res:"https://www.youtube.com/results?search_query=prefixes+suffixes+for+kids",
 act:"Start with 'happy'. Add every prefix and suffix you know. Do the same with 'help', 'care', 'break' and 'joy'. How many words can you build?",
 ff:"The prefix un- appears in over 1,000 English words. Shakespeare used dis- more creatively than any writer before him — he invented dislocate, distasteful, dishearten and dismay."},
{id:"e12",title:"Dictionary & Thesaurus Skills",age:"6–9",dur:"30 min",
 content:"A dictionary gives: spelling, pronunciation, part of speech, definition and word origin. A thesaurus gives synonyms (similar meaning) and antonyms (opposites). Using a thesaurus prevents word repetition and expands vocabulary. But always check the dictionary after — synonyms are rarely perfect substitutes.",
 vsearch:"how to use a dictionary and thesaurus for kids",res:"https://www.youtube.com/results?search_query=dictionary+thesaurus+kids",
 act:"Look up 5 words in a thesaurus. For each, find one synonym that improves a sentence and one that sounds wrong in context. Notice how small word choices change the feel of writing.",
 ff:"Roget's Thesaurus was first published in 1852, compiled by Dr Peter Mark Roget as a private project to improve his own writing. He worked on it for 50 years before publishing at age 73."},
{id:"e13",title:"Homophones & Commonly Confused Words",age:"7–10",dur:"30 min",
 content:"Homophones sound the same but have different spellings and meanings. Their/there/they're. Your/you're. To/two/too. Its/it's. Hear/here. Whole/hole. Where/wear/ware. These cause errors even in adult writing — learning them is a mark of a careful communicator.",
 vsearch:"homophones for kids there their they're",res:"https://www.youtube.com/results?search_query=homophones+for+kids",
 act:"Write one sentence using all three of: there/their/they're. Then all three of: to/two/too. Make them silly sentences so they stick in memory.",
 ff:"English has over 400 pairs of homophones — more than any other major language. This happened partly because English absorbed words from French, Norse and Latin that then evolved to sound like existing English words."},
{id:"e14",title:"Descriptive Writing: Show Don't Tell",age:"7–10",dur:"1 hour",
 content:"'Show don't tell' is the most important rule of creative writing. Instead of telling the reader how a character feels, show it through actions, sensory details and specific images. Don't write 'She was sad' — write 'She sat at the kitchen table, turning her cold mug of tea in both hands, saying nothing.'",
 vsearch:"show don't tell writing for kids",res:"https://www.youtube.com/results?search_query=show+don%27t+tell+writing+kids",
 act:"Rewrite 5 telling sentences as showing descriptions: She was scared. He was excited. The room was messy. The food was delicious. It was very cold outside.",
 ff:"Ernest Hemingway's famous six-word story — 'For sale: baby shoes, never worn' — is the ultimate example of showing through implication. He reportedly said it was his best work."},
{id:"e15",title:"Reading Comprehension: Main Idea & Inference",age:"7–10",dur:"45 min",
 content:"The main idea is what a passage is mostly about — not just the topic, but what the author says about it. Inference means reading between the lines: combining text clues with what you already know to understand something not directly stated. Good readers do both constantly without thinking about it.",
 vsearch:"main idea and inference reading comprehension kids",res:"https://www.youtube.com/results?search_query=main+idea+inference+reading+comprehension",
 act:"Read a 1-page passage. Write: (1) the main idea in one sentence; (2) three supporting details; (3) one inference you made that the author never directly stated.",
 ff:"Researchers found that children explicitly taught inference-making as a skill improve their reading comprehension scores by an average of 40% in just one school year."},
{id:"e16",title:"Letter Writing: Formal & Informal",age:"7–10",dur:"45 min",
 content:"A formal letter (to a stranger or official) uses your address and date, a salutation (Dear Sir/Madam/Name), formal language, and Yours sincerely or Yours faithfully. An informal letter (to a friend or family) can be chatty, use contractions, and end with Love or Cheers. Both are acts of service — taking time to communicate with care.",
 vsearch:"how to write a formal and informal letter kids",res:"https://www.youtube.com/results?search_query=how+to+write+a+letter+for+kids",
 act:"Write one formal letter (to an author, museum or local council) and one informal letter (to a grandparent or cousin). Address an envelope for each.",
 ff:"Before email, the average household sent or received one letter per week. In Jane Austen's time, letters were so expensive that people wrote sideways across the page to use every inch of paper."},
{id:"e17",title:"Paragraphs & Topic Sentences",age:"7–10",dur:"45 min",
 content:"A paragraph is a group of sentences about ONE idea. It begins with a topic sentence stating that idea clearly. Following sentences give details, evidence or examples. The paragraph ends when the idea is complete and a new idea begins. Skilled writers use paragraphs like rooms in a house — each for a different purpose.",
 vsearch:"how to write a paragraph topic sentence kids",res:"https://www.youtube.com/results?search_query=how+to+write+a+paragraph+kids",
 act:"Take a 3-paragraph passage from a library book. Underline each topic sentence. Then write a 3-paragraph piece on 'Why I like [season]' — one paragraph each for weather, activities and food.",
 ff:"The word 'paragraph' comes from Greek para (beside) + graphein (write). Originally it was a symbol in the margin of manuscripts to mark a new section — not a new line."},
{id:"e18",title:"Fiction vs Non-Fiction Text Features",age:"6–9",dur:"30 min",
 content:"Fiction is made-up stories: novels, fairy tales, myths. Non-fiction is real information: encyclopaedias, biographies, instruction manuals, news articles. Non-fiction text features: headings, subheadings, bold words, captions, diagrams, glossaries, indexes. Fiction features: chapters, characters, plot, theme, dialogue.",
 vsearch:"fiction vs non-fiction for kids",res:"https://www.youtube.com/results?search_query=fiction+vs+nonfiction+for+kids",
 act:"Find one fiction book and one non-fiction book on the same topic (e.g. dinosaurs). List 5 differences in how they are organised and written. Which do you prefer reading?",
 ff:"The most borrowed non-fiction books from NZ public libraries are usually cookbooks and gardening books. Children's classics like Charlotte's Web have been borrowed continuously for over 60 years."},
{id:"e19",title:"Diary & Journal Writing",age:"6–10",dur:"20 min daily",
 content:"A diary or journal is a record of your own thoughts, experiences and feelings. Unlike formal writing, it is private and honest. It builds vocabulary, self-reflection and the daily habit of writing. Great writers from Samuel Pepys to Anne Frank kept journals. Date every entry. Write something every day this week.",
 vsearch:"how to write a diary entry for kids",res:"https://www.youtube.com/results?search_query=how+to+write+a+diary+entry+kids",
 act:"Keep a journal for 7 consecutive days. Each day: one thing that happened, one thing you felt, one question you are wondering about. At the end, re-read all 7 entries and write what surprised you.",
 ff:"Samuel Pepys kept a diary from 1660-1669 and it is still the best eyewitness account of the Great Fire of London (1666). He wrote 1.25 million words in shorthand."},
{id:"e20",title:"Book Review Writing",age:"7–10",dur:"45 min",
 content:"A book review summarises and evaluates a book. Structure: opening hook, brief plot summary (no spoilers!), what you liked and why, what could be better, rating and recommendation. A review is personal opinion backed by specific evidence from the text — your voice is welcome here.",
 vsearch:"how to write a book review for kids",res:"https://www.youtube.com/results?search_query=how+to+write+a+book+review+kids",
 act:"Write a review of the last book you read. Use STOP structure: Summary, Thoughts, Opinion, Persuade others. Make it lively enough that someone who has not read it wants to.",
 ff:"Goodreads has over 150 million book reviews written by ordinary readers. Studies show peer reviews influence reading choices more than professional critic reviews by a ratio of 3 to 1."},
{id:"e21",title:"Writing a Factual Report",age:"8–10",dur:"1.5 hours",
 content:"A factual report is organised into sections: Introduction (what the report is about), Description (key facts and features), Context/Habitat/Location, and Conclusion (summary or interesting fact). It uses present tense, third person, technical vocabulary, and no personal opinion. Reports are non-fiction at its most disciplined.",
 vsearch:"how to write a factual report for kids",res:"https://www.youtube.com/results?search_query=how+to+write+a+factual+report+kids",
 act:"Write a one-page report on an animal, plant or place of your choice. Use at least 4 sections with headings. Include a labelled diagram. Cite one source.",
 ff:"Scientists publish reports called papers in journals. The longest single scientific paper ever submitted was over 900 pages. Clear writing is as important as correct facts."},
{id:"e22",title:"Figurative Language: Simile, Metaphor, Personification",age:"8–10",dur:"45 min",
 content:"Simile: comparing two things using 'like' or 'as' (the moon was like a silver coin). Metaphor: saying one thing IS another (the moon was a silver coin). Personification: giving human qualities to non-human things (the wind howled with fury; the stars wept). These tools make writing vivid and memorable.",
 vsearch:"similes metaphors personification for kids",res:"https://www.youtube.com/results?search_query=similes+metaphors+personification+kids",
 act:"Find 5 examples of figurative language in a book you are reading. Then write a description of a storm using all three devices — simile, metaphor and personification.",
 ff:"The Bible contains over 1,500 similes and metaphors. 'The Lord is my shepherd' (Psalm 23) is one of history's most famous metaphors — used for 3,000 years and still powerful."},
{id:"e23",title:"Editing & Proofreading",age:"7–10",dur:"30 min",
 content:"Editing improves overall writing — does it make sense? Is it interesting? Is it in the right order? Proofreading fixes surface errors — spelling, grammar, punctuation. Professional writers separate these stages. Proofread by reading slowly, reading aloud, and using a ruler under each line so your eyes do not skip ahead.",
 vsearch:"editing and proofreading writing for kids",res:"https://www.youtube.com/results?search_query=editing+proofreading+kids+writing",
 act:"Take a piece of your own writing from last week. First edit (content), then proofread (accuracy). Count how many improvements you find. Swap with a sibling for peer-editing.",
 ff:"J.K. Rowling wrote the first Harry Potter book longhand in coffee shops. Her editor cut many scenes from the final manuscript. Good editing is invisible — you only notice when it is absent."},
{id:"e24",title:"Oral Presentation Skills",age:"7–10",dur:"45 min",
 content:"Speaking clearly and confidently is as important as writing. Key skills: make eye contact with your audience; speak slowly and clearly; use pauses for emphasis; know your material so you do not just read from a page; vary your volume and tone to keep listeners engaged. St John Chrysostom was called Golden Mouth because of his extraordinary preaching.",
 vsearch:"oral presentation skills for kids public speaking",res:"https://www.youtube.com/results?search_query=oral+presentation+skills+kids",
 act:"Prepare a 2-minute talk on any topic you know well. Practise alone, then deliver it to your family. Ask for one thing you did well and one thing to improve.",
 ff:"In ancient Athens, the greatest speakers were public heroes. Demosthenes overcame a stammer by practising speeches with pebbles in his mouth while walking uphill into the wind."},
{id:"e25",title:"The History of the English Language",age:"8–10",dur:"45 min",
 content:"English began as Anglo-Saxon (~450 AD). Vikings added Norse words. The Normans (1066) added French. Latin and Greek came through the Church and science. Today English has over 600,000 words — the most of any language. About 60% come from Latin or French, which is why scientific and legal English sounds different from everyday speech.",
 vsearch:"history of English language for kids",res:"https://www.youtube.com/results?search_query=history+of+English+language+kids",
 act:"Find one example each of English words from Old English (bread, dog, water), French (beef, justice, beauty), Latin (library, education), Norse (sky, egg, window).",
 ff:"'Beef' comes from French (boeuf) and 'cow' from Old English (cu) — because Norman lords ate the meat and Anglo-Saxon serfs raised the animals. The same split gives us pig/pork, sheep/mutton, deer/venison."},
{id:"e26",title:"Conjunctions: Connecting Ideas",age:"6–9",dur:"30 min",
 content:"Coordinating conjunctions (FANBOYS: For, And, Nor, But, Or, Yet, So) join equal ideas. Subordinating conjunctions (because, although, when, if, while, since, unless, before, after) join a main clause to a dependent clause. Choosing the right conjunction completely changes the relationship between two ideas.",
 vsearch:"conjunctions for kids coordinating subordinating",res:"https://www.youtube.com/results?search_query=conjunctions+for+kids",
 act:"Take 10 pairs of short sentences and combine them using different conjunctions each time. Notice how 'and' vs 'but' vs 'because' vs 'although' changes the meaning completely.",
 ff:"The Schoolhouse Rock conjunction song (Conjunction Junction, what's your function?) was released in 1973 and is still used in American classrooms over 50 years later because it is so effective for memory."},
{id:"e27",title:"Reading Different Text Types",age:"7–10",dur:"30 min",
 content:"Different texts have different purposes, audiences and structures. News articles: inverted pyramid (most important first). Recipes: numbered steps with precise measurements. Instructions: ordered imperative verbs (cut, mix, stir). Advertisements: persuasive, emotional language. Recognising the text type helps you read it correctly and write it well.",
 vsearch:"different text types for kids",res:"https://www.youtube.com/results?search_query=different+text+types+for+kids",
 act:"Collect one example of 5 different text types from around your home (recipe, news article, advertisement, instructions, story). Compare: purpose, audience, tone, structure.",
 ff:"The oldest surviving piece of writing in English is Beowulf — an epic poem written around 700-1000 AD in Old English. Fewer than 10% of modern English speakers can read it without translation."},
{id:"e28",title:"Creative Writing: The Unexpected Twist",age:"8–10",dur:"1 hour",
 content:"A twist ending surprises the reader by revealing something that reframes everything that came before. The best twists are both surprising AND inevitable — the clues were there all along. Plan your twist first, then plant clues in the story. Examples: the kind stranger was the villain; the adventure was a dream.",
 vsearch:"creative writing twist ending for kids",res:"https://www.youtube.com/results?search_query=creative+writing+twist+ending+kids",
 act:"Write a short story (1-2 pages) with a twist ending. Plant at least 2 clues for the reader. Read it aloud and see if your audience was surprised and whether the twist felt fair.",
 ff:"O. Henry wrote 'The Gift of the Magi' in one sitting on Christmas Eve 1905. Its twist ending is considered a perfect example of the form and has been in print ever since."},

{id:"e29",title:"Alliteration, Rhythm & Sound Devices",age:"7–10",dur:"30 min",
 content:"Alliteration: repeating the same starting sound (seven slippery silver salmon). Onomatopoeia: words that sound like what they mean (crash, buzz, squelch, hiss). Assonance: repeating vowel sounds (the light of the fire is a sight). These devices make writing musical and memorable. The Psalms of David are full of all three — even translated from Hebrew.",
 vsearch:"alliteration onomatopoeia sound devices for kids",res:"https://www.youtube.com/results?search_query=alliteration+onomatopoeia+for+kids",
 act:"Write a paragraph about a thunderstorm using at least 5 examples of onomatopoeia and 3 of alliteration. Read it aloud — does it sound like a storm?",
 ff:"Tolkien was a professor of Old English and used alliteration deliberately throughout The Lord of the Rings. The ancient English poem Beowulf uses alliteration in every single line — it was the defining feature of Old English poetry for 600 years."},
{id:"e30",title:"Myths, Legends & Fables",age:"6–10",dur:"45 min",
 content:"A myth explains why the world is the way it is (why the sky is blue, how fire came to humans). A legend is a story about a real or possibly real person, often exaggerated over time. A fable is a short story with animal characters that teaches a moral (Aesop's Fables — the tortoise and the hare, the boy who cried wolf). All three traditions appear in Greek, Maori, and biblical literature.",
 vsearch:"myths legends fables for kids difference",res:"https://www.youtube.com/results?search_query=myths+legends+fables+for+kids",
 act:"Find one example each of a myth (Maui fishing up NZ, or Genesis 1), a legend (St George and the dragon), and a fable (Aesop). Write the key features of each side by side.",
 ff:"The earliest written fables are from ancient Sumer (modern Iraq), over 4,000 years old. Aesop — who gave the Western world its most famous fables — was a Greek slave living around 620-564 BC. His stories were first written down approximately 200 years after his death."},
{id:"e31",title:"Writing Instructions: Procedural Texts",age:"7–10",dur:"30 min",
 content:"A procedural text tells you how to do something in a specific sequence. Features: title (what you will make/do), materials list (what you need), numbered steps (in order), imperative verbs (cut, mix, stir, press), precise language (no 'some' — use exact measurements). Recipes, DIY guides, science experiments and liturgical rubrics are all procedural texts.",
 vsearch:"procedural writing instructions for kids",res:"https://www.youtube.com/results?search_query=procedural+writing+instructions+for+kids",
 act:"Write a procedural text for making your bed, making toast, or tying your shoelaces. Give it to someone who has never done it before. Follow it exactly. What did you miss?",
 ff:"The rubrics in an Orthodox service book (the Typikon) are among the most precise procedural texts ever written — specifying exactly which candles to light, when to bow, which door to open, what to chant, and in what tone. They have guided worship precisely for over a thousand years."},
{id:"e32",title:"Vocabulary Building: Context Clues",age:"7–10",dur:"30 min",
 content:"When you encounter an unfamiliar word in reading, you can often work out its meaning from context clues: definition clues (the word followed by a definition), synonym clues (a familiar word nearby with similar meaning), contrast clues (an opposite nearby), and example clues (examples that hint at meaning). This is how skilled readers expand their vocabulary naturally.",
 vsearch:"context clues vocabulary for kids",res:"https://www.youtube.com/results?search_query=context+clues+vocabulary+for+kids",
 act:"Find 5 unfamiliar words in a book you are reading. Use context clues to guess each meaning. Check in a dictionary. How accurate were your guesses?",
 ff:"The average person learns about 1,000 new words per year through reading. A child who reads for 20 minutes per day encounters approximately 1.8 million words per year — dramatically more than a child who reads for just 5 minutes."},
{id:"e33",title:"Newspaper & News Reports",age:"8–10",dur:"45 min",
 content:"A news report answers the Five Ws: Who, What, When, Where, Why (and How). It uses the inverted pyramid structure: most important information first, less important details later. This is so editors can cut from the bottom without losing key facts. News reports use the third person, past tense, and precise quotes. They are objective — the reporter's opinion does not appear.",
 vsearch:"how to write a news report for kids",res:"https://www.youtube.com/results?search_query=how+to+write+a+news+report+for+kids",
 act:"Write a news report about something that happened in your family or community this week. Use the Five Ws structure. Include one direct quote (from a real person, with permission). Give it a headline.",
 ff:"The world's oldest surviving newspaper is Ordinari Post Tijender, published in Sweden from 1645. The first newspaper in New Zealand was the New Zealand Gazette and Britannia Spectator, published in 1840 — the same year as the Treaty of Waitangi."},
{id:"e34",title:"Shakespeare: An Introduction",age:"8–10",dur:"45 min",
 content:"William Shakespeare (1564-1616) wrote 37 plays and 154 sonnets. He invented over 1,700 words still in use: bedroom, lonely, generous, eyeball, gossip, bedroom, generous. His themes — jealousy, ambition, love, betrayal, redemption — come directly from the Bible and the human heart. The Orthodox Church Father St John Chrysostom, the playwright, and the shepherd King David all shared the same subject: the human soul.",
 vsearch:"Shakespeare introduction for kids beginners",res:"https://www.youtube.com/results?search_query=Shakespeare+introduction+for+kids",
 act:"Read a children's retelling of A Midsummer Night's Dream or The Tempest. Find three words or phrases from Shakespeare that are still used today. Discuss: what does it tell us that Shakespeare's stories are still performed 400 years later?",
 ff:"Shakespeare's plays have been translated into every major language and are performed more often than those of any other playwright. They have never gone out of print since 1623. C.S. Lewis said that a man who has not read Shakespeare is simply less fully human."},
{id:"e35",title:"Writing Autobiography & Personal Narrative",age:"7–10",dur:"1 hour",
 content:"An autobiography is the story of your own life written by yourself. A personal narrative is a true story from your own experience. Both use first person (I), past tense, vivid sensory details, and show the writer's thoughts and feelings. They are honest, specific and personal. The Desert Fathers told their own stories as teaching tools — personal narrative is an ancient form.",
 vsearch:"autobiography and personal narrative writing for kids",res:"https://www.youtube.com/results?search_query=autobiography+personal+narrative+writing+kids",
 act:"Write a 1-2 page personal narrative about a day or event that changed you in some way — even something small. Use all five senses. Show your thoughts and feelings. Read it aloud to your family.",
 ff:"The Confessions of St Augustine (397 AD) is the first autobiography in Western literature — a direct address to God in which Augustine recounts his sinful life and conversion. It is still in print after 1,600 years and is one of the most widely read books ever written."},
{id:"e36",title:"Year-End Celebration: Our Writing Portfolio",age:"All",dur:"2 hours",
 content:"A writing portfolio is a curated collection of your best work over a period of time. Choosing what to include requires judgement: what shows your growth? What are you proudest of? What was most challenging? A portfolio introduction explains your choices and reflects on what you have learned. This is assessment as celebration — looking back with gratitude.",
 vsearch:"writing portfolio reflection for kids",res:"https://www.youtube.com/results?search_query=writing+portfolio+reflection+for+kids",
 act:"Select your 5 best pieces of writing from this year. Write a one-paragraph introduction for each, explaining why you chose it. Write a final reflection: what kind of writer were you at the start of the year? What kind of writer are you now?",
 ff:"St John Chrysostom said: The person who knows how to speak and write well, and uses those gifts well, performs an act of worship. Our words — written and spoken — can be offered to God as liturgy, as service, as love."},
]},
{id:"sports",name:"Sports Science & Nutrition",emoji:"⚽",color:P.ochre,tagline:"The body is a temple — steward it with wisdom.",
lessons:[
{id:"sp1",title:"The Healthy Plate & Orthodox Fasting",age:"4–8",dur:"30 min",
 content:"A balanced plate: ½ vegetables and fruit, ¼ protein, ¼ whole-grain carbohydrates, plus dairy on the side. The Orthodox Church has a profound tradition of fasting — abstaining from meat, dairy and oil on Wednesdays (betrayal) and Fridays (Crucifixion) and during four major fasting seasons each year.",
 vsearch:"healthy eating food groups kids Free School",res:"https://www.youtube.com/results?search_query=healthy+eating+food+groups+kids",
 act:"Draw today's lunch as a plate diagram. Does it match the healthy plate? Research: what foods are allowed on an Orthodox fast day? Plan a complete, nutritious and delicious fast-day meal.",
 ff:"The Desert Fathers fasted so strictly some ate only once every two or three days — yet lived to extreme old age. St Antony of Egypt lived to 105. Moderate fasting has significant health benefits confirmed by modern science."},
{id:"sp2",title:"Macronutrients: Carbs, Protein & Fats",age:"7–10",dur:"45 min",
 content:"Carbohydrates: quick energy (bread, fruit, rice). Protein: building material (meat, eggs, dairy, legumes). Fats: slow energy, brain function (nuts, avocado, fish, olive oil). All three are essential — the problem is always imbalance. Christ chose bread and wine for the Eucharist — the most basic human foods.",
 vsearch:"macronutrients for kids Khan Academy",res:"https://www.youtube.com/results?search_query=macronutrients+for+kids",
 act:"Look at nutrition labels on 5 foods. Which is highest in protein? In carbs? In fat? Research: what did the early Desert Fathers eat? (Mostly bread, water, salt — sometimes olives and dates.)",
 ff:"The Eucharist — Holy Communion — is bread and wine. Christ chose the most basic human foods to be the vehicles of His Body and Blood. Food has always been sacred in the Christian tradition."},
{id:"sp3",title:"Muscles, Movement & the Incarnation",age:"5–9",dur:"30 min",
 content:"The human body has over 600 muscles. Walking uses ~200 muscles simultaneously. The Orthodox Church teaches that the body was created good and will be resurrected. The Incarnation — God becoming flesh — shows that the body is sacred. St Irenaeus: The glory of God is a human being fully alive.",
 vsearch:"muscular system kids Free School",res:"https://www.youtube.com/results?search_query=muscular+system+kids",
 act:"10-minute circuit: 20 star jumps, 10 push-ups, 10 squats, 10 lunges, 30-second plank, 20 high knees. Record times. Repeat weekly and compare.",
 ff:"The Church Fathers opposed Gnostic teaching that the body is evil. St Irenaeus wrote: The glory of God is a human being fully alive. Physical health and spiritual health are deeply connected."},
{id:"sp4",title:"Heart, Lungs & the Breath of Life",age:"6–10",dur:"45 min",
 content:"The heart pumps blood in two loops: to the lungs (oxygen in, CO₂ out) and to the body (oxygen delivered). The Jesus Prayer is synchronised with the breath: breathe in — Lord Jesus Christ Son of God; breathe out — have mercy on me a sinner. The breath itself becomes prayer.",
 vsearch:"how heart works for kids SciShow",res:"https://www.youtube.com/results?search_query=how+heart+works+kids",
 act:"Find your pulse. Count 15 sec × 4 = resting heart rate. Run on the spot 2 minutes. Measure again. Time recovery. Also practise slow breathing (4 counts in, hold 4, 4 counts out).",
 ff:"The Jesus Prayer — Lord Jesus Christ, Son of God, have mercy on me, a sinner — is synchronised with breathing. Hesychast monks have practised this prayer-with-breath for over 1,000 years."},
{id:"sp5",title:"Core Sports Skills",age:"5–10",dur:"1 hour",
 content:"Throw: step with opposite foot, rotate hips, follow through. Catch: soft hands, watch the ball in. Kick: plant non-kicking foot beside ball, kick with laces, follow through. Run: push off ball of foot, drive knees forward. St Paul: I have fought the good fight, I have finished the race, I have kept the faith.",
 vsearch:"PE with Joe fundamental movement skills kids",res:"https://www.youtube.com/results?search_query=PE+with+Joe+movement+skills",
 act:"4-station circuit: throw at a wall target, kick into a chalk goal, run 30 m sprint, catch a fly ball. Score each station. Improve weekly.",
 ff:"St Paul used athletic images constantly: Run in such a way as to get the prize (1 Cor 9:24). The spiritual life is itself an athletic contest requiring training, discipline and endurance."},
{id:"sp6",title:"Hydration, Sugar & Fasting Wisdom",age:"6–10",dur:"30 min",
 content:"Drink water before you feel thirsty. Children need 1–2 L daily. A 600 mL fizzy drink has ~16 teaspoons of sugar. The WHO recommends max 6 teaspoons of added sugar per day for children.",
 vsearch:"how sugar affects the brain TED-Ed",res:"https://www.youtube.com/results?search_query=how+sugar+affects+brain",
 act:"Read labels on 5 drinks at home. Convert sugar grams to teaspoons (÷4). Which is the worst? Make homemade fruit water. Try going one day drinking only water.",
 ff:"The Desert Fathers taught that self-control in eating and drinking leads to self-control in all areas of life. Modern science confirms that sugar addiction activates the same brain pathways as other addictive substances."},
{id:"sp7",title:"Sleep as Healing & Prayer",age:"All",dur:"30 min",
 content:"Children 6–12 need 9–12 hours nightly. During deep sleep: growth hormone is released, the immune system repairs, the brain consolidates all learning. Every Orthodox evening prayer asks God to grant peaceful, sinless sleep and a good rising. Sleep is a gift and a trust from God.",
 vsearch:"why we sleep TED-Ed kids",res:"https://www.youtube.com/results?search_query=why+we+sleep+TED-Ed",
 act:"Sleep diary for 7 days: record bedtime, wake time, screen time before bed, and how you feel out of 10. Begin and end each day with a short prayer. Notice the pattern.",
 ff:"Rising from sleep to pray mirrors the risen Christ who rose in the night between Saturday and Sunday. Every morning is a small resurrection."},
{id:"sp8",title:"Teamwork, Fair Play & Manaakitanga",age:"5–10",dur:"45 min",
 content:"Good sportsmanship: help fallen opponents up, cheer others' good plays, lose with grace, win without boasting. The Māori value of manaakitanga (hospitality, respect, care) and the Christian virtue of humility point to the same truth: your conduct should uplift everyone around you.",
 vsearch:"sportsmanship for kids",res:"https://www.youtube.com/results?search_query=sportsmanship+for+kids",
 act:"Play a team game. After every good play — yours or theirs — say something positive. Count your positive comments. After the game, shake hands and give one genuine compliment to each person.",
 ff:"St Paul: Run in such a way as to get the prize (1 Cor 9:24). The ancient Olympics at Corinth were the image Paul used. He urged Christians to train as seriously for the spiritual life as athletes train for competitions."},

{id:"sp9",title:"The Digestive System",age:"7–10",dur:"45 min",
 content:"Food's journey: mouth (chewing and saliva starts digestion) to oesophagus (tube to stomach, about 10 seconds) to stomach (acid breaks down food, 2-4 hours) to small intestine (nutrients absorbed, 2-6 hours, 6-7 metres long!) to large intestine (water absorbed, up to 59 hours) to exit. The digestive system is essentially a 9-metre tube.",
 vsearch:"digestive system for kids Free School",res:"https://www.youtube.com/results?search_query=digestive+system+for+kids+Free+School",
 act:"Act out the digestive system: the family walks through a tunnel (oesophagus), squeezes into a bag (stomach), walks a very long path (small intestine). Then eat a meal mindfully, chewing each bite 20 times.",
 ff:"Your small intestine would be 6-7 metres long if stretched out. Its lining has tiny projections (villi) that increase absorptive surface area to the size of a tennis court. The gut contains more bacteria than there are cells in your entire body."},
{id:"sp10",title:"Stretching, Flexibility & Injury Prevention",age:"6–10",dur:"30 min",
 content:"Warm up before exercise (5 min light movement), stretch after (when muscles are warm). Static stretch: hold 20-30 seconds without bouncing. Key stretches: hamstring, quadriceps, calf, hip flexor, shoulder, chest. Flexibility reduces injury risk and improves performance. The human body was designed for movement — stillness causes stiffness.",
 vsearch:"yoga for kids flexibility Cosmic Kids Yoga",res:"https://www.youtube.com/results?search_query=Cosmic+Kids+Yoga+flexibility",
 act:"Morning stretch routine: 10 stretches held 20 seconds each equals 4 minutes total. Do every morning for a week. Can you touch your toes by the end of the week?",
 ff:"The tendons in your hands that enable fine finger movement are controlled by muscles in your forearm — that is why gripping something tightly for a long time (like writing) makes your forearm ache, not your fingers."},
{id:"sp11",title:"Vitamins, Minerals & Superfoods",age:"7–10",dur:"30 min",
 content:"Key vitamins: Vitamin C (citrus, kiwifruit — immunity and collagen), Vitamin D (sunlight, fish — bones), Iron (red meat, spinach — oxygen transport), Calcium (dairy, greens — bones and teeth), Zinc (meat, seeds — immunity and growth), Omega-3 (oily fish, walnuts — brain). Each vitamin does a specific job — deficiency causes specific symptoms.",
 vsearch:"vitamins and minerals for kids Learn Bright",res:"https://www.youtube.com/results?search_query=vitamins+minerals+for+kids",
 act:"Look up: what vitamins and minerals does one kiwifruit contain? How many of your daily needs does one kiwi meet? Compare to an orange. Make a nutrient comparison chart.",
 ff:"Kiwifruit has more Vitamin C per 100g than an orange. NZ kiwifruit — originally called 'Chinese gooseberry' — was renamed for American export marketing in 1959. The naming was a business decision that created a multi-billion-dollar industry."},
{id:"sp12",title:"Water Safety & Swimming",age:"5–10",dur:"1 hour",
 content:"NZ has the highest drowning rate per capita of any developed country. Water safety rules: never swim alone, know your limits, float to survive (FLOAT: Feet up, Lean back, Open your chest, Arms out, Till help arrives). Rip currents: do not fight them, float, swim parallel to shore and then angle back to the beach.",
 vsearch:"water safety for kids Surf Life Saving NZ",res:"https://www.youtube.com/results?search_query=water+safety+for+kids+Surf+Life+Saving+NZ",
 act:"Practise floating on your back in a pool or safe water. Try star float, face float, and treading water. Timed: how long can you float without moving?",
 ff:"Surf Life Saving NZ estimates that basic water competency skills (floating, treading water, self-rescue) could prevent over 60% of NZ drowning deaths — many of which involve people who considered themselves strong swimmers."},
{id:"sp13",title:"Bones, Joints & Healthy Posture",age:"6–10",dur:"30 min",
 content:"Adult humans have 206 bones. Children have about 270 — many fuse as we grow. Bones are living tissue: they constantly rebuild themselves, require calcium and Vitamin D, and respond to stress by becoming stronger (weight-bearing exercise builds bone). Posture: the spine has natural curves — excessive screen-hunching creates harmful straightening or over-curving.",
 vsearch:"bones and joints for kids SciShow Kids",res:"https://www.youtube.com/results?search_query=bones+joints+for+kids+SciShow",
 act:"Practise standing against a wall with the back of your head, shoulder blades, buttocks and heels touching the wall. This is good posture. Walk away and try to maintain it for 5 minutes. How did it feel?",
 ff:"Bone is one of the strongest natural materials known. Weight for weight, cortical (compact) bone is stronger than steel in tension. Yet it is also light, self-repairing, and adapts to the loads placed on it throughout your life."},
{id:"sp14",title:"Energy Systems: Why You Get Tired",age:"8–10",dur:"30 min",
 content:"The body uses three energy systems: ATP-PC system (explosive, 0-10 seconds — sprinting, jumping), Glycolytic system (lactic acid, 10-120 seconds — 400m run, swimming hard), Aerobic system (oxygen, 2+ minutes — long runs, cycling, all day farming). Different sports train different systems. Orthodox fasting reduces caloric intake, changing how all three systems operate.",
 vsearch:"energy systems for kids sports science",res:"https://www.youtube.com/results?search_query=energy+systems+for+kids+sports+science",
 act:"Test all three systems: Sprint 30m as fast as possible (ATP-PC). Run 400m as fast as possible (Glycolytic — notice the burn). Walk for 20 minutes without stopping (Aerobic). How did each feel?",
 ff:"Elite marathon runners can maintain their aerobic pace for 2+ hours. Elite sprinters use their ATP-PC system for under 10 seconds. Training is specific — marathon training makes you a better marathoner, not a better sprinter."},
{id:"sp15",title:"Sports & Character: Failure & Resilience",age:"7–10",dur:"30 min",
 content:"Every great athlete has failed more times than they have succeeded. Michael Jordan was cut from his high school basketball team. J.K. Rowling's Harry Potter was rejected by 12 publishers. St Paul was beaten, imprisoned and shipwrecked. Character is built in failure, not success. The Orthodox ascetic tradition calls this struggle: agon (from which we get 'agony').",
 vsearch:"resilience and failure for kids sport character",res:"https://www.youtube.com/results?search_query=resilience+failure+kids+sport+character",
 act:"Write about a time you failed at something. What happened? What did you learn? Did you try again? How does your faith help you handle failure?",
 ff:"St Paul used the Greek word agon (struggle, contest) for both athletic competition and the Christian spiritual life. The word 'agony' in English comes from this — the Christian life involves genuine struggle, not comfortable ease."},
{id:"sp16",title:"NZ Sports Heritage & Outdoor Culture",age:"6–10",dur:"30 min",
 content:"New Zealand has a proud sporting culture built on the outdoors: rugby (All Blacks, first team to win three Rugby World Cups), cricket, netball (Silver Ferns), sailing (America's Cup), mountaineering (Sir Edmund Hillary, first to summit Everest 1953), rowing, cycling. NZ's outdoor culture also includes: hunting, fishing, tramping, surfing and ski-ing.",
 vsearch:"NZ sports heritage All Blacks Edmund Hillary",res:"https://www.youtube.com/results?search_query=NZ+sports+heritage+All+Blacks+Edmund+Hillary",
 act:"Research one NZ sporting hero or achievement. Write a one-paragraph biography. What values did they demonstrate? How did they represent NZ to the world?",
 ff:"Sir Edmund Hillary said after being the first human to stand on the summit of Mount Everest (29 May 1953): We knocked the bastard off. He later described his greatest achievement not as climbing Everest but as building schools and hospitals for the Sherpa people of Nepal."},
{id:"sp17",title:"Breathing, Focus & the Athletic Mind",age:"7–10",dur:"30 min",
 content:"Athletic performance depends as much on the mind as the body. Key mental skills: breathing control (slow deep breathing reduces anxiety and heart rate), visualisation (mentally rehearsing a skill improves performance), focus (narrowing attention to the present moment), positive self-talk (thoughts affect physiology). The Jesus Prayer, prayed with the breath, trains all of these simultaneously.",
 vsearch:"mental skills for young athletes breathing focus",res:"https://www.youtube.com/results?search_query=mental+skills+young+athletes+breathing+focus",
 act:"Before your next sport or physical activity, spend 2 minutes in slow breathing (4 counts in, hold 2, 4 counts out). Notice whether your performance is different. Practise the Jesus Prayer with your breath.",
 ff:"Studies on Olympic athletes show that mental rehearsal activates the same neural pathways as physical rehearsal. Athletes who visualise their performance improve nearly as much as those who physically practise — the brain does not fully distinguish between imagined and real movement."},
{id:"sp18",title:"Seasonal Eating & the Orthodox Calendar",age:"8–10",dur:"30 min",
 content:"The Orthodox Church's fasting calendar requires approximately 180 fast days per year — no meat, dairy, fish, oil or wine on Wednesdays, Fridays, and during the four major fasting seasons. This naturally produces seasonal and plant-based eating during specific times. Modern nutritional science confirms that plant-heavy diets during seasonal periods are associated with better health outcomes.",
 vsearch:"Orthodox fasting health benefits nutrition",res:"https://www.youtube.com/results?search_query=Orthodox+fasting+health+benefits+nutrition",
 act:"Plan one week of meals following the Orthodox fasting calendar: Wednesday and Friday are fast days (plant-based only). Saturday and Sunday are feast days. What does your shopping list look like?",
 ff:"Studies comparing the health outcomes of populations that observe traditional Orthodox fasting (such as Greek monastics and devout laypeople) with matched non-fasting populations consistently show lower rates of cardiovascular disease, diabetes and certain cancers. The diet and its seasonality appear to be significant factors."},
{id:"sp19",title:"First Aid Revision: DRSABCD & Emergency Response",age:"7–10",dur:"45 min",
 content:"DRSABCD: Danger (check for danger to yourself first), Response (is the person conscious?), Send for help (call 111), Airway (tilt head back, lift chin), Breathing (look, listen, feel for 10 seconds), CPR (30 compressions, 2 breaths), Defibrillator (use if available). CPR: push down 5-6 cm, 100-120 times per minute. Real emergencies require real training.",
 vsearch:"DRSABCD first aid for kids St John NZ",res:"https://www.youtube.com/results?search_query=DRSABCD+first+aid+for+kids+St+John",
 act:"Practise the DRSABCD sequence from memory on a stuffed animal. Practise CPR hand position and depth on a firm pillow (not a person). Consider enrolling in a formal St John first aid course.",
 ff:"Bystander CPR (started before the ambulance arrives) more than doubles the survival rate from cardiac arrest outside hospital. Every person who learns CPR is potentially the most important person in the room in an emergency. St John NZ offers community CPR courses."},
{id:"sp20",title:"Building Physical Habits for Life",age:"All",dur:"30 min",
 content:"Physical health is built by consistent small habits, not occasional heroic efforts. Daily minimum: 60 minutes of movement for children aged 5-17 (any activity counts), 30 minutes for adults. Sleep: 9-12 hours for children 6-12. Water: 1-2 L per day. Sunlight: 20-30 minutes per day for Vitamin D. The body is a temple — regular simple care is stewardship.",
 vsearch:"physical habits for kids daily movement health",res:"https://www.youtube.com/results?search_query=physical+habits+for+kids+daily+movement",
 act:"Design a simple daily health plan for your family: movement (type and duration), sleep target, water intake, sunlight exposure. Track it for one week using a simple log. What is easiest? Hardest?",
 ff:"St Paul wrote: Physical training is of some value, but godliness has value for all things (1 Timothy 4:8). He did not say physical training has no value — he said it has some value. The Orthodox tradition affirms that caring for the body is a spiritual duty, not a vanity."},

{id:"sp21",title:"Nutrition Labels: Reading What You Eat",age:"7–10",dur:"30 min",
 content:"Nutrition labels show: serving size (check how many servings are in the package — most people eat 2-3 servings thinking it is one), energy (kilojoules — 1 calorie = 4.18 kJ), protein, total fat (and saturated fat separately), carbohydrates (total and sugars separately), dietary fibre (aim for 25-30g per day), and sodium (salt — aim for under 2,000mg per day). The ingredients list is in order of weight — the first ingredient is the largest.",
 vsearch:"how to read nutrition labels for kids",res:"https://www.youtube.com/results?search_query=how+to+read+nutrition+labels+for+kids",
 act:"Compare the nutrition labels of 5 breakfast cereals. Which has the most sugar per serving? The most fibre? The most protein? Rank them from most to least nutritious. Were you surprised by the results?",
 ff:"The first mandatory nutrition labelling laws were introduced in the USA in 1990. Before that, food companies could make almost any health claim they wanted with no supporting evidence. Knowing how to read a nutrition label is one of the most practically useful adult skills a child can learn."},
{id:"sp22",title:"Interval Training & Circuit Workouts",age:"8–10",dur:"45 min",
 content:"Interval training alternates between high-intensity effort and rest or lower-intensity recovery. This trains the cardiovascular system more efficiently than steady-state exercise alone. A simple circuit: 30 seconds of hard effort, 30 seconds rest, repeat for 10-15 rounds. Exercises: jumping jacks, high knees, burpees, mountain climbers, squat jumps, push-ups. This is how athletes train in every sport.",
 vsearch:"interval training circuit workout for kids at home",res:"https://www.youtube.com/results?search_query=interval+training+circuit+workout+for+kids",
 act:"Design your own 10-minute interval circuit: choose 5 exercises, 40 seconds each, 20 seconds rest, 2 rounds. Do it three times this week. Record your heart rate before, during and after.",
 ff:"Interval training was developed in the 1930s by Finnish middle-distance runner Paavo Nurmi, who won 9 Olympic gold medals. He trained with precise interval repetitions on a track, recorded on a stopwatch he carried while running. Modern sports science has simply formalized what he discovered empirically."},
{id:"sp23",title:"The Olympic Games: Ancient & Modern",age:"7–10",dur:"30 min",
 content:"The ancient Olympics began in 776 BC at Olympia, Greece, dedicated to Zeus. Events: running, jumping, discus, javelin, wrestling, pankration, chariot racing. Athletes competed in the nude (gymnos = naked — giving us gymnasium). A wreath of olive leaves was the only prize. Theodosius I closed them in 393 AD as a pagan festival. Pierre de Coubertin revived them in Athens in 1896. NZ has been competing since 1908.",
 vsearch:"ancient and modern Olympic Games for kids",res:"https://www.youtube.com/results?search_query=ancient+modern+Olympic+Games+for+kids",
 act:"Research NZ's history at the Olympic Games. How many gold medals has NZ won? In which sports? Who is NZ's most decorated Olympian? Make a timeline of NZ at the Olympics.",
 ff:"St Paul used the Olympic Games (held at Corinth in his time, not just at Olympia) as a central metaphor for the Christian life: Do you not know that in a race all the runners run, but only one gets the prize? Run in such a way as to get the prize (1 Corinthians 9:24). The Corinthians knew exactly what he meant."},
{id:"sp24",title:"Food Preparation & Kitchen Skills for Health",age:"7–10",dur:"45 min",
 content:"Research consistently shows that people who cook most of their own meals eat more vegetables, consume less sugar and salt, spend less money on food, and have better long-term health outcomes than those who rely on processed or restaurant food. Cooking is not just a practical skill — it is a health intervention. The Orthodox monastic tradition of simple, home-cooked food prepared with prayer is one of the healthiest dietary patterns studied.",
 vsearch:"cooking skills for kids health benefits",res:"https://www.youtube.com/results?search_query=cooking+skills+for+kids+health+benefits",
 act:"Cook one complete meal from scratch this week — including a vegetable side. Calculate roughly how much it costs per person compared to the equivalent takeaway meal. What skills did you need?",
 ff:"Studies comparing people who cook 5+ home meals per week with those who cook fewer than 3 found that home cooks consume approximately 140 fewer calories per day, eat significantly more fruits and vegetables, and spend about 40% less money on food annually."},
{id:"sp25",title:"Posture, Ergonomics & Screen Health",age:"6–10",dur:"30 min",
 content:"Modern children spend an average of 7+ hours per day looking at screens. Effects: text neck (forward head posture adding up to 27 kg of extra strain on the neck), eye strain (the 20-20-20 rule: every 20 minutes, look at something 20 feet away for 20 seconds), disrupted sleep (blue light suppresses melatonin). Good posture: ears over shoulders, shoulders over hips, screen at eye level.",
 vsearch:"posture and screen health for kids",res:"https://www.youtube.com/results?search_query=posture+and+screen+health+for+kids",
 act:"Check your posture while reading this on a screen. Are your ears over your shoulders? Shoulders over hips? Screen at eye level? Do the 20-20-20 exercise right now. Set a timer for the next hour.",
 ff:"The average human head weighs 4.5-5 kg in neutral position. For every 2.5 cm the head moves forward from neutral alignment, the effective weight on the cervical spine increases by approximately 4.5 kg. Looking at a phone in the lap adds up to 27 kg of stress on the neck — equivalent to an 8-year-old child sitting on your shoulders."},
{id:"sp26",title:"Team Sports: NZ Rugby & the Values of the Game",age:"7–10",dur:"30 min",
 content:"Rugby is NZ's most prominent team sport. Key values: respect for opponents and referees, teamwork above individual glory, physical courage combined with discipline, fair play. The All Blacks' Maori-derived team culture includes: no individual is bigger than the team, players are expected to clean the changing room themselves (no one is too important to sweep the floor). Humility, excellence and togetherness.",
 vsearch:"NZ rugby values All Blacks teamwork for kids",res:"https://www.youtube.com/results?search_query=NZ+rugby+values+All+Blacks+teamwork+kids",
 act:"Research the All Blacks' culture document (Legacy by James Kerr is the key book). Find 3 values or principles they live by. How do they connect to Christian or Maori values? How could you apply one to your family?",
 ff:"The All Blacks lost only 8% of their test matches between 2004 and 2015 — the most sustained winning record of any professional sports team in history across any code. Their coach Graham Henry attributed this partly to building a culture where players took responsibility for their own character development, not just their physical skills."},
{id:"sp27",title:"Nutrition for Growth: What Children Actually Need",age:"6–10",dur:"30 min",
 content:"Children's nutritional needs differ from adults. Protein: 1-1.5g per kg of body weight per day (higher than adults relative to body weight) for growth. Calcium: 1,000-1,300mg per day (ages 9-18) for bone development. Iron: especially important for girls from puberty for blood production. Vitamin D: 15-20 minutes of sunlight per day (or food/supplements in winter). Children need more frequent meals than adults — typically 3 meals and 2 snacks.",
 vsearch:"nutrition for children growth what kids need to eat",res:"https://www.youtube.com/results?search_query=nutrition+for+children+growth+what+kids+need",
 act:"Keep a 3-day food diary. For each day, estimate: how much protein did you eat? How much calcium (dairy, green vegetables)? Did you get sunlight? How many different coloured vegetables did you eat?",
 ff:"The greatest period of bone development in humans is between ages 9-18. Up to 90% of peak bone mass is established by age 18. Calcium and Vitamin D intake during these years directly determines bone density for the rest of life. Osteoporosis in old age is often rooted in inadequate calcium intake in childhood."},
{id:"sp28",title:"Mental Health & Physical Activity",age:"7–10",dur:"30 min",
 content:"Physical exercise is one of the most effective treatments for depression and anxiety known to medicine. 30 minutes of moderate exercise 5 times per week reduces symptoms of mild-to-moderate depression as effectively as antidepressant medication in some studies. Exercise releases endorphins (natural pain-relievers and mood-lifters), reduces the stress hormone cortisol, and improves sleep quality. The Desert Fathers knew this: bodily ascesis (physical discipline) supports spiritual wellbeing.",
 vsearch:"mental health and physical activity for kids",res:"https://www.youtube.com/results?search_query=mental+health+physical+activity+for+kids",
 act:"Track your mood on a scale of 1-10 over 2 weeks. Also track: how much exercise you did, how much sleep you got, and how much time you spent outside. Look for correlations. What patterns do you notice?",
 ff:"St John Climacus (7th century) wrote in The Ladder of Divine Ascent that asceticism (physical discipline including fasting, vigil and prostrations) was essential for spiritual development because the body and soul are deeply connected — what affects one affects the other. Modern neuroscience confirms this with data."},
{id:"sp29",title:"Fair Trade, Food Systems & Global Justice",age:"8–10",dur:"30 min",
 content:"Most food in NZ supermarkets travelled thousands of kilometres to get there. The farmers who grew it — often in developing countries — may have received very little of the sale price. Fair Trade certification ensures that farmers receive a minimum price, are not exploited, and work in safe conditions. Buying Fair Trade is a small act of justice. Orthodox social teaching has always connected faith with economic justice.",
 vsearch:"fair trade food systems for kids global justice",res:"https://www.youtube.com/results?search_query=fair+trade+food+systems+for+kids",
 act:"Find 3 Fair Trade products in your local supermarket. Research: what country did each come from? What does Fair Trade certification mean for the farmers? Compare the price of Fair Trade vs non-Fair Trade for the same product.",
 ff:"St John Chrysostom preached in the 4th century: The rich man is not one who has much, but one who gives much. From what God has given you, you owe a portion to the poor. Not as a charity, but as a debt — the wealth of the world belongs to all, not to those who happen to hold it at this moment."},
{id:"sp30",title:"Sports & Science: Biomechanics Basics",age:"8–10",dur:"45 min",
 content:"Biomechanics applies physics to human movement. Key concepts: centre of gravity (the point where a body's weight is evenly distributed — lower is more stable), leverage (how lever-length affects force — a longer arm generates more throwing force), Newton's Third Law in sport (every push-off against the ground generates an equal and opposite forward force — this is how running works).",
 vsearch:"biomechanics basics for kids sports science",res:"https://www.youtube.com/results?search_query=biomechanics+basics+for+kids+sports+science",
 act:"Test centre of gravity: stand on one leg with arms out (stable) then arms in (less stable). Lever length: compare throwing distance with a short vs long swing. How does bending your knees when catching lower your centre of gravity and improve stability?",
 ff:"The human body is an extraordinary biomechanical system. The Achilles tendon — the strongest tendon in the body — stores and releases energy during running like a spring. Without this energy storage, running would require approximately 40% more energy. God designed us to run efficiently."},
{id:"sp31",title:"Cultural Sports of the Pacific",age:"5–10",dur:"30 min",
 content:"The Pacific region has rich sporting traditions. Kilikiti (Samoan cricket) is played with a triangular bat and can involve dozens of players per side. Ki-o-rahi is a traditional Maori team sport played on a circular field. Tonga's national sport is rugby. Sumo wrestling originated in Japan as a sacred Shinto ritual. Each sporting tradition carries cultural and spiritual meaning beyond mere competition.",
 vsearch:"Pacific sports kilikiti ki-o-rahi traditional games",res:"https://www.youtube.com/results?search_query=Pacific+sports+kilikiti+ki-o-rahi+traditional",
 act:"Research ki-o-rahi (traditional Maori sport). Learn the basic rules and the spiritual origin of the game. If possible, play a simplified version with your family. How does it differ from sports you usually play?",
 ff:"Ki-o-rahi was played by Maori for centuries before European contact. The game tells a story of Rahi searching for his wife Tiarakurapakewai — the circular field represents the world, the central target (tupu) represents their goal. Sport and story are inseparable in traditional cultures."},
{id:"sp32",title:"Sleep Routines & Evening Prayer",age:"All",dur:"20 min daily",
 content:"A consistent evening routine prepares the body and mind for deep, restorative sleep. Elements of an Orthodox evening routine: evening prayers (thanking God, asking forgiveness, committing the night to His care), reviewing the day honestly, reading something nourishing (a psalm, a saint's life, or uplifting literature), no screens for at least 30-60 minutes before bed, consistent sleep time. This is a physiological and spiritual practice simultaneously.",
 vsearch:"sleep routine for kids evening healthy habits",res:"https://www.youtube.com/results?search_query=sleep+routine+for+kids+evening+healthy",
 act:"Design your family's evening prayer and sleep routine. Include: what time screens go off, what prayer is said, what is read, what time you aim to be asleep. Try it for one week. Compare how you feel.",
 ff:"Research by the American Academy of Sleep Medicine shows that consistent bedtime routines reduce the time it takes children to fall asleep by an average of 15 minutes, increase total sleep time, and significantly reduce night wakings. The body's circadian rhythm responds powerfully to consistent timing."},
{id:"sp33",title:"Outdoor Education: Tramping & Navigation",age:"7–10",dur:"1.5 hours",
 content:"Tramping (hiking/backpacking) is one of NZ's most popular outdoor activities — the Department of Conservation maintains over 14,000 km of tracks. The essential tramping skills: reading a topographic map (contour lines show elevation — lines close together mean steep slopes), using a compass, knowing the weather, the Ten Essentials (map, compass, sunscreen, extra food, extra water, extra clothes, headlamp, first aid, fire starter, knife).",
 vsearch:"tramping navigation New Zealand for kids beginners",res:"https://www.youtube.com/results?search_query=tramping+navigation+New+Zealand+kids",
 act:"Obtain a topographic map of your local area. Identify a hill or ridge near you. Trace the route from your home to the summit and calculate the approximate distance and elevation gain. What equipment would you need?",
 ff:"NZ's Great Walks (Milford Track, Routeburn Track, Tongariro Alpine Crossing and others) are among the most beautiful walks in the world. The Tongariro Alpine Crossing passes directly over the volcanic terrain that inspired Tolkien's Mordor in The Lord of the Rings."},
{id:"sp34",title:"Food Growing & Self-Sufficiency",age:"7–10",dur:"30 min",
 content:"Growing your own food is one of the most rewarding forms of physical activity. It combines: bending, digging, lifting and carrying (exercise), time outdoors (sunlight and Vitamin D), connection to natural rhythms (seasonal eating), and the satisfaction of eating what you grew. Studies show that children who grow their own food eat more vegetables and develop a healthier relationship with food overall.",
 vsearch:"growing your own food health benefits for kids",res:"https://www.youtube.com/results?search_query=growing+your+own+food+health+benefits+kids",
 act:"Calculate: if your family ate one meal per week using entirely home-grown produce for a year, how much money might you save? How much exercise might you get gardening? Make the case for a larger garden.",
 ff:"During World War II, 'Victory Gardens' were planted by millions of families across NZ, Australia, the USA and Britain. By 1944, these home gardens were producing approximately 40% of all vegetables consumed in the USA. The tradition collapsed after the war when cheap supermarket food became available. It is experiencing a revival."},
{id:"sp35",title:"Wairuatanga: The Spiritual Dimension of Health",age:"8–10",dur:"30 min",
 content:"In Te Ao Maori (the Maori worldview), health has four interconnected dimensions: taha tinana (physical health), taha hinengaro (mental/emotional health), taha whanau (family/social health), and taha wairua (spiritual health). All four must be in balance for a person to be truly well. This model — called the Whare Tapa Wha (four-sided house) — was developed by Sir Mason Durie and is now widely used in NZ health care.",
 vsearch:"Whare Tapa Wha Maori health model for kids NZ",res:"https://www.youtube.com/results?search_query=Whare+Tapa+Wha+Maori+health+model+kids",
 act:"Draw the Whare Tapa Wha as a house with four walls. In each wall, write what supports your health in that dimension. Compare with the Orthodox understanding of the human person as body, soul and spirit. How do these models complement each other?",
 ff:"Sir Mason Durie developed the Whare Tapa Wha model in 1984 in response to a NZ health system that treated illness purely as a physical problem. His model is now officially incorporated into NZ mental health policy, hospital design, and school health programmes."},
{id:"sp36",title:"Sports Science Year in Review",age:"All",dur:"1 hour",
 content:"Over this year we have explored: the healthy plate and Orthodox fasting, macronutrients, muscles and the Incarnation, heart and breath, core sports skills, hydration, sleep, teamwork, the digestive system, stretching, vitamins, water safety, bones and posture, energy systems, resilience, NZ sports heritage, the athlete's mind, seasonal eating, first aid, physical habits, nutrition labels, interval training, the Olympics, biomechanics, Pacific sports, sleep routines, tramping, food growing, Maori health, and food justice.",
 vsearch:"sports science and nutrition year review for kids",res:"https://www.youtube.com/results?search_query=sports+science+nutrition+year+review+kids",
 act:"Make a sports and health mind-map of everything you have learned this year. For each topic, write one thing you have changed in your life as a result of learning it. Then make one commitment for next year.",
 ff:"St Paul wrote: I discipline my body and keep it under control (1 Corinthians 9:27). The Greek word he used — hypopiazo — means literally to give a black eye to, to pummel. He was not gentle in his metaphors for physical self-discipline. The body is not an enemy — but it must be trained, not indulged."},
]},
{id:"cooking",name:"Cooking",emoji:"🍳",color:P.gold,tagline:"Real food, prepared with love, offered to God.",
lessons:[
{id:"ck1",title:"Kitchen Safety & Monastic Obedience",age:"5–10",dur:"30 min",
 content:"Before cooking: wash hands, tie hair back, wear apron. Knives point down when carrying. Hot pans ALWAYS assumed hot. Never leave cooking unattended. In Orthodox monasteries, kitchen work (obedience) is assigned by the Abbot and considered a spiritual discipline equal to prayer and fasting. Cooking for others is an act of love.",
 vsearch:"kitchen safety for kids cooking",res:"https://www.youtube.com/results?search_query=kitchen+safety+for+kids",
 act:"Kitchen tour with a parent: name every tool and its purpose. Identify all heat sources. Look up: what do Orthodox monks eat for meals? (Simple food, eaten in silence while scripture is read aloud.)",
 ff:"Every Orthodox monastery has a trapeza (kitchen) and refectory (dining hall) where meals are eaten in silence while a reader reads aloud from the Fathers or saints' lives. Cooking is a spiritual service equal to prayer."},
{id:"ck2",title:"Pancakes from Scratch",age:"5–10",dur:"45 min",
 content:"Whisk dry: 1 cup flour, 1 tbsp sugar, 2 tsp baking powder, ¼ tsp salt. Whisk wet: 1 cup milk, 1 egg, 2 tbsp melted butter. Combine — stir until just mixed (lumps fine). Cook ¼ cup per pancake. Flip when edges look dry and bubbles pop.",
 vsearch:"easy pancake recipe for kids scratch",res:"https://www.youtube.com/results?search_query=easy+pancake+recipe+kids",
 act:"Make breakfast for the whole family. Serve with fresh fruit, honey and yoghurt. Offer a short blessing before eating. Wash up afterwards.",
 ff:"Bliny (Russian pancakes) are traditionally eaten at Maslenitsa — Cheesefare Week — the last week before Great Lent when dairy and eggs are still allowed. Rich and celebratory — the last indulgence before the great fast."},
{id:"ck3",title:"Knife Skills: The Claw",age:"7–10",dur:"30 min",
 content:"The claw hold: fingertips tucked under, second knuckles forward. The knife blade rests against the knuckles as it rises and falls — never reaching your fingertips. Start with soft foods: banana coins, mushroom slices, cooked potato. Work slowly — speed comes with months of practice.",
 vsearch:"kids knife skills claw grip",res:"https://www.youtube.com/results?search_query=kids+knife+skills+claw",
 act:"Under adult supervision: slice a banana into coins using the claw. Then dice a mushroom. Award a Sous Chef certificate.",
 ff:"In Orthodox monasteries, kitchen work is assigned as an obedience — a spiritual task equal to prayer. St Siluan of Athos cooked for the monastery for years and said the kitchen was where he learned his deepest lessons about humility."},
{id:"ck4",title:"Leavened Bread & Artos",age:"6–10",dur:"2 hours",
 content:"In the Orthodox tradition, five loaves of leavened bread (artos) are blessed at Vespers on feast days — recalling Christ's feeding of the 5,000. Basic loaf: 3 cups flour, 7g yeast, 1 tsp salt, 1 tbsp sugar, 1 cup warm water, 2 tbsp olive oil. Mix, knead 10 min, rise 1 hour, shape, rise 30 min, bake 200°C 25 min. Score a cross on top.",
 vsearch:"how to make bread with kids yeast",res:"https://www.youtube.com/results?search_query=how+to+make+bread+kids+yeast",
 act:"Make a loaf. Score a cross on top before baking. While it rises, research: what is Artoklasia? (The blessing of five loaves at Vespers, recalling Christ's feeding of the 5,000.) Eat at a family meal with a blessing.",
 ff:"Christ said: I am the Bread of Life. Whoever comes to me will never hunger (John 6:35). The Eucharist is bread. Baking and breaking bread together has been central to Christian life since the first Pascha."},
{id:"ck5",title:"Lenten Lentil Soup",age:"7–10",dur:"1 hour",
 content:"Orthodox Christians fast from meat, dairy, fish, oil and wine on Wednesdays and Fridays — over 180 fast days per year. This requires learning to cook simple, nourishing plant-based food. Lentil soup: sauté 1 chopped onion + 2 garlic cloves in olive oil. Add 1 cup red lentils, 4 cups water or stock, 1 tsp cumin, salt, pepper. Simmer 25 minutes. Squeeze lemon. Eat with bread.",
 vsearch:"easy lentil soup recipe from scratch",res:"https://www.youtube.com/results?search_query=easy+lentil+soup+recipe",
 act:"Make lentil soup for a family dinner on Wednesday or Friday as a fast-day meal. Research: what did Esau sell his birthright for? (A bowl of lentil stew — Genesis 25:29-34.) Discuss: what would you trade a birthright for?",
 ff:"Lentils are one of the oldest cultivated foods — 8,000 years. Lentil soup was the food of the poor and the food of the desert monks. Some of the greatest saints ate almost nothing else."},
{id:"ck6",title:"Roast Vegetables",age:"6–10",dur:"1 hour",
 content:"Roasting concentrates natural sugars through the Maillard reaction (above 140°C = complex golden colour and flavour). Chop any mix: kumara, potato, pumpkin, carrot, onion. Toss with olive oil, salt, pepper, rosemary or thyme. Single layer on tray. Roast 200°C 35–45 min, turning once.",
 vsearch:"how to roast vegetables perfectly",res:"https://www.youtube.com/results?search_query=how+to+roast+vegetables",
 act:"Make as a dinner side dish. Eat together with a blessing. Try garlic cloves, lemon zest, or balsamic drizzle.",
 ff:"Olive oil — the primary cooking fat of the Mediterranean world — was so sacred that the Temple menorah burned only pure olive oil. The word Christ/Messiah means Anointed One — anointed with oil. Oil is sacred."},
{id:"ck7",title:"Reading Recipes & Scaling",age:"8–10",dur:"30 min",
 content:"A recipe has: ingredients list, method (numbered steps), yield (how many it serves), temperature, and time. To double: multiply every ingredient by 2. To halve: divide by 2. Cooking time usually does not change for the same dish — go by appearance and colour.",
 vsearch:"how to read a recipe for kids",res:"https://www.youtube.com/results?search_query=how+to+read+a+recipe+kids",
 act:"Take the lentil soup recipe. Rewrite it to serve 20 people for a parish meal after Liturgy. Then rewrite it to serve 1 person.",
 ff:"The oldest recipes in continuous use are the monastic recipes of Mount Athos — some dating back over 1,000 years and still being made today."},
{id:"ck8",title:"Garden-to-Plate & Eating in Season",age:"All",dur:"30 min",
 content:"The freshest food is the most nutritious. Harvest what is ready: mixed greens, cucumber, tomatoes, fresh herbs. Simple dressing: 3 tbsp olive oil + 1 tbsp lemon juice + pinch of salt + ½ tsp honey. The Church year is a feast-and-fast calendar — eating seasonally is a form of embodied faith.",
 vsearch:"garden to table cooking for kids simple",res:"https://www.youtube.com/results?search_query=garden+to+table+cooking+kids",
 act:"Harvest something from your garden. Build a simple meal around it. Before eating, say: O Christ our God, bless the food and drink of Thy servants. Amen.",
 ff:"The average NZ supermarket vegetable has travelled over 2,000 km. Most vitamins begin declining from the moment of harvest. Garden-to-plate travels about 20 metres — freshness is a form of stewardship."},

{id:"ck9",title:"Traditional NZ Maori Cooking: Hangi",age:"6–10",dur:"2 hours",
 content:"A hangi is a traditional Maori method of cooking food in a pit oven using heated rocks. Rocks are heated in a fire for several hours until white-hot. A wire basket with food (meat, root vegetables, kumara, pumpkin) is lowered into the pit, the hot rocks placed around it, the whole pit covered with wet sacking and earth to seal in steam. Cooking time: 3-4 hours. The result is deeply flavourful, tender food infused with a subtle smoky-earth taste.",
 vsearch:"hangi Maori cooking traditional NZ how to",res:"https://www.youtube.com/results?search_query=hangi+Maori+cooking+traditional+NZ",
 act:"Research the hangi process in detail. If possible, attend a hangi at a local marae or event. Write a step-by-step how-to guide. What vegetables are traditionally used? What makes a good hangi stone?",
 ff:"The word hangi refers both to the oven (the pit) and the meal itself. Hangi has been the central cooking method for Maori hospitality for approximately 700 years. At a large tangi (funeral) or wedding, a hangi might feed several hundred people."},
]},
{id:"gardening",name:"Gardening",emoji:"🌱",color:P.forest,tagline:"From seed to harvest — tending the garden God gave us.",
lessons:[
{id:"gr1",title:"What a Plant Needs",age:"4–8",dur:"30 min",
 content:"Plants need 5 things: sunlight, water, CO₂ from air, nutrients from soil (nitrogen, phosphorus, potassium), and space. The first human vocation given by God was to tend the garden (Genesis 2:15). Gardening is obedience to our original calling as stewards of creation.",
 vsearch:"how plants grow SciShow Kids",res:"https://www.youtube.com/results?search_query=how+plants+grow+SciShow+Kids",
 act:"Plant a bean in a clear cup with damp paper towel. Draw daily for 10 days. Label root, shoot, seed leaves (cotyledons), true leaves. Read Genesis 2:15.",
 ff:"Monasteries throughout history have been centres of agricultural knowledge. Prayer and farming have always gone together — the Cistercian monks of medieval France were the most advanced farmers in Europe."},
{id:"gr2",title:"Living Soil",age:"5–9",dur:"45 min",
 content:"A single teaspoon of healthy soil contains ~1 billion bacteria, 120,000 fungi, and millions of other organisms. Good garden soil smells sweet — like a forest after rain (the compound is called geosmin, produced by actinobacteria). God made the soil alive; our task is to maintain that life.",
 vsearch:"what is soil for kids Free School",res:"https://www.youtube.com/results?search_query=what+is+soil+kids",
 act:"Dig up 1 cup of garden soil. Spread on white paper. Use a magnifying glass to find 5 different living things. Smell the soil — this is the smell of life.",
 ff:"God formed man from the dust of the ground (Genesis 2:7). The Hebrew word for man is adam and for ground is adamah. We are literally earthlings — made of and returning to the same living soil we tend."},
{id:"gr3",title:"Compost: Returning to the Earth",age:"6–10",dur:"1 hour",
 content:"Compost recipe: 2 parts brown (dry leaves, cardboard, straw = carbon) to 1 part green (kitchen scraps, grass = nitrogen). Exclude meat, dairy and oils. Keep moist. Turn weekly. In 6–12 weeks: dark, earthy humus. Composting is a parable of resurrection: what dies becomes the foundation for new life.",
 vsearch:"composting for kids GrowVeg",res:"https://www.youtube.com/results?search_query=composting+for+kids",
 act:"Start a home compost system. Keep a tally of what you add each day. Read 1 Corinthians 15:36: What you sow does not come to life unless it dies.",
 ff:"St Paul writes: What you sow does not come to life unless it dies (1 Corinthians 15:36) — using seed and composting as a direct image of the Resurrection."},
{id:"gr4",title:"Easy Vegetables for Beginners (NZ)",age:"5–10",dur:"1.5 hours",
 content:"Easiest NZ first crops: radish (4 weeks), lettuce (6 weeks), spring onion (8 weeks), peas (10 weeks), courgette (10 weeks), potato (12 weeks). Planting guide: northern NZ year-round, central NZ September–March, South Island/highlands October–February.",
 vsearch:"easy vegetables for kids to grow GrowVeg",res:"https://www.youtube.com/results?search_query=easy+vegetables+kids+grow",
 act:"Choose one vegetable to grow this week. Plant in a pot if no garden space. Set up a plant diary with weekly measurements and observations.",
 ff:"The monks of Mount Athos grow much of their own food, including olive trees hundreds of years old. Some Athonite gardens have been continuously cultivated for over 1,000 years."},
{id:"gr5",title:"Three Sisters: Companion Planting",age:"7–10",dur:"1 hour",
 content:"Plant corn, climbing beans and pumpkin together. Corn provides a climbing pole for beans. Beans fix nitrogen into the soil. Pumpkin's huge leaves shade the ground and retain moisture. Each plant helps the others — a parable of Christian community: we support each other's weaknesses.",
 vsearch:"Three Sisters companion planting",res:"https://www.youtube.com/results?search_query=Three+Sisters+companion+planting",
 act:"Plan a Three Sisters bed on paper. Discuss: how does each plant reflect a different member of a family or church community?",
 ff:"Māori grew kumara with gourds in a similar companion planting tradition. The kumara was so sacred that dedicated tūāhu priests oversaw planting ceremonies with prayer."},
{id:"gr6",title:"Bees, Pollinators & God's Provision",age:"5–9",dur:"45 min",
 content:"A honeybee visits 5,000 flowers in a single day. Without bees: no apples, almonds, kiwifruit, berries, cucumbers, or most vegetables. Orthodox monasteries keep bees — beeswax candles are the primary liturgical candle of the Church.",
 vsearch:"why bees matter SciShow Kids",res:"https://www.youtube.com/results?search_query=why+bees+matter+kids",
 act:"Sit beside a flowering plant for 10 minutes. Count every insect visitor. Research: where is honey mentioned in the Bible? (At least 60 times, from Genesis to Revelation.)",
 ff:"The beeswax candle represents Christ in Orthodox theology: pure wax = His sinless body, wick = His soul, flame = His divinity. The bee is a tiny preacher of God's wisdom, as St John Chrysostom wrote."},
{id:"gr7",title:"Saving Seeds for the Future",age:"8–10",dur:"45 min",
 content:"Seeds from open-pollinated plants can be saved and replanted year after year. Tomatoes: scoop, ferment 3 days in water, drain, dry. Beans/peas: let pods dry completely on the plant. Label: variety name, year, location.",
 vsearch:"how to save seeds for next year gardening",res:"https://www.youtube.com/results?search_query=how+to+save+seeds+gardening",
 act:"Save seeds from a tomato, pumpkin or pepper you eat this week. Dry on paper towel for 2 weeks. Label and store in a paper envelope in a cool, dry place.",
 ff:"Monasteries have been seed savers for 1,500 years — preserving rare varieties of grain, olive trees, herbs and vegetables that might otherwise have been lost to history."},
{id:"gr8",title:"Garden Year Planner (NZ)",age:"8–10",dur:"30 min",
 content:"Spring (Sept–Nov): plant beans, peas, lettuce, tomato seedlings after frost. Summer (Dec–Feb): harvest, plant winter brassicas. Autumn (March–May): plant garlic on shortest day (21 June). Winter (June–Aug): rest, compost, plan. Garlic goes in on the Winter Solstice — a natural echo of Advent, awaiting the coming of light.",
 vsearch:"seasonal gardening NZ guide Tui",res:"https://www.youtube.com/results?search_query=seasonal+gardening+NZ",
 act:"Make a 12-month wall planner. For each month: what to plant, what to harvest, and one garden task. Also mark the four Orthodox fasting periods — notice how they overlap with the gardening year.",
 ff:"The Orthodox fasting calendar is governed by the sun (fixed feasts) and the moon (Pascha — first Sunday after first full moon after the spring equinox). The Church year and the gardening year both follow the rhythm of creation."},

{id:"gr9",title:"Worms & Vermicomposting",age:"6–10",dur:"1 hour",
 content:"Vermicomposting uses worms (specifically tiger worms or red wrigglers) to break down kitchen scraps into incredibly rich worm castings (vermicast). A worm can eat half its body weight per day. The resulting vermicast has 5-11 times more nitrogen, phosphorus and potassium than standard compost. Worm tea (the liquid that drains from the worm farm) is a powerful liquid fertiliser.",
 vsearch:"vermicomposting worm farm for kids GrowVeg",res:"https://www.youtube.com/results?search_query=vermicomposting+worm+farm+for+kids",
 act:"Set up a simple worm farm using a bucket with drainage holes and a lid. Add tiger worms (from a garden centre), damp shredded newspaper as bedding, and start feeding kitchen scraps. Water weekly with the worm tea.",
 ff:"Charles Darwin spent 39 years studying earthworms. He concluded that: It may be doubted whether there are many other animals which have played so important a part in the history of the world as have these lowly organised creatures."},
]},
{id:"farming",name:"Farming",emoji:"🚜",color:P.terra,tagline:"Land, animals and food — the foundations of life.",
lessons:[
{id:"fm1",title:"Farm Animals & Their Gifts",age:"4–8",dur:"30 min",
 content:"Cows: milk and beef. Sheep: wool and meat — Christ is the Good Shepherd and we His sheep. Chickens: eggs and meat. Pigs: pork and bacon. Goats: milk, cheese, weed control. Bees: honey and beeswax for liturgical candles. The Orthodox tradition of blessing animals on feast days recognises them as part of God's good creation entrusted to our care.",
 vsearch:"farm animals for kids Free School",res:"https://www.youtube.com/results?search_query=farm+animals+for+kids",
 act:"List 10 things that came from animals that you used or ate today. Say a prayer of thanksgiving for the animals that serve your family.",
 ff:"NZ has ~5 million cattle, 26 million sheep and 5 million people. At peak in 1982 there were 70 million sheep — 20 per person."},
{id:"fm2",title:"Backyard Chickens & Stewardship",age:"5–10",dur:"45 min",
 content:"A healthy laying hen produces 250–300 eggs per year. Hens need: a secure coop (shut at night), fresh water daily, layer pellets + scraps + grit. No rooster required for eggs — only for fertile eggs. Orthodox monasteries have kept chickens for 1,500 years — for eggs on non-fast days.",
 vsearch:"backyard chickens beginners kids",res:"https://www.youtube.com/results?search_query=backyard+chickens+beginners",
 act:"If you have hens, collect, weigh and record eggs for a week. If not, design a backyard chicken setup on paper. Calculate: how many hens to provide all your family's weekly eggs?",
 ff:"The rooster's crow marks the hour of Prime (the first Hour prayer) in the daily monastic schedule. Peter's denial was marked by the rooster's crow — a call to repentance."},
{id:"fm3",title:"A Dairy Cow's Day",age:"5–10",dur:"45 min",
 content:"NZ dairy farms milk twice a day: ~5 am and 2–3 pm. A peak-season Friesian cow produces 25–30 L per milking. Cows walk to the shed, teats are cleaned and attached to vacuum clusters (7–8 min), milk flows to a refrigerated vat, tanker collects every 1–2 days.",
 vsearch:"dairy farm day life NZ for kids",res:"https://www.youtube.com/results?search_query=dairy+farm+day+life+NZ",
 act:"Calculate: one cow × 25L × 2 milkings × 305 days = how many litres per year? How many families could that one cow feed?",
 ff:"NZ produces about 21 billion litres of milk equivalent per year — about 4,000 litres per New Zealander, most exported. NZ is the world's largest dairy exporter by value."},
{id:"fm4",title:"Sheep, Shearing & Wool",age:"6–10",dur:"45 min",
 content:"Sheep are shorn once a year in NZ (October–December). A gun shearer can do 200–300 sheep per day. One fleece weighs 4–8 kg. Wool insulates, breathes, resists fire and water, and biodegrades completely. The image of the Good Shepherd saturates all of Scripture — from the patriarchs (all shepherds) to Revelation.",
 vsearch:"sheep shearing NZ Country Calendar",res:"https://www.youtube.com/results?search_query=sheep+shearing+NZ",
 act:"Find a piece of raw wool. Feel the lanolin. Research: how many steps from fleece to a woollen jumper? Read Psalm 23 and find every image from farming life.",
 ff:"The image of God as shepherd and humanity as His flock runs throughout the entire Bible — from Abraham, Moses, David (all shepherds) to Revelation, where Christ is the Lamb on the throne."},
{id:"fm5",title:"The Farming Year (NZ)",age:"7–10",dur:"45 min",
 content:"Spring (Aug–Nov): lambing and calving — busiest and most joyful season. Summer (Dec–Feb): shearing, hay-making, harvesting. Autumn (March–May): weaning lambs, winter cropping. Winter (June–Aug): animals on hay, fencing repairs, planning. The farmer's year follows the seasons — as the Church year does.",
 vsearch:"Country Calendar NZ farm documentary",res:"https://www.youtube.com/results?search_query=Country+Calendar+NZ+farm",
 act:"Watch one Country Calendar episode. What season is it? Overlay the farming year onto the Church calendar: what season of the Church corresponds to lambing (spring)? To harvest (late summer)?",
 ff:"1 June is NZ's rural Moving Day — when farm employment contracts traditionally begin and end. It mirrors the nomadic life of the biblical patriarchs."},
{id:"fm6",title:"Rotational Grazing & Stewardship",age:"8–10",dur:"45 min",
 content:"Rotational grazing: animals graze one paddock then move on; the grazed paddock rests and regrows. Benefits: grass does not get over-grazed, parasite load breaks, soil improves as roots grow deeply. Caring for land mirrors how God calls us to care for creation — Genesis 2:15: work it and take care of it.",
 vsearch:"rotational grazing explained for beginners",res:"https://www.youtube.com/results?search_query=rotational+grazing+explained",
 act:"Design a 12-paddock rotational system on paper. If each paddock needs 28 days rest and animals stay 3 days, how many paddocks minimum? (At least 10.) How is rotating paddocks like fasting and feasting in the Church year?",
 ff:"Pasture grass under good rotational grazing stores up to 5 times more carbon than continuously grazed pasture. Well-managed land actively restores creation. Stewardship — not just use — is a Christian calling."},
{id:"fm7",title:"Beekeeping & the Monastery Tradition",age:"8–10",dur:"1 hour",
 content:"A hive: 1 queen (1,500–2,000 eggs/day), 40,000–80,000 workers (all female), 300–3,000 drones. Workers collect nectar, add enzymes, fan out moisture — the result is honey with less than 18% water content that does not spoil.",
 vsearch:"beekeeping for beginners introduction kids",res:"https://www.youtube.com/results?search_query=beekeeping+for+beginners+kids",
 act:"Visit a beekeeper if possible. Try local raw honey vs supermarket honey — compare colour, smell and taste. Research: where is honey mentioned in Orthodox prayers and liturgy?",
 ff:"The pure beeswax candle represents Christ: pure wax = His sinless body, wick = His soul, flame = His divinity. The bee is a tiny preacher of God's wisdom, as St John Chrysostom wrote."},
{id:"fm8",title:"From Paddock to Plate",age:"All",dur:"45 min",
 content:"Every meal has a story. A lamb chop: ewe and ram produce a lamb in spring, raised on grass, sent to the works at 6–8 months, butchered, packaged, refrigerated, transported, bought, cooked, eaten. How many people were involved? How many kilometres? This meal cost a life — gratitude and prayer before eating are appropriate responses.",
 vsearch:"farm to table meat supply chain for kids",res:"https://www.youtube.com/results?search_query=farm+to+table+meat+supply+chain",
 act:"Pick one item from tonight's dinner. Trace its full journey from farm to plate. Before eating, say the meal blessing and mean it.",
 ff:"The Orthodox meal blessing: Give bread to those who hunger, and hunger for righteousness to those who have bread. The blessing of food carries a responsibility for others who go without."},

{id:"fm9",title:"Soil Testing & Improvement",age:"8–10",dur:"1 hour",
 content:"Soil pH (0-14 scale): 7 = neutral. Most plants prefer 6-7. Below 6: too acidic — add lime. Above 7: too alkaline — add sulphur or compost. Soil nutrients: nitrogen (N) for leaves and growth, phosphorus (P) for roots and flowers, potassium (K) for fruit and disease resistance — called NPK. Test soil with a simple home test kit from a garden centre.",
 vsearch:"how to test your soil pH home garden",res:"https://www.youtube.com/results?search_query=how+to+test+soil+pH+home+garden",
 act:"Buy a simple soil pH test kit (approximately $15 from a garden centre). Test 3 different spots in your garden. Record results. Research what your soil needs based on what you want to grow.",
 ff:"New Zealand soils tend to be low in selenium — a trace mineral essential for human and animal health. NZ soils formed from relatively young volcanic rock and have not had millions of years to accumulate this mineral. Fertiliser programmes include selenium for livestock health."},
]},
{id:"construction",name:"Home Construction",emoji:"🔨",color:P.navy,tagline:"Building with our hands to God's glory.",
lessons:[
{id:"co1",title:"The Toolkit: Names & Uses",age:"5–10",dur:"30 min",
 content:"Essential tools: hammer, screwdriver (Phillips and flat-head), tape measure (metric, retractable), level, hand saw, drill (holes + driving screws), square (checks 90° angles), clamps. St Joseph was a tekton — craftsman, carpenter, builder. Jesus spent 30 of His 33 years on earth working with His hands alongside Joseph.",
 vsearch:"basic tools for kids names uses",res:"https://www.youtube.com/results?search_query=basic+tools+for+kids+names",
 act:"Lay out the household toolkit. Name each tool. Demonstrate correct use. Research: what was the trade of St Joseph, foster father of Jesus? (Tekton — craftsman.)",
 ff:"Jesus spent approximately 30 of his 33 years on earth as a tekton — craftsman — working with His hands. All honest labour is participation in God's creative work. Work is worship."},
{id:"co2",title:"Measure Twice, Cut Once",age:"6–10",dur:"30 min",
 content:"Measure TWICE, cut ONCE. A tape measure reads from the hooked end. The hook moves slightly — intentional, compensating for its own thickness. Use a carpenter's square for right angles. Mark cuts with a sharp pencil. Cut on the waste side of the line.",
 vsearch:"how to use tape measure kids",res:"https://www.youtube.com/results?search_query=how+to+use+tape+measure+kids",
 act:"Measure 10 things in the house. The Ark was 300 cubits × 50 × 30. At 45 cm per cubit, calculate the dimensions in metres. (135m × 22.5m × 13.5m.)",
 ff:"On NZ tape measures, small red marks appear every 600 mm — stud marks — the standard spacing of wall framing studs in our homes. These hidden patterns hold our houses together."},
{id:"co3",title:"Build a Birdhouse",age:"7–10",dur:"2 hours",
 content:"Floor 12×12 cm, two sides 12×20 cm, front and back 14×25 cm, roof panel 16×18 cm. Entry hole: 30–35 mm, 15 cm up the front. No perch — it helps predators. Assemble with 40 mm screws. Untreated pine. Hang 2–3 m up.",
 vsearch:"build birdhouse kids simple plan",res:"https://www.youtube.com/results?search_query=build+birdhouse+kids",
 act:"Build the birdhouse with adult supervision. Mount it. Keep a log of bird activity. Jesus said: Not one sparrow falls to the ground without your Father knowing (Matthew 10:29). Build it for His sparrows.",
 ff:"The hammer is likely humanity's oldest tool — stone hammers from Kenya date to 3.3 million years ago. The cross itself was built with hammer and nails."},
{id:"co4",title:"Reading a Building Plan",age:"7–10",dur:"45 min",
 content:"Plans show top view (floor plan), side views (elevations), cross-sections. Lines: thick solid = walls or visible edges; thin solid = dimensions; dashed = hidden features. Scale 1:50 means 1 cm on paper = 50 cm in real life. The Orthodox church building itself is theology in three dimensions: narthex (world), nave (Church), sanctuary (heaven).",
 vsearch:"how to read building plans basics",res:"https://www.youtube.com/results?search_query=how+to+read+building+plans",
 act:"On 5 mm graph paper (1 square = 50 cm real), draw a floor plan of your bedroom. Include all furniture to scale. Add a north arrow.",
 ff:"The Orthodox church building is theology in three dimensions: the narthex (entrance) represents the world, the nave the visible Church, the sanctuary represents heaven."},
{id:"co5",title:"How a House is Built",age:"8–10",dur:"1 hour",
 content:"Four systems. Foundation: concrete slab or piles. Frame: timber skeleton (bottom plate, studs at 600 mm centres, top plate, roof trusses). Envelope: cladding + roof + windows. Services: plumbing, electrical, insulation woven into the frame.",
 vsearch:"how a house is built timelapse",res:"https://www.youtube.com/results?search_query=how+a+house+is+built+timelapse",
 act:"Build a model house frame from ice-block sticks: bottom plate, studs at 60 mm scaled spacing, top plate, and a simple king-post roof truss.",
 ff:"The Cathedral of Hagia Sophia (Holy Wisdom) in Constantinople, built 537 AD, was the largest enclosed space in the world for nearly 1,000 years. Built with no modern machinery."},
{id:"co6",title:"Simple Machines in Building",age:"7–10",dur:"45 min",
 content:"Six simple machines: lever (crowbar), wheel and axle (screwdriver, wheelbarrow), pulley (crane), inclined plane (ramp), wedge (axe head, chisel), screw (jack, fasteners). All reduce force needed or change its direction. Archimedes: Give me a lever long enough and I shall move the world.",
 vsearch:"six simple machines for kids Free School",res:"https://www.youtube.com/results?search_query=six+simple+machines+kids",
 act:"Build a lever from a plank over a round log. Try lifting a heavy pot. Move the fulcrum — easier or harder? Find each simple machine in your home.",
 ff:"The great Byzantine cathedrals were built without modern machinery using only simple machines: levers, pulleys, inclined ramps, and thousands of skilled hands. Faith motivated extraordinary engineering."},
{id:"co7",title:"Maintenance: Fix It, Don't Bin It",age:"All",dur:"45 min",
 content:"Preventative maintenance is cheaper than repair; repair is cheaper than replacement. Squeaky hinge: 1 drop of oil. Loose screw: tighten or use a larger one. Dripping tap: usually a worn washer ($2). Blocked drain: boiling water + baking soda + vinegar.",
 vsearch:"basic home maintenance beginners kids",res:"https://www.youtube.com/results?search_query=basic+home+maintenance+beginners",
 act:"Walk through your home with a parent. Find 5 things to repair. Fix one together this week. Keep a repair log.",
 ff:"Monastic communities are remarkable for the care and longevity of their buildings and tools. They maintain what God has given them with extraordinary stewardship."},
{id:"co8",title:"Build a Raised Garden Bed",age:"8–10 with adult",dur:"3 hours",
 content:"Materials for 1.2 m × 2.4 m: four 200 mm × 50 mm × 2.4 m planks (2 cut to 1.2 m), 4 corner posts 300 mm × 50 mm × 50 mm, 50 mm screws. Fill: cardboard base + compost + topsoil. This is a building project AND a gardening project — the two crafts together serve the family table.",
 vsearch:"build raised garden bed for beginners",res:"https://www.youtube.com/results?search_query=build+raised+garden+bed+beginners",
 act:"Design and build a raised bed with an adult. Fill it and plant your first crop. Keep a cost record.",
 ff:"Raised bed gardening produces ~4 times more food per square metre than conventional row gardening. Medieval monks invented this technique."},

{id:"co9",title:"Reading Electrical & Plumbing Plans",age:"8–10",dur:"45 min",
 content:"Every house has electrical and plumbing plans hidden in its walls. Electrical plans use symbols: double circle = ceiling light, rectangle = power outlet, triangle = smoke detector, wavy lines = earth wire. Plumbing plans show hot water (red lines), cold water (blue lines), waste water (green lines). Understanding these is the first step to safe DIY maintenance.",
 vsearch:"reading home electrical plumbing plans basics",res:"https://www.youtube.com/results?search_query=reading+home+electrical+plumbing+plans+basics",
 act:"Draw a floor plan of two rooms in your house. Add approximate locations of power outlets, light switches and ceiling lights. Add the locations of water taps and the hot water cylinder if you know them.",
 ff:"In NZ, electrical wiring work must be done by a licensed electrician — it is illegal (and dangerous) for unlicensed people to do it. However, understanding how your home's electrical and plumbing systems work is valuable for everyone."},
]},
{id:"orthodox",name:"Orthodox Bible Study",emoji:"☩",color:P.byz,tagline:"The Scriptures read within the living Tradition of the Church.",
lessons:[
{id:"ob1",title:"The Bible in the Orthodox Church",age:"5–10",dur:"30 min",
 content:"The Orthodox Church reads the Bible inside the living Tradition — the Scriptures were written by the Church, belong to the Church, and are interpreted by the Church through the Holy Fathers. The Orthodox Old Testament uses the Septuagint (Greek translation, ~250 BC) — the Bible Jesus and the Apostles used.",
 vsearch:"Introduction to the Bible Orthodox perspective",res:"https://www.oca.org",
 act:"In an Orthodox Study Bible, compare the books of the Septuagint OT with a Protestant Bible. Note the additional books. Learn the NT order: 4 Gospels, Acts, 7 Catholic Epistles, 14 Pauline Epistles, Revelation.",
 ff:"The Septuagint (LXX) was the Bible Jesus and the Apostles quoted. When NT writers quote the OT, they almost always quote the Septuagint Greek translation — not the Hebrew."},
{id:"ob2",title:"The Holy Trinity",age:"5–10",dur:"30 min",
 content:"One God in Three Persons: the Father (unbegotten source), the Son/Logos (eternally begotten of the Father — not created), and the Holy Spirit (eternally proceeding from the Father). Defined at the First Ecumenical Council of Nicaea (325 AD) and expressed in the Nicene Creed.",
 vsearch:"Holy Trinity explained Orthodox children",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/doctrine-scripture/the-holy-trinity",
 act:"Learn the Nicene Creed by heart — one line per day. Find within the Creed: references to the Father, to the Son (multiple lines — count them), to the Holy Spirit.",
 ff:"The Nicene Creed was composed in 325 AD and expanded in 381 AD. It is sung or recited at every Orthodox Divine Liturgy worldwide. Over 1,700 years later, not a word has been changed."},
{id:"ob3",title:"The Nicene Creed: Learning It by Heart",age:"6–10",dur:"45 min",
 content:"I believe in one God, the Father Almighty, Maker of heaven and earth and of all things visible and invisible. And in one Lord Jesus Christ, the Son of God, the Only-begotten... And in the Holy Spirit, the Lord, the Giver of Life... This is the symbol (symbolon = agreement) of the Orthodox Faith.",
 vsearch:"Nicene Creed Orthodox children sung",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/worship/the-divine-liturgy/nicene-creed",
 act:"Copy out the Nicene Creed in your best handwriting. Memorise one clause per day for 2 weeks. Recite the entire Creed from memory. 318 bishops at Nicaea defined this faith.",
 ff:"At Nicaea (325 AD), 318 bishops settled whether Christ is fully God or a created being. St Athanasius said He is of one substance (homoousios) with the Father. The 318 bishops agreed — and the world changed."},
{id:"ob4",title:"The Divine Liturgy",age:"6–10",dur:"45 min",
 content:"The Orthodox Divine Liturgy is the central act of Christian worship, celebrated every Sunday and feast day. Written substantially by St Basil the Great and St John Chrysostom in the 4th century. It begins: Blessed is the Kingdom of the Father and of the Son and of the Holy Spirit. It is the Church's participation in the eternal worship of angels around God's throne.",
 vsearch:"Orthodox Divine Liturgy explained children",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/worship/the-divine-liturgy",
 act:"Obtain a printed Divine Liturgy. Find and highlight: the Trisagion (Holy God, Holy Mighty, Holy Immortal), the Nicene Creed, the Lord's Prayer, the Cherubic Hymn. Read each slowly.",
 ff:"When the ambassadors of St Vladimir of Kiev attended the Liturgy at Hagia Sophia in 987 AD, they reported: We did not know whether we were in heaven or on earth. This experience led to the conversion of Russia to Christianity."},
{id:"ob5",title:"The Twelve Great Feasts",age:"6–10",dur:"30 min",
 content:"Twelve Great Feasts plus Pascha (Easter — the Feast of Feasts): Nativity of the Theotokos (Sep 8), Exaltation of the Cross (Sep 14), Presentation of the Theotokos (Nov 21), Nativity of Christ (Dec 25), Theophany (Jan 6), Presentation of Christ (Feb 2), Annunciation (Mar 25), Palm Sunday, Ascension, Pentecost, Transfiguration (Aug 6), Dormition (Aug 15).",
 vsearch:"Orthodox Church Year Great Feasts explained children",res:"https://www.oca.org/feasts-and-saints",
 act:"Make a Church Year calendar starting from September (the Orthodox New Year). Mark all 12 Great Feasts and Pascha. Find an icon for each feast.",
 ff:"The Orthodox Church year begins on 1 September — the traditional date when God began creating the world. The entire year is a spiral journey through the life of Christ and His saints."},
{id:"ob6",title:"Pascha: The Feast of Feasts",age:"5–10",dur:"1 hour",
 content:"Pascha (Easter) is the central event of the Christian year — the Feast of Feasts. All of Great Lent, Holy Week, and the 40 days of Pascha revolve around this truth: Christ is Risen from the dead, trampling down death by death, and upon those in the tombs bestowing life.",
 vsearch:"Orthodox Easter Pascha explained for children",res:"https://www.oca.org/feasts-and-saints/lives/the-holy-pascha-of-our-lord-jesus-christ",
 act:"Memorise the Paschal Troparion: Christ is risen from the dead, trampling down death by death, and upon those in the tombs bestowing life. In Greek: Χριστὸς Ἀνέστη ἐκ νεκρῶν...",
 ff:"The Paschal service: the entire congregation stands in complete darkness at midnight. The priest emerges with a single candle — the light of Christ. This has happened every year for 2,000 years."},
{id:"ob7",title:"Great Lent: A Season of Healing",age:"7–10",dur:"30 min",
 content:"Great Lent is the 40-day fast before Pascha. During Lent: no meat, dairy, fish, oil or wine Monday–Friday; oil and wine permitted on Saturdays and Sundays; fish permitted on the Annunciation (Mar 25) and Palm Sunday. The 40 days echo Moses on Sinai, Elijah's journey, and Christ's 40 days in the wilderness.",
 vsearch:"Great Lent explained Orthodox families children",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/worship/fasting-and-abstinence",
 act:"Create a Lenten preparation list: three acts of repentance, three acts of prayer, three acts of almsgiving. Begin one from each category this week.",
 ff:"In Scripture, 40 always means a period of testing and preparation for something greater: Noah's 40 days of rain, Moses's 40 days on Sinai, Israel's 40 years in the desert, Christ's 40 days fasting."},
{id:"ob8",title:"The Jesus Prayer",age:"7–10",dur:"30 min",
 content:"Lord Jesus Christ, Son of God, have mercy on me, a sinner. The heart of the Hesychast tradition. Synchronised with breathing: breathe in — Lord Jesus Christ Son of God; breathe out — have mercy on me a sinner. Often counted on a prayer rope (komboskini).",
 vsearch:"The Jesus Prayer Orthodox explained",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/prayer/the-jesus-prayer",
 act:"Pray the Jesus Prayer 33 times (once for each year of Christ's earthly life) using fingers or a small prayer rope. Then sit in silence for 5 minutes. What did you notice?",
 ff:"The Way of a Pilgrim is a 19th-century Russian classic describing a peasant who learns to pray the Jesus Prayer without ceasing. One of the most widely read books in the Orthodox tradition."},
{id:"ob9",title:"Holy Icons: Windows into Heaven",age:"5–10",dur:"30 min",
 content:"An icon (from Greek eikon = image) is theology in visual form. Icons use: inverse perspective (the icon looks at you), golden background (uncreated divine light), stylised figures (showing the transfigured, resurrected body). When you pray before an icon, you pray to the Person depicted — not to the image itself.",
 vsearch:"Orthodox Icons explained for children",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/worship/icons",
 act:"Study one icon for 15 minutes. Write down: what colours are used and what they might mean. What gestures do you see? What letters are inscribed? What does the golden background represent?",
 ff:"The Seventh Ecumenical Council (787 AD) defined Orthodox theology of icons: making an icon of Christ affirms the Incarnation — He truly became flesh. Refusing to make icons of Christ implies His body was unreal."},
{id:"ob10",title:"The Theotokos: God-Bearer",age:"6–10",dur:"30 min",
 content:"The Orthodox Church calls the Virgin Mary Theotokos — God-bearer or Mother of God. This title was defined at the Third Ecumenical Council of Ephesus in 431 AD. It is primarily a statement about Christ: since Jesus is fully God and fully human, His mother is truly the Mother of God.",
 vsearch:"Theotokos Mother of God Orthodox explained children",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/doctrine-scripture/the-holy-theotokos",
 act:"Learn the Theotokion: It is truly meet to bless thee, O Theotokos, ever-blessed and most pure... This ancient hymn is sung at every Divine Liturgy. Memorise the first two lines this week.",
 ff:"More honourable than the Cherubim and beyond compare more glorious than the Seraphim — these words declare that Mary, a human being, is more honoured than the highest angelic orders. This is what the Incarnation means for all humanity."},
{id:"ob11",title:"The Holy Fathers",age:"8–10",dur:"30 min",
 content:"The Holy Fathers are those through whom the Holy Spirit has guided the Church's understanding of Scripture and Tradition. Key Fathers: Apostolic Fathers (1st–2nd cent), Desert Fathers (3rd–4th cent), Cappadocian Fathers (St Basil, St Gregory of Nazianzus, St Gregory of Nyssa). Reading the Fathers is reading with the Church — not alone.",
 vsearch:"Church Fathers Orthodox introduction children",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/doctrine-scripture",
 act:"Memorise one saying from the Desert Fathers: A brother came to Abba Moses and asked for a word. He said: Go and sit in your cell, and your cell will teach you everything.",
 ff:"The Sayings of the Desert Fathers (Apophthegmata Patrum), collected in Egypt in the 4th–5th centuries, is still one of the most read books in the Orthodox world. Short, piercing, and inexhaustible."},
{id:"ob12",title:"The Seven Holy Mysteries (Sacraments)",age:"7–10",dur:"45 min",
 content:"The Seven Holy Mysteries: Holy Baptism (triple immersion — entrance into the Church), Holy Chrismation (gift of the Holy Spirit), Holy Eucharist (Body and Blood of Christ), Holy Confession (forgiveness of sins), Holy Unction (healing of soul and body), Holy Matrimony, Holy Orders. Through the Mysteries, heaven touches earth.",
 vsearch:"Seven Sacraments Orthodox explained children",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/worship/the-seven-sacraments",
 act:"Draw a diagram of the Seven Holy Mysteries. Write a one-sentence explanation of each in your own words. Which have you received?",
 ff:"Holy Baptism in the Orthodox Church is by triple immersion — three times, in the name of the Father and of the Son and of the Holy Spirit. Immersion = death to the old life. Emergence = resurrection to new life."},

{id:"ob13",title:"The Psalter in Orthodox Worship",age:"7–10",dur:"30 min",
 content:"The Psalter (Book of Psalms) is the prayer book of the Orthodox Church. All 150 Psalms are read or sung every week in monastic communities. The Psalter is divided into 20 sections called kathismata. Psalms accompany every service, every meal, every major life event. The Church breathes in Scripture and breathes out prayer — and both are the Psalms.",
 vsearch:"Orthodox Psalter Psalms worship for children",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/worship",
 act:"Read Psalm 1, 23, 91, 100 and 150 aloud as a family this week. Choose one to memorise. Notice how each psalm expresses a different emotion or situation.",
 ff:"St Athanasius the Great wrote that while all other Scripture speaks to us, the Psalms speak for us — they are the words we speak to God. The Psalms are not about God; they are addressed to God."},
{id:"ob14",title:"The Lord's Prayer: Line by Line",age:"6–10",dur:"45 min",
 content:"Our Father who art in heaven (God is our Father, in transcendence). Hallowed be Thy name (His name is holy — let my life reflect that). Thy kingdom come (I choose His reign over mine). Thy will be done (I surrender my agenda). Give us this day our daily bread (trust for today only). Forgive us as we forgive others (mercy flows from those who receive it).",
 vsearch:"Lord's Prayer explained line by line for children Orthodox",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/worship",
 act:"Take each petition of the Lord's Prayer and rewrite it in your own words — what does 'Thy kingdom come' look like in your family today? What bread do you actually need?",
 ff:"The Lord's Prayer is the most widely prayed prayer in history — spoken every day by over a billion people in hundreds of languages. Its words have not changed since Jesus taught them."},
{id:"ob15",title:"The Beatitudes in Orthodox Worship",age:"7–10",dur:"30 min",
 content:"The Beatitudes (Matthew 5:3-12) are sung at the Divine Liturgy as part of the Third Antiphon. They frame the entire Liturgy — we enter heaven through the path Jesus described: poverty of spirit, mourning, meekness, hunger for righteousness, mercy, purity, peacemaking, and the willingness to suffer for the truth.",
 vsearch:"Beatitudes Orthodox Liturgy for children",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/worship/the-divine-liturgy",
 act:"Write each Beatitude on a card. Arrange them in order. Discuss: which one is most countercultural in the modern world? Which one is most difficult to live?",
 ff:"Orthodox iconography sometimes depicts the Beatitudes as a staircase leading upward — each one a step higher in the spiritual life, not a separate virtue but a progression of transformation."},
{id:"ob16",title:"The Prodigal Son: A Parable of Repentance",age:"6–10",dur:"45 min",
 content:"Luke 15:11-32 is called by the Orthodox Church the Parable of the Compassionate Father. A son demands his inheritance, wastes it, comes to his senses, and returns expecting to be made a servant. The father runs to him, restores him to sonship, and throws a feast. The older brother cannot rejoice. This parable is read on the Sunday of the Prodigal Son during the pre-Lenten Triodion.",
 vsearch:"Prodigal Son Orthodox parable children animated",res:"https://www.oca.org",
 act:"Read Luke 15:11-32 aloud. Act it out with family members taking each role. Discuss: which character do you most identify with — the younger son, the older son, or the father? Why?",
 ff:"The Sunday of the Prodigal Son is one of the four preparatory Sundays before Great Lent in the Orthodox Church. The Church reads this parable to remind us that however far we have wandered, the Father is already running toward us."},
{id:"ob17",title:"Theophany: The Baptism of Christ",age:"6–10",dur:"30 min",
 content:"Theophany (January 6) celebrates the Baptism of Christ in the Jordan River — one of the Twelve Great Feasts. At this moment the Holy Trinity was fully revealed: the Son stood in the waters, the Holy Spirit descended as a dove, and the Father spoke from heaven: This is My beloved Son, in whom I am well pleased.",
 vsearch:"Theophany Baptism of Christ Orthodox for children",res:"https://www.oca.org/feasts-and-saints/lives/the-holy-theophany-of-our-lord-god-and-saviour-jesus-christ",
 act:"Research the Great Blessing of Waters performed at Theophany. What is the priest doing? Why is water blessed? Where are the blessed waters used throughout the year?",
 ff:"At Theophany, Orthodox priests bless the nearest body of water — ocean, river, lake or harbour — by plunging a cross into it three times. In Russia, worshippers plunge into ice-cold water as an act of faith."},
{id:"ob18",title:"The Transfiguration of Christ",age:"7–10",dur:"30 min",
 content:"The Transfiguration (August 6) is one of the Twelve Great Feasts. Jesus took Peter, James and John up a high mountain. Before them He was transfigured — His face shone like the sun, His clothes became dazzling white. Moses and Elijah appeared with Him. This feast celebrates the uncreated light of God that surrounded Christ — a light the saints share in after purification.",
 vsearch:"Transfiguration of Christ Orthodox feast children",res:"https://www.oca.org/feasts-and-saints/lives/the-holy-transfiguration-of-our-lord-god-and-saviour-jesus-christ",
 act:"Find or draw an icon of the Transfiguration. Notice the three apostles falling in awe. Notice Moses and Elijah. Notice the light emanating from Christ. Write a short reflection: what does it mean to be transfigured?",
 ff:"St Gregory Palamas (14th century) taught that the light of the Transfiguration was the uncreated energy of God Himself — the same light that can fill the heart of a person through prayer and fasting. This is called the hesychast theology of light."},
{id:"ob19",title:"The Cross: Exaltation & Veneration",age:"6–10",dur:"30 min",
 content:"The Exaltation of the Holy Cross on September 14 is one of the Twelve Great Feasts. This commemorates the finding of the True Cross by St Helena (mother of Emperor Constantine) in Jerusalem in 326 AD. The cross is not an instrument of shame but the throne of glory — the place where death was defeated.",
 vsearch:"Exaltation of the Holy Cross Orthodox feast children",res:"https://www.oca.org/feasts-and-saints/lives/the-universal-exaltation-of-the-precious-and-life-giving-cross",
 act:"Make a cross from two sticks tied with twine. Decorate with sweet basil (traditionally placed on the cross at this feast). Research: why does the Orthodox cross have three crossbars instead of one?",
 ff:"The Orthodox cross has three crossbars: the top is the title board (INRI), the middle is the main crossbar, and the angled lower bar is the footrest — tilted to show one thief ascending to paradise, one descending."},
{id:"ob20",title:"Prayer Rope & Unceasing Prayer",age:"7–10",dur:"30 min",
 content:"The komboskini (Greek) or chotki (Russian) is a knotted prayer rope used to count repetitions of the Jesus Prayer. It typically has 33, 50, or 100 knots. Each knot is tied in a special way with 7 crosses woven into it. The tradition comes from 1 Thessalonians 5:17: Pray without ceasing.",
 vsearch:"Orthodox prayer rope komboskini Jesus Prayer",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/prayer/the-jesus-prayer",
 act:"Make a simple prayer rope from thick wool. Tie 10 knots. Use it to pray the Jesus Prayer slowly, one prayer per knot. Sit in silence afterward for 3 minutes.",
 ff:"St Hesychios the Priest wrote in the 5th century: Unceasing watchfulness and the Jesus Prayer — these two are the foundation of the inner life. A person who has these will not be shaken by any storm."},
{id:"ob21",title:"St John of Kronstadt: Priest & Wonderworker",age:"8–10",dur:"30 min",
 content:"St John of Kronstadt (1829-1908) was a Russian Orthodox priest renowned for his pastoral zeal, miraculous healings and writing. He served daily Liturgy throughout his 53-year priesthood. He opened his home to the poor, gave away everything he owned constantly, and wrote the spiritual classic 'My Life in Christ.' His feast is December 20.",
 vsearch:"St John of Kronstadt story for children Orthodox",res:"https://www.oca.org/saints/lives/right-believing-john-of-kronstadt",
 act:"Read one excerpt from 'My Life in Christ' (available free online). Write one sentence that challenges you or that you want to remember. Pray: O holy John of Kronstadt, pray for us.",
 ff:"St John of Kronstadt wrote: I must not forget that love is the greatest gift of God. He who has love has everything. He who has it not has nothing, however many other gifts he may possess."},
{id:"ob22",title:"The Annunciation: Mary's Yes",age:"6–10",dur:"30 min",
 content:"The Annunciation (March 25) is one of the Twelve Great Feasts. The angel Gabriel appeared to Mary and announced that she would conceive and bear the Son of God. Mary's response — 'Behold the handmaid of the Lord; be it done unto me according to thy word' (Luke 1:38) — is the most consequential yes in history.",
 vsearch:"Annunciation feast Orthodox for children",res:"https://www.oca.org/feasts-and-saints/lives/the-annunciation-of-our-most-holy-lady-the-theotokos",
 act:"Find or draw an icon of the Annunciation. Notice Mary's posture — some icons show her startled, others calm and accepting. Notice the angel. What does the gesture of each figure communicate?",
 ff:"In Byzantine theology, the Annunciation is the moment of the Incarnation — the eternal Son of God took on human flesh in Mary's womb at that precise instant. Christmas celebrates His birth; the Annunciation celebrates His becoming human."},
{id:"ob23",title:"Holy Week Day by Day",age:"7–10",dur:"45 min",
 content:"Holy Week is the most sacred week of the Orthodox year. Palm Sunday: triumphant entry into Jerusalem. Holy Monday-Wednesday: teachings and parables. Holy Thursday: Last Supper, betrayal, Garden of Gethsemane. Holy Friday: crucifixion and burial. Holy Saturday: Christ in the tomb. Pascha Midnight: Resurrection!",
 vsearch:"Holy Week Orthodox for children Palm Sunday Pascha",res:"https://www.oca.org/feasts-and-saints/lives/the-holy-pascha-of-our-lord-jesus-christ",
 act:"Make a Holy Week calendar. For each day, write one key event and one hymn or prayer specific to that service. If possible, attend as many Holy Week services as you can.",
 ff:"The Lamentations sung at Holy Friday Vespers over the Epitaphion (the cloth icon of Christ's body) are among the most beautiful and sorrowful music ever composed. They have been sung continuously in Orthodox churches since at least the 12th century."},
{id:"ob24",title:"The Apostle Paul's Letters",age:"8–10",dur:"45 min",
 content:"St Paul wrote 14 letters (epistles) in the New Testament. They were written before the Gospels and are the earliest Christian writings we have. Key letters: Romans (the Gospel explained systematically), 1 Corinthians (problems in a young church), Galatians (grace vs law), Philippians (joy from prison). Paul's letters are read at every Divine Liturgy.",
 vsearch:"Apostle Paul's letters epistles for children",res:"https://www.oca.org",
 act:"Read Philippians 4:4-13 aloud. These 10 verses contain: a command to rejoice, a promise about peace, and the famous verse I can do all things through Christ who strengthens me. Memorise verses 4 and 13.",
 ff:"St Paul wrote most of his letters from prison. Philippians — the epistle of joy — was written while Paul was chained to a Roman guard, awaiting possible execution. The joy he describes is not dependent on circumstances."},
{id:"ob25",title:"How an Icon is Written",age:"7–10",dur:"45 min",
 content:"Icons are not painted — they are written (Greek graphein means to write). The iconographer prepares the wood with gesso, then lays down gold background (the divine light) first, then darkest tones, then highlights last (light breaking through). The iconographer fasts and prays before writing. The icon is signed with the subject's name, not the artist's — the iconographer is transparent.",
 vsearch:"how icons are written Orthodox iconography for children",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/worship/icons",
 act:"Try egg tempera painting (1 egg yolk + a few drops of water + powdered pigment). Paint a simple cross or basic geometric design on a small board or heavy paper. Notice how different it feels from normal painting.",
 ff:"The oldest known icons date to the 6th century and are preserved at the Monastery of St Catherine in Sinai, Egypt — the oldest continuously inhabited Christian monastery in the world, founded in 565 AD and still functioning today."},
{id:"ob26",title:"The Desert Fathers & Mothers",age:"8–10",dur:"30 min",
 content:"In the 3rd and 4th centuries, thousands of Christians fled to the desert of Egypt and Syria to live in prayer, fasting and silence. The most famous are: St Antony the Great (father of monasticism, lived to 105), St Mary of Egypt, St Moses the Ethiopian (former bandit who became a holy monk), St Syncletica (who led a community of female ascetics). Their sayings are still read daily in monasteries.",
 vsearch:"Desert Fathers and Mothers Orthodox for children",res:"https://www.oca.org",
 act:"Read 5 sayings from the Desert Fathers (easily found online). Write down the one that most challenges you. Discuss: what did these people give up? What did they gain?",
 ff:"One of the most famous sayings: A brother said to Abba Arsenius, My thoughts trouble me saying you can neither fast nor work. But the elder seeing the snares of the devil, said: Go, eat, drink, sleep — only do not leave your cell."},
{id:"ob27",title:"Confession & Repentance",age:"7–10",dur:"30 min",
 content:"Holy Confession (Pokaianie — repentance) is one of the Seven Holy Mysteries. The Orthodox Christian stands before an icon of Christ, with the priest as a witness — not a judge. The priest does not forgive sins; God forgives. Confession requires: examination of conscience, sincere sorrow, confession of specific sins, and the firm intention to change.",
 vsearch:"Orthodox Confession repentance for children",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/worship/the-seven-sacraments",
 act:"Write a short examination of conscience: 5 things you have done that were wrong; 3 things you should have done but did not; 1 relationship that needs repair. This is the beginning of confession, not the end.",
 ff:"St John Climacus wrote: The beginning of repentance is to accuse oneself. Repentance is an ongoing way of life for the Orthodox Christian. The word in Greek is metanoia — literally 'change of mind' or 'change of direction.'"},
{id:"ob28",title:"Pentecost: The Birthday of the Church",age:"6–10",dur:"30 min",
 content:"Pentecost (50 days after Pascha) is one of the Twelve Great Feasts. The Holy Spirit descended on the Apostles as tongues of fire and they began speaking in other languages. 3,000 people were baptised that day — the birth of the Church. The Orthodox Pentecost service includes kneeling for the first time since Pascha (kneeling is forbidden during the Paschal season as a sign of the Resurrection).",
 vsearch:"Pentecost Orthodox feast Holy Spirit for children",res:"https://www.oca.org/feasts-and-saints/lives/pentecost",
 act:"Read Acts 2:1-41. Count: how many different nations heard their own language spoken? How many were baptised? Make a mini-sermon outline of Acts 2:14-39.",
 ff:"The Orthodox Church uses green for Pentecost — the colour of renewal, life and the Holy Spirit. Worshippers hold green branches and flowers. The icon of Pentecost shows the Apostles in a semicircle with a dark space at the bottom representing the world waiting for the Gospel."},

{id:"ob29",title:"The Great Litany: Praying for the World",age:"7–10",dur:"30 min",
 content:"The Divine Liturgy begins with the Great Litany — a series of prayer petitions chanted by the deacon, with the choir responding Kyrie eleison (Lord have mercy) after each one. The petitions move outward: for peace from above, for the Church, for clergy, for civil authorities, for the city, for travellers, for the sick, for those in captivity, for fine weather and good harvest, for our deliverance from affliction. The whole world is held in prayer.",
 vsearch:"Great Litany Orthodox Divine Liturgy explained for children",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/worship/the-divine-liturgy",
 act:"Read through the full text of the Great Litany (available free online). Write down every category of person or thing being prayed for. How many different groups are included? Then pray the Litany slowly yourself.",
 ff:"The Great Litany of the Orthodox Liturgy is essentially unchanged from the earliest liturgical sources (4th-5th century). For 1,600 years, Orthodox Christians have prayed for fine weather, good harvests, travellers and captives at every Sunday Liturgy — a continuous thread of intercession for the whole world."},
{id:"ob30",title:"The Book of Job: Suffering & Faith",age:"8–10",dur:"45 min",
 content:"The Book of Job addresses the hardest question in theology: why do good people suffer? Job loses his children, wealth and health — yet refuses to curse God. His three friends argue that suffering must be punishment for sin. God's answer from the whirlwind is not a logical explanation but a revelation of His majesty and power. Job is restored. The Orthodox Church reads Job during Holy Week — Christ is the true Job, the innocent sufferer.",
 vsearch:"Book of Job explained for children Orthodox",res:"https://www.oca.org",
 act:"Read Job 1:1-22 and Job 38:1-18 (God's answer from the whirlwind). In Job 1: what happened? How did Job respond? In Job 38: what does God ask Job? Why might these questions be an answer to suffering?",
 ff:"The book of Job is considered by many scholars to be the oldest book in the Bible — possibly predating even Genesis in its written form. It has been read, argued over, and prayed through by Jews and Christians for over 3,000 years. No other book addresses suffering with such unflinching honesty."},
{id:"ob31",title:"Icons of the Theotokos: Hodigitria & Orans",age:"6–10",dur:"30 min",
 content:"There are many types of icons of the Theotokos (Virgin Mary). The Hodigitria (She who shows the Way) depicts Mary pointing to Christ with one hand — she is always pointing to Him, never to herself. The Orans (Praying) shows Mary with arms raised in prayer, sometimes with Christ in a medallion on her chest. The Eleusa (Tender Mercy) shows Mary and Christ cheek to cheek. Each type captures a different aspect of her relationship with her Son.",
 vsearch:"Icons of the Theotokos types Orthodox for children",res:"https://www.oca.org/orthodoxy/the-orthodox-faith/worship/icons",
 act:"Find an example of each type of Theotokos icon (Hodigitria, Orans, Eleusa). For each, write: what is Mary doing with her hands? What does her expression say? What does her gesture communicate about her relationship with Christ?",
 ff:"The Vladimir Mother of God icon (Eleusa type, dated to the early 12th century and currently in the Tretyakov Gallery in Moscow) is considered one of the most sacred objects in Russia. It was credited with saving Moscow from Mongol invasion three times. It is one of the most reproduced images in human history."},
{id:"ob32",title:"St Seraphim of Sarov: Joy & the Holy Spirit",age:"7–10",dur:"30 min",
 content:"St Seraphim of Sarov (1754-1833) is one of the most beloved saints of the Russian Orthodox Church. He lived as a hermit for many years in the forest, greeting everyone who came to him with Christos Voskrese (Christ is Risen) regardless of the time of year, and calling everyone 'my joy.' He said the aim of the Christian life is the acquisition of the Holy Spirit. He is depicted holding a censer and wearing a white monastic robe.",
 vsearch:"St Seraphim of Sarov story for children Orthodox",res:"https://www.oca.org/saints/lives/our-venerable-father-seraphim-of-sarov",
 act:"Read about St Seraphim greeting everyone with 'Christ is Risen' all year round. Try it this week — greet every family member with Christos Anesti! What response do you get? Practise his teaching: find something to be joyful about today even if it is difficult.",
 ff:"St Seraphim said: Acquire the spirit of peace and a thousand souls around you will be saved. He also said to a young disciple: Do not grieve the Holy Spirit by any sin. These two instructions — seek peace, avoid sin — are his entire spiritual programme in two sentences."},
{id:"ob33",title:"The Sermon on the Mount: Living the Beatitudes",age:"7–10",dur:"45 min",
 content:"The Sermon on the Mount (Matthew 5-7) is Jesus's most complete teaching on how to live. After the Beatitudes come: salt and light (we are agents of preservation and revelation), the higher righteousness (not just avoiding murder but avoiding anger; not just avoiding adultery but avoiding lust), the Lord's Prayer, fasting and giving in secret, the wise and foolish builders. The entire Sermon assumes the listener wants to live this way.",
 vsearch:"Sermon on the Mount for children Orthodox",res:"https://www.oca.org",
 act:"Read Matthew 5-7 in one sitting. Which verse or teaching most challenges you personally? Write it out. Memorise it. Try to apply it for one week. Report back: was it easier or harder than expected?",
 ff:"The Orthodox Church reads the Sermon on the Mount in sections during the Divine Liturgy throughout the year. St John Chrysostom wrote extensive homilies (sermons) on every verse of the Sermon on the Mount — they are still read by Orthodox Christians today, 1,600 years later."},
{id:"ob34",title:"Holy Week: Bridegroom Matins",age:"7–10",dur:"30 min",
 content:"The first three days of Holy Week (Monday, Tuesday, Wednesday) are marked by Bridegroom Matins — a service held in the evening with the lights dimmed, the icon of Christ as the Bridegroom (bound, crowned with thorns, yet kingly) on the analogion. The central hymn: Behold, the Bridegroom comes at midnight, and blessed is the servant whom He shall find watching. The parable of the Wise and Foolish Virgins is at the heart of this service.",
 vsearch:"Bridegroom Matins Orthodox Holy Week for children",res:"https://www.oca.org/feasts-and-saints/lives/the-holy-pascha-of-our-lord-jesus-christ",
 act:"Read the Parable of the Ten Virgins (Matthew 25:1-13). What does the oil represent? What does the delay represent? What does the midnight arrival represent? How do you prepare for something you do not know the timing of?",
 ff:"The Bridegroom icon depicts Christ dressed as a Byzantine emperor but bound, humiliated, and wearing a crown of thorns. This paradox — king and captive, divine and suffering, glorious and mocked — is at the heart of the Orthodox theology of the Cross."},
{id:"ob35",title:"The Church Calendar: Living by Sacred Time",age:"7–10",dur:"30 min",
 content:"The Orthodox Church calendar is a complete alternative structure of time — feasts, fasts, commemorations of saints, seasons of preparation and celebration. The year begins on 1 September (the Indiction), reaches its climax at Pascha, and spirals through the 12 Great Feasts, 4 major fasts, and hundreds of saints' days. To live by the Church calendar is to orient your entire life around the life of Christ.",
 vsearch:"Orthodox Church calendar explained for families children",res:"https://www.oca.org/feasts-and-saints",
 act:"Create a full-year Orthodox Church calendar on a large piece of paper. Mark: all 12 Great Feasts, the 4 fasting periods (Great Lent, Apostles Fast, Dormition Fast, Nativity Fast), the first day of each month with its patron saint. Display it in your home.",
 ff:"The Orthodox Julian calendar (used by some Orthodox churches) is currently 13 days behind the Gregorian calendar used by most of the world. This means that some Orthodox Christians celebrate Christmas on January 7 (Gregorian) — which is December 25 on the Julian calendar. The date is the same; only the counting differs."},
{id:"ob36",title:"A Year of Faith: Looking Back & Forward",age:"All",dur:"1 hour",
 content:"Looking back over a year of Orthodox Bible Study: we have covered the Trinity, the Creed, the Divine Liturgy, the Great Feasts, Pascha, Great Lent, the Jesus Prayer, Holy Icons, the Theotokos, the Holy Fathers, the Seven Holy Mysteries, the Psalter, the Lord's Prayer, the Beatitudes, the Prodigal Son, Theophany, the Transfiguration, the Cross, and many saints. This is not the end — it is one full circle of the Liturgical year.",
 vsearch:"Orthodox faith year review reflection for families",res:"https://www.oca.org",
 act:"Write or draw: What is the most important thing you have learned about the Orthodox faith this year? What question do you still have? What practice has most changed your daily life? What do you want to learn next?",
 ff:"The Orthodox Church does not teach that Christian formation is ever complete — it is a lifelong, unending journey. The Greek word for this journey is theosis: the gradual union of the human person with God, by grace. St Athanasius wrote: God became man so that man might become God. This is the destination of every Orthodox life — and it has no end."},
]},
];

// ─── STORAGE ───────────────────────────────────────────────────────────────
const SUBJECTS_LITTLE = [
{id:"greek",name:"Greek Language",emoji:"🏛️",color:P.byz,tagline:"The language the angels sing!",
lessons:[
{id:"gl1",title:"Yia Sou! Hello!",age:"2–5",dur:"15 min",
 content:"Yia sou means hello in Greek! Kalimera means good morning. Orthodox Christians all over the world say these words. When you say a Greek word you speak the same language as the angels in church!",
 vsearch:"Greek hello song for toddlers",res:"https://www.youtube.com/results?search_query=Greek+hello+song+toddlers",
 act:"Wave to everyone in the house today and say Yia sou! When you wake up tomorrow say Kalimera! Can you teach it to a stuffed animal?",
 ff:"Kalimera means good morning — kali means good and mera means day. Every morning God gives us a good day as a gift!"},
{id:"gl2",title:"Alpha and Omega",age:"2–5",dur:"15 min",
 content:"The first Greek letter is Alpha — it says 'ah'! The last letter is Omega — it says 'oh'. Jesus says I am the Alpha and the Omega — the very beginning and the very end of everything!",
 vsearch:"Greek Alpha Omega for little kids song",res:"https://www.youtube.com/results?search_query=Greek+Alpha+Omega+little+kids",
 act:"Draw a big A and a big O with fat crayons. Say Alpha! and Omega! out loud. Draw a picture of Jesus and put the letters beside Him — just like on an icon.",
 ff:"On Orthodox icons of Jesus you sometimes see IC XC — short for Jesus Christ in Greek. Now you are starting to read icon language!"},
{id:"gl3",title:"Ena Thio Tria! 1 2 3!",age:"2–5",dur:"15 min",
 content:"Let us count in Greek! Ena is 1, Thio is 2, Tria is 3, Tessera is 4, Pende is 5. Three is the holiest number — Father, Son and Holy Spirit! When we make the sign of the cross we use three fingers for the Trinity.",
 vsearch:"Greek numbers 1 2 3 song for toddlers",res:"https://www.youtube.com/results?search_query=Greek+numbers+1+2+3+toddlers",
 act:"Count your fingers in Greek: Ena, Thio, Tria, Tessera, Pende! Count your toes. Count the candles at church. Count your family members in Greek!",
 ff:"The number 3 is so holy that the Trisagion prayer says Holy three times — Holy God, Holy Mighty, Holy Immortal! Three is everywhere in the life of the Church."},
{id:"gl4",title:"Kyrie Eleison: Lord Have Mercy",age:"2–5",dur:"15 min",
 content:"Kyrie eleison means Lord have mercy. It is the most important prayer we sing in church — we sing it again and again. Kyrie means Lord and eleison means have mercy — like the biggest warmest hug from God. Even very small children can pray this!",
 vsearch:"Kyrie Eleison simple chant for little children",res:"https://www.youtube.com/results?search_query=Kyrie+eleison+chant+little+children",
 act:"Sing Kyrie eleison softly three times with a parent. Then sit quietly with eyes closed for a moment. You can say Kyrie eleison any time — when scared, when happy, when falling asleep.",
 ff:"Monks and nuns pray Kyrie eleison hundreds of times every day. Now you pray it too — you are praying with all the monks around the world!"},
{id:"gl5",title:"Red Blue and Gold",age:"2–5",dur:"15 min",
 content:"Kokkino means red, ble means blue, chryso means gold. In church icons, red means God's love, blue means heaven, and gold means God's light — that beautiful shining background on every icon!",
 vsearch:"Greek colours red blue gold little kids",res:"https://www.youtube.com/results?search_query=Greek+colours+red+blue+gold+kids",
 act:"Look at an icon together. Point to the kokkino, the ble, and the chryso. Then colour a cross shape using all three colours.",
 ff:"The gold on icons is real gold leaf pressed onto the wood. It never fades. Gold represents the eternal light of God that never goes out."},
{id:"gl6",title:"Efharisto: Thank You!",age:"2–5",dur:"15 min",
 content:"Efharisto means thank you in Greek! It is also the name for the most special part of church — the Eucharist — when we receive Jesus. Saying thank you to God is so precious that the whole service is named after it!",
 vsearch:"Greek thank you efharisto for toddlers",res:"https://www.youtube.com/results?search_query=Greek+thank+you+efharisto+toddlers",
 act:"Say Efharisto every time someone gives you something today. Before bed say: Efharisto Thee mou — thank you, my God! Hold up your hands as you say it.",
 ff:"The Eucharist — Holy Communion — comes from the word efharisto. Every time you say thank you in Greek, you are speaking the language of the most holy moment in the whole church!"},
{id:"gl7",title:"Christos Anesti!",age:"2–5",dur:"15 min",
 content:"Christos Anesti means Christ is Risen! The answer is Alithos Anesti — Truly He is Risen! At Pascha (Easter) the priest shouts it three times at midnight and everyone shouts it back with candles burning!",
 vsearch:"Christos Anesti Easter Orthodox for little children",res:"https://www.youtube.com/results?search_query=Christos+Anesti+Easter+Orthodox+children",
 act:"Call out: CHRISTOS ANESTI! and have everyone shout back: ALITHOS ANESTI! Soft like a whisper. Then loud like a shout! Say it to every person in the house today.",
 ff:"On Pascha night, even the tiniest babies are brought to church for the midnight service. The whole world seems to shout Christ is Risen all at once!"},
{id:"gl8",title:"God is Love",age:"2–5",dur:"15 min",
 content:"O Theos agape estin means God is love in Greek. Theos means God. Agape means the deepest most giving love — the kind that never runs out and never stops. When Mum or Dad hugs you tight, that is a little taste of God's agape love!",
 vsearch:"God is love Bible verse for toddlers",res:"https://www.youtube.com/results?search_query=God+is+love+Bible+verse+toddlers",
 act:"Make a heart shape with your hands. Say: O Theos agape estin — God is love! Then give the biggest hug you can to someone you love.",
 ff:"Agape love in Greek means giving love — love that gives and gives and never asks for anything back. This is the love God showed us when Jesus came."},
{id:"gl9",title:"Hagios: Holy!",age:"2–5",dur:"15 min",
 content:"Hagios means holy in Greek! At church we sing Hagios o Theos — Holy is God! This song called the Trisagion has been sung in churches for over 1,500 years — every single day!",
 vsearch:"Trisagion Holy God children Orthodox simple",res:"https://www.youtube.com/results?search_query=Trisagion+Holy+God+children+Orthodox+simple",
 act:"Sing and clap: HOLY is God! HOLY is the Mighty One! HOLY is the Immortal One! Have mercy on us! Do it three times getting louder each time.",
 ff:"Holy means set apart and full of God's wonderful light. When something is holy it belongs especially to God."},
{id:"gl10",title:"Exi Epta Okto: 6 7 8",age:"2–5",dur:"15 min",
 content:"More Greek numbers! Exi is 6, Epta is 7, Okto is 8. Seven is the holiest number of all — God made the world in 7 days! He worked for 6 days and on the 7th day He rested.",
 vsearch:"Greek numbers 6 7 8 song for kids",res:"https://www.youtube.com/results?search_query=Greek+numbers+6+7+8+song+kids",
 act:"Count 7 toys in Greek: Ena, Thio, Tria, Tessera, Pende, Exi, Epta! Then draw 7 things God made — sun, moon, stars, clouds, trees, animals, people!",
 ff:"The 7th day is called the Sabbath — a day of rest and prayer. We celebrate Sunday as our Sabbath — the day we rest and worship God together."},
{id:"gl11",title:"Kalimera Kalinychta",age:"2–5",dur:"15 min",
 content:"Kalimera means good morning and Kalinychta means good night! These are the first and last words of every monk's day in an Orthodox monastery.",
 vsearch:"Greek good morning good night song children",res:"https://www.youtube.com/results?search_query=Greek+good+morning+good+night+children",
 act:"This week: say Kalimera to every family member at breakfast. Say Kalinychta to every family member at bedtime. Make it a family habit!",
 ff:"In Orthodox monasteries, everyone says Kalimera and Kalinychta to each other every single day. Now your family can do the same!"},
{id:"gl12",title:"Amen!",age:"2–5",dur:"15 min",
 content:"Amen means truly! yes! so be it! We say it at the end of every prayer. When we say Amen we are saying: Yes God, I agree! I believe this! It is the oldest word in our faith.",
 vsearch:"what does Amen mean children toddlers",res:"https://www.youtube.com/results?search_query=what+does+Amen+mean+children+toddlers",
 act:"Pray a little prayer together and say a great big AMEN at the end! Then say a tiny whispered amen. Then a joyful shouted AMEN!",
 ff:"Amen travels unchanged through every language on earth. It is so powerful and true that no one has ever needed to translate it!"},
]},
{id:"maori",name:"Te Reo Maori",emoji:"🥝",color:P.sage,tagline:"The beautiful language of Aotearoa.",
lessons:[
{id:"nzl1",title:"Kia Ora! Hello!",age:"2–5",dur:"15 min",
 content:"Kia ora means hello and thank you and welcome! Morena means good morning. Say kia ora with a big smile and you give the other person a gift of kindness.",
 vsearch:"Kia Ora Maori hello song for toddlers",res:"https://www.youtube.com/results?search_query=Kia+Ora+Maori+hello+song+toddlers",
 act:"Greet everyone in the house today with KIA ORA! and a big wave. Tomorrow morning be first to say MORENA! to your family.",
 ff:"Kia ora means be well or be healthy. Every time you say kia ora you are wishing the other person good health — what a beautiful wish!"},
{id:"nzl2",title:"Tahi Rua Toru! 1 2 3!",age:"2–5",dur:"15 min",
 content:"Counting in Maori! Tahi is 1, Rua is 2, Toru is 3, Wha is 4, Rima is 5! The Maori language has been spoken in Aotearoa for about 700 years — since the first waka (canoe) arrived!",
 vsearch:"Maori numbers 1 2 3 4 5 toddler song",res:"https://www.youtube.com/results?search_query=Maori+numbers+1+2+3+4+5+toddler+song",
 act:"Count 5 of your favourite toys in Maori: tahi, rua, toru, wha, rima! Count your toes. Count the people at dinner.",
 ff:"The number rima means both five and hand in Maori — because we have five fingers on one hand! Your hand is your first counting tool."},
{id:"nzl3",title:"Colours in Maori",age:"2–5",dur:"15 min",
 content:"Whero means red, kikorangi means blue, kakariki means green, kowhai means yellow and ma means white! Kakariki is also the name of the tiny bright green NZ parrot — named after its colour!",
 vsearch:"Maori colours song for toddlers",res:"https://www.youtube.com/results?search_query=Maori+colours+song+toddlers",
 act:"Point to things around the room and say their colour in Maori. Find something whero (red)! Something kikorangi (blue)! Colour a rainbow using each colour's Maori name.",
 ff:"Te kura means school but kura also means red in Maori. Many things in the Maori language carry layers of beautiful meaning hidden inside the words."},
{id:"nzl4",title:"My Body in Maori",age:"2–5",dur:"15 min",
 content:"Upoko means head, kanohi means face, ringaringa means hands, waewae means feet, and manawa means heart and breath! Touch each part as you say the word.",
 vsearch:"body parts Maori song for little children",res:"https://www.youtube.com/results?search_query=body+parts+Maori+song+little+children",
 act:"Play Head Shoulders Knees and Toes but in Maori — upoko (head), pokohiwi (shoulders), turi (knees), waewae (feet)! Slowly then fast then very fast!",
 ff:"The word manawa means both heart and breath. In many languages the words for heart, breath and spirit are connected — because God breathed life into us."},
{id:"nzl5",title:"The Kiwi Bird",age:"2–5",dur:"15 min",
 content:"The kiwi is New Zealand's most special bird — it only lives here! It cannot fly but has an amazing long beak to sniff out worms underground. God made the kiwi extra extra special!",
 vsearch:"kiwi bird for toddlers NZ nature",res:"https://www.youtube.com/results?search_query=kiwi+bird+for+toddlers+NZ+nature",
 act:"Pretend to be a kiwi! Walk slowly on your tiptoes, sniff along the carpet with your nose looking for pretend worms. Then draw a kiwi and colour it brown.",
 ff:"The kiwi lays the biggest egg for its body size of any bird in the whole world! A kiwi egg is about 20% of the mother's weight — kiwi mums are very very strong."},
{id:"nzl6",title:"Whanau: My Family",age:"2–5",dur:"15 min",
 content:"Whanau means family in Maori! Mama means Mum, Papa means Dad, Koroua is grandfather and Kuia is grandmother. Your whanau is the people who love you and look after you.",
 vsearch:"whanau family Maori words song toddlers",res:"https://www.youtube.com/results?search_query=whanau+family+Maori+words+song+toddlers",
 act:"Draw your whanau (family). Under each person write their Maori title — Mama, Papa, Koroua, Kuia, etc. Surprise your grandparents by calling them Koroua and Kuia all day!",
 ff:"In Maori tradition whanau includes not just your immediate family but all your extended family — aunties, uncles, cousins and grandparents. The bigger your whanau the richer you are!"},
{id:"nzl7",title:"Pohutukawa Tree",age:"2–5",dur:"15 min",
 content:"The pohutukawa tree bursts into bright red flowers every December just in time for Christmas! God made it like a special Christmas decoration just for Aotearoa. Say its name: poh-hoo-too-KA-wa!",
 vsearch:"pohutukawa tree NZ Christmas for little kids",res:"https://www.youtube.com/results?search_query=pohutukawa+tree+NZ+Christmas+for+little+kids",
 act:"Clap the syllables: po-hu-tu-ka-wa (5 claps)! Draw a big pohutukawa tree with bright red fluffy flowers all over it.",
 ff:"Some pohutukawa trees are over 1,000 years old! A pohutukawa that flowers today was already ancient when the first Maori arrived in Aotearoa 700 years ago."},
{id:"nzl8",title:"Kai: Food!",age:"2–5",dur:"15 min",
 content:"Kai means food in Maori! Ika means fish, riwai means potato, and kumara means sweet potato. The kumara was the most important food the first Maori brought in their waka when they sailed to Aotearoa!",
 vsearch:"Maori food words kai toddler song",res:"https://www.youtube.com/results?search_query=Maori+food+words+kai+toddler+song",
 act:"At your next meal shout KAI! before eating. Learn: Kia ora nga kai — Thank you for the food! Say it before every meal this week.",
 ff:"Kumara was brought to New Zealand by the very first Maori voyagers from Polynesia. It was so precious that special priests said prayers and ceremonies over the kumara gardens."},
{id:"nzl9",title:"A Maori Song",age:"2–5",dur:"15 min",
 content:"Learning a language through singing is the best way for little children! Maori songs called waiata are full of love for the land, the family and God. When you sing a Maori song you join a tradition hundreds of years old!",
 vsearch:"Maori waiata songs for toddlers children simple",res:"https://www.youtube.com/results?search_query=Maori+waiata+songs+toddlers+children+simple",
 act:"Listen to a simple Maori waiata on YouTube. Clap along! Try to learn just one line or the chorus. Can you sing it to your teddy bear?",
 ff:"Before Maori people had writing, all their history and knowledge was kept in songs, chants and stories. A person who forgot a song might lose a piece of their people's history forever!"},
{id:"nzl10",title:"Aroha: Love",age:"2–5",dur:"15 min",
 content:"Aroha means love in Maori — deep warm caring love. Aroha nui means big love! When we show aroha we are sharing God's love with someone. Even a two-year-old can give great big aroha!",
 vsearch:"aroha love Maori word for toddlers children",res:"https://www.youtube.com/results?search_query=aroha+love+Maori+word+toddlers+children",
 act:"Say AROHA NUI to every family member today — big love! Give a hug with each saying. Draw a big heart and write AROHA inside it in big letters.",
 ff:"Aroha is so important in Maori culture that you find it in the names of people, schools and organisations all over New Zealand."},
{id:"nzl11",title:"Turangawaewae: My Place",age:"2–5",dur:"15 min",
 content:"Turangawaewae means the place where I belong — my home, my safe place where I stand with confidence! Everyone needs a turangawaewae. Your home is your turangawaewae. And God is our greatest turangawaewae!",
 vsearch:"turangawaewae home belonging Maori children",res:"https://www.youtube.com/results?search_query=turangawaewae+home+belonging+Maori+children",
 act:"Stand in the middle of your home and stamp your feet! Say: THIS is my turangawaewae! This is my place where I belong! Draw your home with your whole family inside it nice and safe.",
 ff:"Tu means stand, ranga means raised up, waewae means feet — so turangawaewae is the place that lifts up your feet and makes you stand tall with confidence!"},
{id:"nzl12",title:"Haere Ra: Goodbye!",age:"2–5",dur:"15 min",
 content:"Haere ra means goodbye when you are leaving! E noho ra means goodbye when you are the one staying! Both words carry love and say: God go with you on your journey!",
 vsearch:"haere ra goodbye Maori for young children",res:"https://www.youtube.com/results?search_query=haere+ra+goodbye+Maori+for+young+children",
 act:"Practise: one person walks out calling HAERE RA! and the other calls back E NOHO RA! Do it with every family member. Use these words every time someone leaves the house this week.",
 ff:"The English word goodbye comes from God be with ye — a prayer tucked inside a farewell. And haere ra carries the same blessing — may you go safely with God!"},
]},
{id:"nature",name:"Nature Science",emoji:"🌿",color:P.forest,tagline:"Discovering God's beautiful world together.",
lessons:[
{id:"nl1",title:"Our Nature Walk",age:"2–5",dur:"20 min",
 content:"God made the whole world as a beautiful gift! Today we use all five senses to discover it. See something beautiful. Hear a sound. Smell something. Feel a texture. Psalm 34 says: Taste and see that the Lord is good!",
 vsearch:"nature walk toddlers preschoolers sensory",res:"https://www.youtube.com/results?search_query=nature+walk+toddlers+preschoolers+sensory",
 act:"Go outside with a small basket. Collect 5 different things from nature: a stone, a leaf, a feather, a seed, some bark. Come inside and feel each one. Which is softest? Which is roughest? Thank God for each treasure.",
 ff:"Psalm 19 says: The heavens declare the glory of God! The whole sky above us is singing a song of praise!"},
{id:"nl2",title:"Garden Bugs",age:"2–5",dur:"20 min",
 content:"God made tiny creatures everywhere in the garden! Earthworms make soil soft for plants. Ladybirds eat the bugs that hurt vegetables. Bees collect nectar and make honey. Every tiny creature has an important job in God's garden.",
 vsearch:"garden bugs insects toddlers gentle exploring",res:"https://www.youtube.com/results?search_query=garden+bugs+insects+toddlers+gentle",
 act:"Go on a gentle bug hunt — lift a rock or leaf and look underneath. Find 3 different creatures. Count their legs! Watch them for 1 minute. Put the rock back gently — it is their home. Draw what you found.",
 ff:"A ladybird eats up to 5,000 aphids in its lifetime! God designed each tiny creature to be exactly what its garden needs."},
{id:"nl3",title:"Seeds: Tiny Miracles",age:"2–5",dur:"20 min",
 content:"Inside every tiny seed is a whole plant waiting to wake up! It has everything it needs — the instructions for roots, stem, leaves and flowers. Jesus said the Kingdom of Heaven is like a mustard seed — the tiniest seed that grows into the biggest tree!",
 vsearch:"planting seeds toddlers preschoolers magic",res:"https://www.youtube.com/results?search_query=planting+seeds+toddlers+preschoolers",
 act:"Plant a bean seed in a clear plastic cup with damp tissue against the glass so you can watch the root grow! Water gently. How many days until you see the first root?",
 ff:"God designed seeds so they can stay asleep for years — waiting for exactly the right conditions to wake up and grow. Scientists have grown plants from seeds that were 2,000 years old!"},
{id:"nl4",title:"Rain and Rainbows",age:"2–5",dur:"15 min",
 content:"Rain is one of God's gifts that waters all the gardens, rivers and oceans! After the great flood God put a rainbow in the sky as His promise to Noah and to us — I will always love you and take care of you. Every rainbow is God's promise still shining!",
 vsearch:"rain and rainbow toddlers simple weather",res:"https://www.youtube.com/results?search_query=rain+and+rainbow+toddlers+simple",
 act:"After it rains, find the best puddle and jump in it with boots on! Then look for a rainbow in the sky. Make your own rainbow by holding a glass of water in bright sunlight over white paper.",
 ff:"God said: I have set my rainbow in the clouds as a sign of my covenant between me and the earth. A covenant is an unbreakable promise. Every rainbow is that same promise keeping!"},
{id:"nl5",title:"Sun Moon and Stars",age:"2–5",dur:"15 min",
 content:"God made the sun to light and warm us during the day. He made the moon to shine gently at night. He made millions and millions of stars — more than anyone could ever count! The Bible says God calls each star by its own name. If He knows every star's name, He certainly knows yours!",
 vsearch:"sun moon stars song for toddlers",res:"https://www.youtube.com/results?search_query=sun+moon+stars+song+for+toddlers",
 act:"At bedtime, look out the window for the moon and count as many stars as you can. Make a night sky picture: black paper, white paint, finger-dabs for stars.",
 ff:"Scientists estimate there are more stars in the observable universe than there are grains of sand on all the beaches on Earth. And God knows every single one by name!"},
{id:"nl6",title:"Animals God Made",age:"2–5",dur:"20 min",
 content:"God made every single animal — from the enormous blue whale to the tiny ant! He made them on the fifth and sixth days of creation and each time He said: It is good! He gave Adam the special job of naming them all.",
 vsearch:"animals God made toddlers creation",res:"https://www.youtube.com/results?search_query=animals+God+made+toddlers+creation",
 act:"Look at an animal picture book or watch animals outside. For each one say: Thank You God for making the [animal name]! Make the sound of 5 different animals. Which is your very favourite?",
 ff:"Noah had to fit two of every animal on the ark! Some scientists think the ark was big enough to hold about 7,000 kinds of animals. Can you imagine the noise?"},
{id:"nl7",title:"All Kinds of Weather",age:"2–5",dur:"15 min",
 content:"God made all the weather! Sunny days warm us. Windy days carry seeds to plant new trees. Rainy days water the garden. Jesus once calmed a terrible storm just by speaking — Peace! Be still! — and the wind and waves obeyed Him at once!",
 vsearch:"weather song toddlers sunny windy rainy",res:"https://www.youtube.com/results?search_query=weather+song+toddlers+sunny+windy+rainy",
 act:"Weather chart for the week: each morning draw a sun, cloud, raindrop or wind swirl. Count them up at the end of the week. What was your favourite weather day?",
 ff:"The disciples were terrified in the storm but Jesus was sleeping peacefully in the boat. He could sleep because He knew He was God. We can be peaceful in difficult things because He is with us!"},
{id:"nl8",title:"Trees are Giants",age:"2–5",dur:"20 min",
 content:"Trees are some of the biggest and oldest living things God made! They give us shade, fruit, clean air, homes for birds, and beautiful colours. In the Bible there are many important trees — from the Garden of Eden to the fig tree that Zacchaeus climbed!",
 vsearch:"trees for toddlers autumn leaves nature",res:"https://www.youtube.com/results?search_query=trees+for+toddlers+autumn+leaves+nature",
 act:"Find the biggest tree near your home and give it a hug! Is it bigger than your arms? Collect fallen leaves. Make leaf rubbings with crayons. Thank God for trees!",
 ff:"The oldest tree in New Zealand is Tane Mahuta — Lord of the Forest — a kauri tree that is at least 1,500 years old. It was ancient before the first Maori arrived 700 years ago!"},
{id:"nl9",title:"Wonderful Birds",age:"2–5",dur:"15 min",
 content:"God gave birds something no other animal has — feathers! And most birds also get wings to fly! Jesus said: Look at the birds of the air — your heavenly Father feeds them. Are you not much more valuable than they are?",
 vsearch:"birds for toddlers NZ wonder nature",res:"https://www.youtube.com/results?search_query=birds+for+toddlers+NZ+nature+wonder",
 act:"Sit quietly by a window or outside for 5 minutes and watch for birds. Count how many different ones you see. Put a little dish of water outside as a gift for the birds. Draw your favourite bird.",
 ff:"God knows when even one sparrow falls to the ground — Jesus told us this! And He says we are worth more than many sparrows."},
{id:"nl10",title:"Water is Life",age:"2–5",dur:"15 min",
 content:"Water is one of God's greatest gifts! We need it to drink, wash, swim, grow food. In Baptism, water washes us clean and welcomes us into God's family. Jesus said He is the Living Water — He gives us life that never ever runs out!",
 vsearch:"water play toddlers life gift nature",res:"https://www.youtube.com/results?search_query=water+play+toddlers+life+gift+nature",
 act:"Water play outside! Fill a bucket and give your plants a drink. Pour water through your fingers and watch it fall. Say: Thank You God for water!",
 ff:"More than half of your body is water! God made us mostly of the same water He fills the oceans and rivers with — we are part of His creation!"},
{id:"nl11",title:"Four Seasons",age:"2–5",dur:"15 min",
 content:"God made four seasons — Spring, Summer, Autumn, Winter — and they come around every year like a beautiful wheel. The Church year follows the seasons too — fasting and feasting just like nature!",
 vsearch:"four seasons song for toddlers simple",res:"https://www.youtube.com/results?search_query=four+seasons+song+toddlers+simple",
 act:"Draw four pictures — one for each season — and what you love doing in each one. What is your favourite season? Which season does God seem to enjoy decorating the most?",
 ff:"The Orthodox Church year begins in September just as nature changes from summer to autumn. The whole year is shaped around Jesus — His birth, life, death and Resurrection!"},
{id:"nl12",title:"Caring for God's Garden",age:"2–5",dur:"20 min",
 content:"The very first job God gave to people was looking after the garden! That job has been passed down to every person ever since. Even a two-year-old can help care for God's garden — watering a plant, picking up litter, feeding a bird.",
 vsearch:"caring for nature toddlers preschoolers stewardship",res:"https://www.youtube.com/results?search_query=caring+for+nature+toddlers+preschoolers",
 act:"Choose one thing to do today to care for God's creation: water a plant, pick up one piece of litter, put fresh water out for birds, or plant one seed. Pray: Dear God, thank you for this beautiful world. Help me look after it. Amen.",
 ff:"Genesis 2:15 says: The Lord God put the man in the Garden to work it and take care of it. This was the very first job God ever gave — and every person since Adam has inherited it!"},
]},
{id:"maths",name:"Mathematics",emoji:"🔢",color:P.navy,tagline:"Numbers shapes and patterns in everything!",
lessons:[
{id:"ml1",title:"Counting 1 to 5",age:"2–5",dur:"15 min",
 content:"Numbers help us count all of God's gifts! 1, 2, 3, 4, 5! The number 3 is extra special — Father, Son and Holy Spirit. When we make the sign of the cross we hold three fingers together for the Trinity!",
 vsearch:"counting 1 to 5 toddler song fingers",res:"https://www.youtube.com/results?search_query=counting+1+to+5+toddler+song+fingers",
 act:"Count 5 of your favourite toys one by one, touching each as you count. Then count 5 jumps, 5 claps and 5 kisses! Put 5 blocks in a row and count them forward, then backward from 5 to 1.",
 ff:"The very first counting tools humans ever made were their fingers and toes — just like you are using right now! Finger-counting goes back at least 40,000 years."},
{id:"ml2",title:"Shapes All Around Us",age:"2–5",dur:"15 min",
 content:"God loves shapes! Circles are round — like the sun, moon, a coin. Squares have four equal sides. Triangles have three sides — three for the Trinity! The cross is made of two rectangles joined together — the most important shape of all!",
 vsearch:"shapes for toddlers circle square triangle rectangle",res:"https://www.youtube.com/results?search_query=shapes+for+toddlers+circle+square+triangle",
 act:"Shape hunt around the house: find 2 circles, 2 squares and 2 rectangles! Draw each one. Can you make the shape of a cross with two rectangles? Put them together!",
 ff:"Orthodox churches are often built in the shape of a cross when viewed from above — so the whole building is a sign of Jesus and His love for us!"},
{id:"ml3",title:"Big Small More Less",age:"2–5",dur:"15 min",
 content:"Comparing is the beginning of maths! Which apple is bigger? Which pile has more? Which is taller? Which is shorter? God made everything in different sizes on purpose — from the enormous blue whale to the tiniest grain of sand!",
 vsearch:"big and small more and less toddlers comparing",res:"https://www.youtube.com/results?search_query=big+and+small+more+and+less+toddlers",
 act:"Find two of the same thing in different sizes — two cups, two shoes, two books. Which is bigger? Which is heavier? Sort a pile of objects from smallest to biggest in a line.",
 ff:"God made the enormous blue whale and the microscopic bacterium on the same planet — and both are perfectly designed for what they need to do!"},
{id:"ml4",title:"Sorting and Grouping",age:"2–5",dur:"15 min",
 content:"Sorting means putting things that belong together in groups. We can sort by colour — all the red ones here, all the blue ones there! God sorted creation too — day and night, sky and earth, land and sea, plants and animals!",
 vsearch:"sorting and grouping toddlers preschoolers colours",res:"https://www.youtube.com/results?search_query=sorting+and+grouping+toddlers+preschoolers",
 act:"Sort a box of crayons by colour. Then sort them from shortest to longest. Then sort your toy animals into groups you decide.",
 ff:"When God created the world He was sorting! He separated light from darkness, sky from earth, land from sea. God is the first great sorter!"},
{id:"ml5",title:"Patterns Everywhere",age:"2–5",dur:"15 min",
 content:"A pattern repeats again and again — red blue red blue, clap stomp clap stomp! God built patterns into everything He made. The sun rises and sets every day. Summer autumn winter spring every year. The Church year has a beautiful pattern of fasting and feasting!",
 vsearch:"patterns for toddlers AB repeating simple",res:"https://www.youtube.com/results?search_query=patterns+for+toddlers+AB+repeating+simple",
 act:"Make a pattern with two colours of blocks or two types of fruit. Repeat it 4 times! Then clap a pattern for someone to copy: clap stomp clap stomp. Make a zigzag pattern with crayons.",
 ff:"God made snowflakes in patterns — every snowflake has exactly 6 points, never 5 or 7. God put the same mathematical pattern into every single water crystal on Earth. Patterns are God's fingerprints!"},
{id:"ml6",title:"Counting to 10",age:"2–5",dur:"15 min",
 content:"1, 2, 3, 4, 5, 6, 7, 8, 9, 10! Let us count to 10 using all our fingers! Seven is the holiest number — God rested on the 7th day. Ten is the number of the commandments God gave to Moses.",
 vsearch:"counting to 10 song toddler fingers",res:"https://www.youtube.com/results?search_query=counting+to+10+song+toddler+fingers",
 act:"Use 10 small objects to count with. Count forward to 10. Count backward from 10 to 1. Group them as 5 and 5. Group them as 6 and 4. How many ways can you split 10?",
 ff:"The 10 Commandments were written by God's own finger on two stone tablets — 5 commandments on each tablet. Next time you hold up 10 fingers, you are holding the most important rules ever given!"},
{id:"ml7",title:"Adding: Putting Together",age:"2–5",dur:"15 min",
 content:"Adding means putting things together to make more! If you have 2 apples and someone gives you 1 more, now you have 3! Hold up 2 fingers on one hand and 1 on the other. Count them all — that is addition!",
 vsearch:"simple addition for toddlers putting together",res:"https://www.youtube.com/results?search_query=simple+addition+for+toddlers+putting+together",
 act:"Adding with snacks: put 2 blueberries on one side and 3 on the other. How many all together? Count and eat! Try 1+1, 2+1, 2+2, 3+1. Draw the number stories as circles on paper.",
 ff:"Ancient Egyptian children learned addition by counting their fingers, just like you do! 5,000 years ago, Egyptian children in school were adding numbers on clay tablets."},
{id:"ml8",title:"Measuring with Hands and Feet",age:"2–5",dur:"15 min",
 content:"Measuring is finding out exactly how big something is! You can measure with a ruler, but you can also measure with your hands! How many hand-widths long is your pillow? The Bible measured Noah's Ark in cubits — the length of a forearm!",
 vsearch:"measuring with hands feet toddlers non standard",res:"https://www.youtube.com/results?search_query=measuring+with+hands+feet+toddlers",
 act:"Measure 5 things in the house using your hand as the unit. How many hands wide is the table? The sofa? Measure the same things with a parent's bigger hand — different numbers!",
 ff:"The cubit was used to measure Noah's Ark — it equals the length of an arm from elbow to fingertip. God gave Noah exact measurements because the ark had to be exactly the right size!"},
{id:"ml9",title:"Morning Day and Night",age:"2–5",dur:"15 min",
 content:"Time goes around and around! Morning: the sun rises and we wake up and pray. Daytime: we play, eat and learn. Evening: the sun sets. Night: the moon shines and God watches over us. The Church marks each time with prayers — Orthros in the morning, Vespers in the evening.",
 vsearch:"morning day night time toddlers routine",res:"https://www.youtube.com/results?search_query=morning+day+night+time+toddlers+routine",
 act:"Draw three circles showing the sun at morning, at midday (high in the sky) and at evening (orange and low). What do you do at each time? Add prayer times to morning and night!",
 ff:"In the very first chapter of the Bible, God marks time by saying: And there was evening and there was morning — the first day. God invented the rhythm of day and night to give us rest and work in perfect balance!"},
{id:"ml10",title:"Counting Money: Coins",age:"2–5",dur:"15 min",
 content:"Coins are round discs with pictures on them that we use to buy things. In New Zealand we have 10c, 20c, 50c, $1 and $2 coins! Jesus told a story about a woman who lost one precious coin and searched the whole house until she found it — then she called all her friends to celebrate!",
 vsearch:"counting coins toddlers preschoolers simple",res:"https://www.youtube.com/results?search_query=counting+coins+toddlers+preschoolers+simple",
 act:"Get a collection of coins and sort them by size. Count how many of each. Set up a tiny pretend shop. Buy and sell things with your coins.",
 ff:"Jesus used coins to teach important lessons! He said: Give to Caesar what is Caesar's and to God what is God's. The coin had the emperor's picture — our hearts have God's image on them!"},
{id:"ml11",title:"Taking Away",age:"2–5",dur:"15 min",
 content:"Subtraction means taking away! If you have 5 grapes and you eat 2, how many are left? Show it with fingers! Hold up 5, fold down 2 — count what is left: 3!",
 vsearch:"simple subtraction for toddlers taking away",res:"https://www.youtube.com/results?search_query=simple+subtraction+for+toddlers+taking+away",
 act:"Play taking away with raisins or small objects. Start with 5. Take away 1 — how many left? 5 take away 2? 5 take away 5? Draw circles on paper — draw 5, cross out 2, count what is left.",
 ff:"The Parable of the Prodigal Son is a maths story! A father had 2 sons, then 1 left. But when the son returned it became a joyful addition story again! Even the parables of Jesus use maths!"},
{id:"ml12",title:"Maths in God's Creation",age:"2–5",dur:"15 min",
 content:"Maths is hidden everywhere in God's creation! Count the petals on a flower. Count the spots on a ladybird. Count the legs on a spider — always 8! Count the sections of an orange. God hid numbers and patterns into everything He made!",
 vsearch:"maths in nature toddlers preschoolers exploring",res:"https://www.youtube.com/results?search_query=maths+in+nature+toddlers+preschoolers+exploring",
 act:"Maths nature walk! Find something to count, something to measure, a pattern, and a shape — all in the garden or house. Draw each discovery.",
 ff:"Galileo the famous scientist wrote: The universe is written in the language of mathematics. And the Fathers would say: and God is the one who wrote it! Maths is God's fingerprint on creation."},
]},
{id:"english",name:"English and Stories",emoji:"📚",color:P.rose,tagline:"Letters words and wonderful stories!",
lessons:[
{id:"el1",title:"ABC — The Alphabet!",age:"2–5",dur:"15 min",
 content:"The alphabet has 26 letters — they are the building blocks of every word! A is for apple, angel and Amen! B is for bread, Bible and blessing! C is for cross, church and candle! Every letter helps us read God's Word!",
 vsearch:"ABC alphabet song toddlers preschoolers",res:"https://www.youtube.com/results?search_query=ABC+alphabet+song+toddlers+preschoolers",
 act:"Sing the alphabet song with actions! For each letter up to F, find one object in the house that starts with that letter. Trace a big A, B, C with a fat crayon — first on paper, then in the air!",
 ff:"Jesus says He is the Alpha and the Omega — the A and the Z of the Greek alphabet! He is the beginning and end of the whole alphabet of everything that exists!"},
{id:"el2",title:"My Very Own Name",age:"2–5",dur:"15 min",
 content:"Your name is the very first special word that belongs just to you! God knew your name before you were born. The Bible says: I have called you by name — you are mine! Learning to write your name is learning to write the most important word you will ever write.",
 vsearch:"learning your name toddlers preschoolers tracing",res:"https://www.youtube.com/results?search_query=learning+your+name+toddlers+preschoolers",
 act:"Write your name in the biggest most decorated letters you can! Say each letter out loud as you write it. Trace it with your finger. Decorate each letter with patterns or colours. Display it on your bedroom door!",
 ff:"In the Bible God often gave people new names when something important happened — Abram became Abraham, Jacob became Israel, Simon became Peter. A new name meant a new beginning with God!"},
{id:"el3",title:"Vowels: A E I O U",age:"2–5",dur:"15 min",
 content:"Every word in English has at least one vowel! The vowels are A, E, I, O, U — they are the breath inside every word. A says ah, E says eh, I says ee, O says oh, U says oo. Practise each one with a big open mouth!",
 vsearch:"vowels A E I O U song toddlers preschoolers",res:"https://www.youtube.com/results?search_query=vowels+A+E+I+O+U+song+toddlers",
 act:"Say each vowel in a funny voice: A in a mouse voice, E in a giant voice, I in a whisper, O in an opera voice, U in a robot voice! Find one word starting with each vowel: Apple, Egg, Ice cream, Orange, Umbrella!",
 ff:"In ancient Hebrew (the language of the Old Testament) only consonants were written — no vowels! Readers had to know which vowels to put in. Reading was like a puzzle every single time!"},
{id:"el4",title:"Rhyming is Fun!",age:"2–5",dur:"15 min",
 content:"Rhyming words sound the same at the end — cat and hat, sun and fun, love and dove! The Psalms of King David in the Bible rhyme beautifully in Hebrew. Rhyming words feel like music! They help us remember things — that is why we sing prayers in church!",
 vsearch:"rhyming words song toddlers preschoolers cat hat",res:"https://www.youtube.com/results?search_query=rhyming+words+song+toddlers+preschoolers",
 act:"Rhyming game: I say cat — you say...? I say sun — you say...? I say God — you say...? Try to make a tiny 2-line rhyme about something you love: I love my dog, He sits on a log!",
 ff:"King David wrote the Psalms as poems with rhythm and rhyme — they were meant to be sung! The beautiful singing in Orthodox churches follows a 1,500-year tradition."},
{id:"el5",title:"Stories: Beginning Middle End",age:"2–5",dur:"20 min",
 content:"Every story has three parts! A beginning where we meet the characters. A middle where something exciting or tricky happens. An end where everything is resolved! Even the Bible has these three parts!",
 vsearch:"story beginning middle end toddlers preschoolers",res:"https://www.youtube.com/results?search_query=story+beginning+middle+end+toddlers+preschoolers",
 act:"Tell the story of your day: BEGINNING — this morning I woke up and... MIDDLE — then something interesting happened... END — and finally... Then make up a silly 3-part story about a talking carrot!",
 ff:"The whole Bible is one magnificent story — beginning (God makes everything good), middle (everything goes wrong and God works to save us), end (Jesus makes everything new and perfect again)!"},
{id:"el6",title:"Reading Together",age:"2–5",dur:"20 min",
 content:"The best thing a family can do together is read aloud! Stories grow your brain, your heart and your imagination all at once. The very first Christians read the Scriptures aloud together. Reading together is an ancient holy tradition!",
 vsearch:"reading aloud toddlers preschoolers together benefits",res:"https://www.storylineonline.net",
 act:"Choose your absolute favourite picture book. Read it aloud with lots of expression — change your voice for each character! When you finish, ask: What was your favourite part? What do you think happened next?",
 ff:"Children who are read to for just 20 minutes a day hear about 1,800,000 more words per year than children who are not read to. Those extra words change the brain and the heart forever!"},
{id:"el7",title:"Pencil and Drawing Practice",age:"2–5",dur:"15 min",
 content:"Before we write letters we practise holding the pencil and making shapes! The tripod grip uses three fingers — thumb, first finger, middle finger. Squeezing playdough and doing puzzles make our fingers strong for writing!",
 vsearch:"pencil grip practice toddlers preschoolers",res:"https://www.youtube.com/results?search_query=pencil+grip+practice+toddlers+preschoolers",
 act:"Warm up with playdough — squeeze, roll a ball, make a snake! Then draw: lines across the page, circles, spirals going inward, zigzags. Try to trace the letters O, C, I, L. No pressure — just play!",
 ff:"Medieval monks called scribes copied out the Bible entirely by hand — page after page, year after year. Their handwriting was so beautiful it is still admired 1,000 years later!"},
{id:"el8",title:"Important First Words",age:"2–5",dur:"15 min",
 content:"Some words carry the whole world in them! Mum. Dad. Love. God. Home. Thank you. Sorry. These short simple words are the most important ones we ever learn. In the Bible, the very first words God speaks are Let there be light — five simple words that began all of creation!",
 vsearch:"first words reading simple preschoolers toddlers",res:"https://www.youtube.com/results?search_query=first+words+reading+simple+preschoolers",
 act:"Write (or trace) five important words: MUM, DAD, GOD, LOVE, HOME. Draw a picture next to each word. Can you read each word when the picture is covered?",
 ff:"The most important prayer in the Orthodox Church is just three words in Greek — Kyrie Eleison — Lord have mercy. Three simple words prayed by millions every day. Simple words can carry the weight of heaven!"},
{id:"el9",title:"Listening is a Superpower",age:"2–5",dur:"15 min",
 content:"Before we can read, we must learn to listen! Good listening means: eyes on the speaker, body still and calm, ears wide open. In church we listen to the Gospel, to the prayers, to the choir. Listening is how we first receive God's word!",
 vsearch:"listening skills for toddlers preschoolers superpower",res:"https://www.youtube.com/results?search_query=listening+skills+for+toddlers+preschoolers",
 act:"Listening adventure: close your eyes for 1 full minute and count every different sound you can hear. How many did you find? Then listen to a short story and answer: Who was in it? What happened?",
 ff:"The word obedience comes from a Latin word meaning to listen deeply. True obedience starts with truly listening. The Desert Fathers said: The beginning of all wisdom is to learn to listen well."},
{id:"el10",title:"Nursery Rhymes and Songs",age:"2–5",dur:"15 min",
 content:"Nursery rhymes are a little child's first poetry — they have rhythm, rhyme and often a tiny story! The Church uses rhythm and music in prayers for the very same reason — music makes things stick in our hearts!",
 vsearch:"nursery rhymes songs toddlers preschoolers actions",res:"https://www.youtube.com/results?search_query=nursery+rhymes+songs+toddlers+preschoolers+actions",
 act:"Say three favourite nursery rhymes with actions as big and dramatic as possible! Then make up a new verse using your own family's names. Perform it for everyone!",
 ff:"Nursery rhymes were used in medieval schools to help children memorise important facts! Even the Creed was once taught in rhyming verse to help children remember the faith."},
{id:"el11",title:"Letters in the World",age:"2–5",dur:"15 min",
 content:"Letters are hiding everywhere! On cereal boxes, street signs, church notice boards, shop windows, books and bags. When you start to notice letters in the real world you are becoming a reader! Every letter you spot is a little treasure.",
 vsearch:"environmental print letters real world preschoolers",res:"https://www.youtube.com/results?search_query=environmental+print+letters+real+world+preschoolers",
 act:"Letter hunt! Walk around your home or outside and find as many letters as you can. Look for the letters in your name. Which letter appears the most?",
 ff:"In the catacombs of Rome where the first Christians hid to pray, they carved their prayers and names into the stone walls. Some of those carved letters can still be read today nearly 2,000 years later!"},
{id:"el12",title:"Books are Friends Forever",age:"2–5",dur:"20 min",
 content:"A book is a miracle — someone put their thoughts and stories inside it, and when you open it those thoughts travel straight into your mind! The Bible is the greatest book — billions of people have read it over thousands of years!",
 vsearch:"love of books reading toddlers preschoolers library",res:"https://www.youtube.com/results?search_query=love+of+books+reading+toddlers+preschoolers",
 act:"Visit your local library or look at your home bookshelf. Choose one book just by its cover without knowing anything about it. Read it together. Then draw your favourite moment.",
 ff:"The Bible has been translated into over 3,600 languages — more than any other book in history! God wants His Word to reach every language, every people, every child — including you right here right now!"},
]},
{id:"sports",name:"Sports and Health",emoji:"⚽",color:P.ochre,tagline:"Moving playing and growing strong for God!",
lessons:[
{id:"sl1",title:"My Amazing Body!",age:"2–5",dur:"20 min",
 content:"God made your body amazing — it can run and jump and spin and roll and climb! St Paul says our bodies are temples of the Holy Spirit — which means God lives inside you! A temple is the most beautiful and precious place in the world. Your body is God's most precious temple!",
 vsearch:"movement dance song toddlers preschoolers",res:"https://www.youtube.com/results?search_query=movement+dance+song+toddlers+preschoolers",
 act:"Dance party time! Put on music and move for 5 whole minutes: jump like a frog, spin like a top, roll on the grass, run as fast as you can! After — sit very still. Can you feel your heart beating fast?",
 ff:"The ancient Greek Olympics began 2,800 years ago with athletes honouring God through physical excellence. St Paul compared the Christian life to an athlete running a race!"},
{id:"sl2",title:"Rainbow Food",age:"2–5",dur:"15 min",
 content:"God made food in all the colours of the rainbow — and eating many colours is how we get all the goodness our bodies need! Red strawberries, orange carrots, yellow bananas, green peas, purple grapes! When your plate looks like a rainbow, God is pleased!",
 vsearch:"rainbow healthy food toddlers preschoolers colours",res:"https://www.youtube.com/results?search_query=rainbow+healthy+food+toddlers+preschoolers",
 act:"Rainbow plate today! Try to have at least 3 different colours of food at your next meal. Draw your plate with crayons using the real colours of what you ate. Which colour was missing from your rainbow?",
 ff:"God's very first gift of food to Adam and Eve was fruit and vegetables from the garden. All those colours existed since the very beginning — God loves colour on our plates!"},
{id:"sl3",title:"Drink Your Water!",age:"2–5",dur:"15 min",
 content:"More than half of your body is water! We need to drink water every day to feel happy, think clearly and play energetically. Jesus said: Whoever drinks the water I give them will never be thirsty again — He gives us Living Water that fills our hearts forever!",
 vsearch:"drinking water healthy toddlers preschoolers fun",res:"https://www.youtube.com/results?search_query=drinking+water+healthy+toddlers+preschoolers+fun",
 act:"Decorate a water bottle with stickers — this is YOUR special water bottle! Drink one full bottle today. Every time you drink a big gulp, say: Thank you God for water!",
 ff:"The Orthodox Church has a special ceremony at Theophany where the priest blesses water and people take some home. Even water is holy when blessed and given to God!"},
{id:"sl4",title:"Sleep is God's Rest",age:"2–5",dur:"15 min",
 content:"God rested on the seventh day — and He put rest into His plan for us too! When we sleep, our bodies grow (growing happens at night!), our brains sort out everything we learned, and God watches over us.",
 vsearch:"sleep rest importance toddlers preschoolers",res:"https://www.youtube.com/results?search_query=sleep+rest+importance+toddlers+preschoolers",
 act:"Plan your perfect bedtime routine: bath, pyjamas, prayers, a story, goodnight kisses, lights off! Try it tonight. Say: O Lord, keep me safe as I sleep and give me a peaceful night. Amen.",
 ff:"Little children need 10 to 13 hours of sleep every night! While you sleep your brain sorts through everything you learned all day. Sleep is actually a form of learning!"},
{id:"sl5",title:"Running Jumping Throwing",age:"2–5",dur:"20 min",
 content:"Running, jumping and throwing are the three most important movement skills for little children to learn! God made your body to do all these things — and the more you practise the better your brain and body both get!",
 vsearch:"run jump throw movement skills toddlers preschoolers",res:"https://www.youtube.com/results?search_query=run+jump+throw+movement+skills+toddlers",
 act:"Backyard athletics! Sprint to the fence and back 3 times. Jump as far as you can from standing — mark where you land with a stick. Throw a ball as far as you can. Can you beat your best?",
 ff:"St Paul wrote: Run in such a way as to get the prize! He meant the Christian life needs the same effort, training and whole-hearted commitment as sport!"},
{id:"sl6",title:"Washing Hands",age:"2–5",dur:"15 min",
 content:"Washing our hands before eating and after the toilet keeps us healthy. In the Old Testament the priests washed their hands before serving at the altar. When we wash our hands before meals we are doing something holy!",
 vsearch:"handwashing song toddlers preschoolers",res:"https://www.youtube.com/results?search_query=handwashing+song+toddlers+preschoolers",
 act:"Sing the whole alphabet or Kyrie eleison three times while washing hands — this is exactly the right amount of time! Count the steps: wet, soap, scrub all over, rinse, dry. Practise until it is automatic.",
 ff:"When Orthodox Christians prepare to receive Holy Communion they come with clean hands and clean hearts. The outer cleanliness is a sign of the inner preparation!"},
{id:"sl7",title:"Outside Every Day!",age:"2–5",dur:"20 min",
 content:"God made the outdoors especially for children! Fresh air, sunlight, running on grass, getting muddy, climbing trees — these things make children healthier, happier, more creative and better sleepers!",
 vsearch:"outdoor play toddlers preschoolers benefits nature",res:"https://www.youtube.com/results?search_query=outdoor+play+toddlers+preschoolers+benefits",
 act:"Outside every day this week no matter the weather! Rainy day: boots, coat, puddle jumping! Sunny day: run barefoot on the grass, roll down a hill! Windy day: run into the wind with arms out like wings!",
 ff:"Research shows children who spend time in natural outdoor environments have better focus, more creativity and less anxiety. God put health-giving properties into sunlight, fresh air and soil!"},
{id:"sl8",title:"Fruit and Vegetables",age:"2–5",dur:"15 min",
 content:"Fruit and vegetables are God's most colourful and nutritious food gifts! Each colour has special powers: red protects your heart, orange helps your eyes, green makes your muscles strong, purple helps your brain!",
 vsearch:"fruit vegetables rainbow toddlers preschoolers",res:"https://www.youtube.com/results?search_query=fruit+vegetables+rainbow+toddlers+preschoolers",
 act:"Fruit and vegetable rainbow challenge: try to eat one item from each colour group this week. Make a chart with coloured squares and tick each colour off as you eat it. Can you complete the whole rainbow?",
 ff:"In the Garden of Eden God gave Adam and Eve every fruit-bearing tree for food — the very first people were fruit eaters! Eating mostly plants is one of the healthiest ways to eat."},
{id:"sl9",title:"Taking Turns",age:"2–5",dur:"20 min",
 content:"Taking turns and sharing are two of the most important skills we learn when we are little! In Maori culture this is called manaakitanga — always looking out for the other person. In Orthodox Christianity we call it agape love. Even little games practise big love!",
 vsearch:"taking turns sharing toddlers preschoolers games",res:"https://www.youtube.com/results?search_query=taking+turns+sharing+toddlers+preschoolers+games",
 act:"Play a taking-turns game: roll a ball back and forth, build a tower one block each, card matching game. Each time it is the other person's turn, say cheerfully: Your turn! and wait with a smile.",
 ff:"St Paul wrote: In humility consider others better than yourselves. Every time you say Your turn! you are practising this beautiful teaching!"},
{id:"sl10",title:"My Feelings",age:"2–5",dur:"15 min",
 content:"God made us with feelings — happy, sad, scared, excited, angry, peaceful — and all our feelings are important and real! The Psalms of King David express every single human feeling. God gave us the Psalms to show us that all our feelings are welcome in prayer!",
 vsearch:"feelings emotions toddlers preschoolers expression",res:"https://www.youtube.com/results?search_query=feelings+emotions+toddlers+preschoolers+expression",
 act:"Draw 5 feeling faces: happy, sad, scared, angry, surprised. Point to how you feel right now. Talk about something that made you feel each feeling this week. Say a little prayer for the difficult feelings.",
 ff:"King David wrote Psalms about every feeling he ever had — joy, fear, anger, grief, wonder, thankfulness. He held nothing back from God. The Psalms show us that God is big enough to hold all our feelings safely."},
{id:"sl11",title:"Balance and Coordination",age:"2–5",dur:"20 min",
 content:"Balance and coordination are skills your body is busy learning right now — every time you walk, run or climb you are practising! God designed the human inner ear with tiny crystals that detect every movement and tilt — your own built-in balance sensor!",
 vsearch:"balance coordination toddlers preschoolers fun games",res:"https://www.youtube.com/results?search_query=balance+coordination+toddlers+preschoolers+fun",
 act:"Balance challenges: stand on one foot and count to 5. Walk along a line on the floor. Hop on one foot 3 times. Roll from one side of the room to the other. Walk with a beanbag balanced on your head!",
 ff:"The human inner ear has tiny calcium crystals that move when you tilt — sending signals to your brain about balance. God designed this incredible inner gyroscope into every person so we can stand, walk and dance!"},
{id:"sl12",title:"My Body is God's Temple",age:"2–5",dur:"15 min",
 content:"St Paul tells us our bodies are temples of the Holy Spirit — God lives inside us! A temple is the most beautiful most precious building — carefully looked after, always clean, full of light and prayer. Our bodies are like that!",
 vsearch:"body temple God toddlers children simple",res:"https://www.youtube.com/results?search_query=body+temple+God+children+simple",
 act:"Lie on big paper while someone traces around your whole body. Decorate your body outline beautifully — this is God's temple! Write inside it: God lives here! Put it on your bedroom wall.",
 ff:"1 Corinthians 6:19 says: Do you not know that your bodies are temples of the Holy Spirit who is in you? God has chosen to live inside your body. What an astonishing and wonderful thing!"},
]},
{id:"cooking",name:"Cooking",emoji:"🍳",color:P.gold,tagline:"Simple food made with love and gratitude.",
lessons:[
{id:"ckl1",title:"Kitchen Helpers!",age:"2–5",dur:"20 min",
 content:"Even the very youngest children can help in the kitchen! Wash vegetables, stir the batter, tear salad leaves, peel bananas, sprinkle cheese, set the table! In Orthodox monasteries the whole community works together in the kitchen. Cooking together is love made visible!",
 vsearch:"kitchen helpers toddlers preschoolers cooking together",res:"https://www.youtube.com/results?search_query=kitchen+helpers+toddlers+preschoolers",
 act:"Today be a kitchen helper! Wash all the vegetables for dinner under running water. Dry them with a cloth. Set the table. You helped make dinner — God bless your work!",
 ff:"In every Orthodox monastery on earth, cooking is considered just as holy as praying the Liturgy. Every job done with love is worship."},
{id:"ckl2",title:"Making Toast",age:"2–5",dur:"20 min",
 content:"Toast is one of the first things a little child can help make! Jesus blessed and broke bread at the Last Supper — the most holy meal in all of history! Every time we eat bread together we can remember that holy meal.",
 vsearch:"making toast spreading toddlers simple cooking",res:"https://www.youtube.com/results?search_query=making+toast+spreading+toddlers+simple",
 act:"Make toast with a parent supervising the toaster. Spread butter with a round-ended knife. Try different toppings: honey, jam, cheese. Say grace before eating: Dear God, thank you for this bread. Amen.",
 ff:"The very first bread was probably an accident — someone's grain porridge spilled on a hot stone about 30,000 years ago. The smell of baking bread is the oldest cooked smell in all of human history!"},
{id:"ckl3",title:"Simple Salad",age:"2–5",dur:"20 min",
 content:"A salad uses raw vegetables straight from the garden — God's food at its most fresh and alive! The monks who live on Mount Athos in Greece eat simple salads with olive oil every day and many of them live to be very old.",
 vsearch:"simple salad making toddlers preschoolers together",res:"https://www.youtube.com/results?search_query=simple+salad+making+toddlers+preschoolers",
 act:"Make a simple salad together! Wash and tear lettuce into a bowl. Slice cherry tomatoes in half (with help). Grate some carrot. Drizzle olive oil and squeeze lemon. Toss together with clean hands — so fun!",
 ff:"Olive oil is one of the most sacred foods in the entire Bible — used to anoint kings and priests, to light the Temple menorah, and to heal the sick. The word Christ means Anointed One — anointed with precious oil!"},
{id:"ckl4",title:"Pancakes!",age:"2–5",dur:"30 min",
 content:"Making pancakes is like doing a science experiment that you can eat! The baking powder makes tiny bubbles that puff the pancakes up. In many Orthodox countries bliny (thin pancakes) are eaten at Maslenitsa — the last week before Great Lent!",
 vsearch:"pancakes toddlers making together simple recipe",res:"https://www.youtube.com/results?search_query=pancakes+toddlers+making+together+simple",
 act:"Make pancakes with a parent handling the hot stove. You can: pour the milk, crack the egg into a bowl, stir the batter, choose the toppings! When they are ready, bring them to the table yourself. You are the chef today!",
 ff:"In Russia and Eastern Europe, beautiful thin pancakes called bliny are made for Maslenitsa — the festive week before Great Lent. Making bliny is a family celebration shared with the whole neighbourhood."},
{id:"ckl5",title:"Baking Bread Together",age:"2–5",dur:"30 min",
 content:"Bread is called the staff of life because it has fed people all over the world for thousands of years! In the Orthodox Church bread is blessed and shared at every feast. Jesus called Himself the Bread of Life.",
 vsearch:"simple bread baking toddlers preschoolers together",res:"https://www.youtube.com/results?search_query=simple+bread+baking+toddlers+preschoolers",
 act:"Make simple soda bread — no yeast needed! Mix flour, baking soda, salt and buttermilk. Knead with your hands. Shape into a round. Score a cross on top with a knife. Bake. Eat warm with butter and give thanks!",
 ff:"The Lord's Prayer asks God for our daily bread — right in the middle of the most important prayer Jesus taught! Bread is so important that Jesus used it as the symbol for everything we need from God each day."},
{id:"ckl6",title:"Fruit Smoothie",age:"2–5",dur:"15 min",
 content:"A smoothie is a delicious way to eat lots of fruit at once! Fruit is one of God's most colourful sweet gifts — He hid vitamins and sweetness inside every fruit like a little treasure for our bodies!",
 vsearch:"fruit smoothie toddlers preschoolers simple recipe",res:"https://www.youtube.com/results?search_query=fruit+smoothie+toddlers+preschoolers+simple",
 act:"Make a fruit smoothie: banana + berries + milk + a small squeeze of honey in a blender (with parent help). Pour into your best cups. Name your smoothie creation!",
 ff:"The Bible says the Promised Land flowed with milk and honey — a land so abundant that God described it in terms of its two most delicious natural products!"},
{id:"ckl7",title:"Fruit Kebabs",age:"2–5",dur:"15 min",
 content:"Food can be beautiful as well as delicious! Threading fruit onto skewers in a rainbow pattern is art that you can eat! Orthodox monasteries always present meals beautifully — because every meal is a gift from God.",
 vsearch:"fruit kebabs toddlers preschoolers rainbow",res:"https://www.youtube.com/results?search_query=fruit+kebabs+toddlers+preschoolers+rainbow",
 act:"Thread fruit pieces onto a blunt wooden skewer in a colour pattern: strawberry, grape, banana, melon, repeat! Arrange them beautifully on a plate and present them to your family as a gift from you!",
 ff:"At the Jewish Passover, every item of food on the seder plate has a specific meaning connected to the story of the Exodus. Food arranged with intention and prayer is itself a form of worship!"},
{id:"ckl8",title:"Baking Cookies",age:"2–5",dur:"30 min",
 content:"Baking cookies together is one of the most wonderful things families can do! The mixing, rolling, cutting shapes, waiting while they bake, the amazing smell, and then the eating — every single step is full of joy!",
 vsearch:"baking cookies toddlers preschoolers together simple",res:"https://www.youtube.com/results?search_query=baking+cookies+toddlers+preschoolers+together",
 act:"Make shortbread or butter cookies: mix softened butter, flour, sugar and vanilla. Roll out and cut into cross shapes, circles or stars. Bake until golden. Decorate and pack some into a bag to give away to a neighbour!",
 ff:"ANZAC biscuits were sent by New Zealand and Australian families to their soldiers in World War I — baked at home and shipped across the ocean. Each biscuit carried love from home!"},
{id:"ckl9",title:"Saying Grace",age:"2–5",dur:"10 min",
 content:"Grace is a prayer of thanksgiving before eating — thanking God for the food on our table! Saying grace reminds us that food is a gift, not something we made ourselves. The Orthodox meal blessing: O Christ our God, bless the food and drink of Thy servants. Amen!",
 vsearch:"saying grace meal prayer toddlers preschoolers",res:"https://www.youtube.com/results?search_query=saying+grace+meal+prayer+toddlers+preschoolers",
 act:"Make a beautiful Grace Card for your family! Write or draw your favourite meal blessing on a card. Decorate it. Cover it with sticky-back plastic. Place it in the centre of your dining table. Use it at every single meal!",
 ff:"Research shows that families who eat together and pray together before meals have children who are healthier, more grateful and better at communicating. The simple act of pausing to say thank you to God changes everything!"},
]},
{id:"gardening",name:"Gardening",emoji:"🌱",color:P.forest,tagline:"Planting watching and caring for God's garden.",
lessons:[
{id:"grl1",title:"Digging in the Dirt!",age:"2–5",dur:"20 min",
 content:"Digging in the dirt is one of the greatest joys of childhood — and it is also good for you! Scientists have discovered that bacteria in healthy garden soil make children happier, healthier and more relaxed. God put joy and health into the earth itself!",
 vsearch:"digging dirt garden toddlers preschoolers sensory",res:"https://www.youtube.com/results?search_query=digging+dirt+garden+toddlers+preschoolers",
 act:"Dig a small patch of garden with a trowel. Look for worms! Count them carefully and put them back gently. Feel the soil: dry or damp? Smooth or lumpy?",
 ff:"God formed the very first human being from the dust of the ground — Genesis 2:7. The Hebrew word for man is adam and for ground is adamah. We are literally earthlings — earth people!"},
{id:"grl2",title:"Planting a Seed",age:"2–5",dur:"20 min",
 content:"Planting a seed is one of the most hopeful and trusting things we ever do! You bury a tiny thing in the dark ground and trust that God will make it grow into something beautiful and alive. Jesus used seeds more than almost anything else to explain the Kingdom of Heaven!",
 vsearch:"planting seeds toddlers preschoolers hope trust",res:"https://www.youtube.com/results?search_query=planting+seeds+toddlers+preschoolers+hope",
 act:"Plant a sunflower or bean seed in a pot of soil. Water it gently. Put it where it will see sunlight. Every day, draw what you see. How many days does it take to appear?",
 ff:"Jesus said the Kingdom of Heaven is like a mustard seed — the smallest of all seeds — that grows into the biggest of all garden plants! What starts tiny can become something immense. That is how faith works too."},
{id:"grl3",title:"Watering Plants",age:"2–5",dur:"15 min",
 content:"Plants need water to live — just like us! Without water, leaves go limp and sad. With the right amount, they stand up bright and happy. Psalm 1 says the righteous person is like a tree planted by streams of water — always nourished!",
 vsearch:"watering plants toddlers preschoolers gentle",res:"https://www.youtube.com/results?search_query=watering+plants+toddlers+preschoolers+gentle",
 act:"Give every plant in your house and garden a gentle drink today! Check the soil first by poking your finger about 1 cm in — if it feels dry, the plant is thirsty! Use a small watering can you can manage yourself.",
 ff:"Psalm 1 describes the person who loves God as like a tree planted by streams of water that yields its fruit in season and whose leaf does not wither. God promises to be the water source that keeps us growing!"},
{id:"grl4",title:"Watching Things Grow",age:"2–5",dur:"15 min",
 content:"Growing things teach us patience! A seed becomes a seedling. A seedling becomes a plant. A plant becomes a flower. A flower becomes a fruit. Each tiny stage is happening even when we cannot see it — God is always at work even when we cannot see what He is doing!",
 vsearch:"watching plants grow toddlers preschoolers diary",res:"https://www.youtube.com/results?search_query=watching+plants+grow+toddlers+preschoolers",
 act:"Plant growth diary: every day this week, draw or photograph your seedling. Measure it if it is big enough with a ruler. Write or say what you notice: new tiny leaf! Stretched taller! First bud!",
 ff:"God designed plants to grow at exactly the right pace for their environment. Some alpine plants grow only 1 mm per year. Others grow 1 metre per week in tropics. All are perfectly following His design!"},
{id:"grl5",title:"Worms are Heroes!",age:"2–5",dur:"20 min",
 content:"Earthworms are some of God's most important and least appreciated little workers! Every day they eat dead leaves and soil and turn them into rich nutrients that plants love. They also make tunnels that let air and water down to plant roots.",
 vsearch:"earthworms for toddlers preschoolers nature garden",res:"https://www.youtube.com/results?search_query=earthworms+toddlers+preschoolers+nature+garden",
 act:"Carefully dig up a small patch of soil and find worms! Count them. Hold one gently in your palm and watch how it moves. Earthworms have no eyes but can feel light through their skin! Replace them carefully.",
 ff:"Charles Darwin spent the last 40 years of his life studying earthworms and concluded they might be the most important animals on Earth for maintaining soil health. God hides importance in the most unassuming places!"},
{id:"grl6",title:"Growing Cress: Fast!",age:"2–5",dur:"15 min",
 content:"Cress is the most magical garden for little children because it grows almost fast enough to watch! Plant the tiny seeds on wet cotton wool and within just 2 or 3 days you will see tiny green shoots appear. Within a week you can cut them and eat them!",
 vsearch:"growing cress toddlers preschoolers fast magical",res:"https://www.youtube.com/results?search_query=growing+cress+toddlers+preschoolers+fast",
 act:"Put wet cotton wool in an egg cup and sprinkle cress seeds thickly on top. Place in a bright windowsill and water gently each day. When is the first green shoot? When can you cut it? Eat on buttered bread!",
 ff:"The very first vegetables humans ever cultivated — about 10,000 years ago — were small leafy plants much like cress. That moment when our ancestors began growing food instead of just gathering it changed human history forever!"},
{id:"grl7",title:"Composting: Nothing Wasted",age:"2–5",dur:"20 min",
 content:"Composting is nature's recycling — turning scraps into treasure! When we put vegetable peelings and fruit skins in the compost, millions of tiny creatures break them down into rich dark soil. Nothing in God's garden is wasted — even dead things become the foundation for new life!",
 vsearch:"composting toddlers preschoolers simple nature",res:"https://www.youtube.com/results?search_query=composting+toddlers+preschoolers+simple+nature",
 act:"Start a kitchen scrap bucket this week! Put in all vegetable and fruit scraps — no meat or dairy. At the end of the week take it outside and bury it in the garden. You are making soil — God's garden gold!",
 ff:"St Paul writes: What you sow does not come to life unless it dies (1 Corinthians 15:36). He uses the seed and composting as an image of the Resurrection — death and burial is not the end but the beginning of magnificent new life!"},
{id:"grl8",title:"Flowers for God",age:"2–5",dur:"20 min",
 content:"God decorated His world with flowers of every colour, shape and fragrance — just because He loves beauty! Jesus said: Consider the lilies of the field — not even King Solomon in all his magnificent glory was dressed as beautifully as one simple lily.",
 vsearch:"flowers for toddlers preschoolers planting caring",res:"https://www.youtube.com/results?search_query=flowers+for+toddlers+preschoolers+planting",
 act:"Plant a flower seed or seedling in a pot and choose the brightest most beautiful colour you can find! Draw a flower showing all its parts: roots, stem, leaf, flower. Which part is underground?",
 ff:"On feast days in the Orthodox Church, the whole building is decorated with flowers and branches — at Theophany, on Palm Sunday, at Pentecost and at other feasts. God's creation enters the church to worship alongside us!"},
{id:"grl9",title:"Vegetables I Can Eat",age:"2–5",dur:"20 min",
 content:"We can eat vegetables from so many different parts of the plant — how clever of God! Carrots: we eat the root. Lettuce: we eat the leaves. Tomatoes: we eat the fruit. Peas: seeds inside the pod. Broccoli: we eat the flowers! Every part of the plant has something delicious!",
 vsearch:"vegetables different parts toddlers preschoolers eating",res:"https://www.youtube.com/results?search_query=vegetables+different+parts+toddlers+preschoolers",
 act:"Vegetable safari in the kitchen! Find a root vegetable, a leaf vegetable, a fruit vegetable and a flower vegetable. Wash each one and taste a small piece raw. Thank God for each one!",
 ff:"The kumara was so precious to the first Maori voyagers that they brought it carefully across the vast Pacific Ocean in their waka from their homeland. Food from the garden has always been worthy of special care and gratitude!"},
]},
{id:"farming",name:"Farming",emoji:"🚜",color:P.terra,tagline:"Animals land and where our food comes from.",
lessons:[
{id:"fml1",title:"Farm Animals!",age:"2–5",dur:"15 min",
 content:"A farm is full of God's creatures all living and working together! Cows say moo and give us milk. Sheep say baa and give us wool. Chickens cluck and give us eggs. Pigs grunt and oink. Every single animal has a special sound and a special job that God designed for it!",
 vsearch:"farm animals sounds song toddlers preschoolers",res:"https://www.youtube.com/results?search_query=farm+animals+sounds+song+toddlers+preschoolers",
 act:"Farm animal orchestra! Go through each farm animal and make its sound as loudly and dramatically as you can. Then play a guessing game: close eyes while someone makes a sound — who is it? Draw a colourful farm with all the animals.",
 ff:"When God told Noah to bring animals on the ark He said bring two of every living creature — so that they would survive and continue to fill the earth. God loves every creature and made sure they were protected!"},
{id:"fml2",title:"Where Does Milk Come From?",age:"2–5",dur:"15 min",
 content:"The milk in your cup started its journey with a cow! Very early in the morning — before the sun rises — the farmer wakes up to milk the cows. The milk travels in a cold tanker to a factory, then to the shop, then to your fridge. Your glass of milk has been on quite an adventure!",
 vsearch:"where does milk come from toddlers preschoolers journey",res:"https://www.youtube.com/results?search_query=where+does+milk+come+from+toddlers+preschoolers",
 act:"Milk investigation: pour milk into a clear glass and look, smell, taste it. Now try butter, cheese and yoghurt — all made from milk! Can you taste that they are related? Draw the milk's whole journey from cow to glass.",
 ff:"New Zealand produces far more milk than all the people of NZ could ever drink! Most of our milk is made into butter, cheese and milk powder and shipped to countries all around the world."},
{id:"fml3",title:"Chickens and Eggs",age:"2–5",dur:"15 min",
 content:"A healthy hen can lay one egg nearly every single day! The colour of the eggshell depends on the breed of the hen. Eggs are one of the most complete foods God made — full of protein, vitamins and everything a growing body needs!",
 vsearch:"chickens eggs toddlers preschoolers where do eggs come from",res:"https://www.youtube.com/results?search_query=chickens+eggs+toddlers+preschoolers",
 act:"Egg exploration: crack an egg carefully into a clear bowl. Look at it — yellow yolk, clear white, thin membrane. Scramble it for breakfast. Tell the egg's story from beginning to end while you eat!",
 ff:"Orthodox monasteries have kept chickens for 1,500 years for their eggs on non-fasting days. Even the rooster serves a purpose — his crow marks the hour when the monks rise for morning prayer!"},
{id:"fml4",title:"Wool: From Sheep to Jumper",age:"2–5",dur:"15 min",
 content:"A sheep grows a thick woolly coat called a fleece! Every spring the farmer shears it off with special clippers — it is like a sheep getting a haircut and the sheep is not hurt at all! Then the wool is washed, spun into yarn and knitted into clothes.",
 vsearch:"wool sheep shearing toddlers preschoolers NZ",res:"https://www.youtube.com/results?search_query=wool+sheep+shearing+toddlers+preschoolers",
 act:"Feel a woolly jumper or a piece of raw wool. Is it soft? Warm? A little springy? Try simple finger knitting with thick wool, making a chain with your fingers one loop at a time.",
 ff:"Jesus called Himself the Good Shepherd and called us His sheep. He said: My sheep hear my voice and I know them and they follow Me. We learn to recognise Jesus' voice too — through prayer and Scripture!"},
{id:"fml5",title:"The Farmer's Long Day",age:"2–5",dur:"15 min",
 content:"Farmers are some of the hardest working people in the world — they work every single day of the year including Christmas and Matariki! A dairy farmer wakes up at 4 in the morning to milk the cows before the sun rises!",
 vsearch:"farmer's day life toddlers preschoolers",res:"https://www.youtube.com/results?search_query=farmer%27s+day+life+toddlers+preschoolers",
 act:"What time does a dairy farmer wake up — 4 am! Count how many more hours of sleep you get than the farmer. Draw the farmer's whole day from 4 am to 8 pm. At dinner, say a special prayer of thanks for all farmers!",
 ff:"On 1 June every year many New Zealand farming families pack all their belongings and move to a completely new farm because that is when farm employment contracts traditionally begin and end."},
{id:"fml6",title:"Baby Lambs!",age:"2–5",dur:"15 min",
 content:"In spring the most magical thing happens on NZ farms — baby lambs are born! A newborn lamb can stand up and walk within just a few minutes of being born. Jesus is called the Good Shepherd who knows each of His sheep — each of us — by name!",
 vsearch:"baby lambs spring NZ toddlers preschoolers",res:"https://www.youtube.com/results?search_query=baby+lambs+spring+NZ+toddlers+preschoolers",
 act:"Watch videos of newborn baby lambs! Draw your own fluffy white wobbly-legged baby lamb next to its mama. Make the baaing sound together.",
 ff:"Jesus said: My sheep hear My voice and I know them and they follow Me. A real lamb runs to its mother's voice through a whole flock of bleating sheep. We can learn to recognise Jesus' voice too!"},
{id:"fml7",title:"From Farm to Table",age:"2–5",dur:"15 min",
 content:"Every single thing we eat started as a living thing on a farm or in a garden! Farmers plant, water, tend and harvest. Then trucks carry the food to markets and shops. By the time food reaches your plate, many people have helped put it there!",
 vsearch:"farm to table food journey toddlers preschoolers",res:"https://www.youtube.com/results?search_query=farm+to+table+food+journey+toddlers+preschoolers",
 act:"Pick one thing on your dinner plate tonight. Trace its whole journey: Who grew it? Where? How did it travel? Who cooked it? Say a special prayer for every person who helped bring this one food to your table!",
 ff:"The Orthodox meal blessing asks God to give bread to those who hunger. When we pray before meals we remember that not everyone has enough and that we are called to share from our table!"},
{id:"fml8",title:"Bees Make Honey",age:"2–5",dur:"15 min",
 content:"Bees are among God's most amazing little workers! Each bee visits thousands of flowers every single day, collecting tiny drops of nectar. The whole hive works together to turn nectar into honey. One bee makes only about 1/12 of a teaspoon of honey in its entire life!",
 vsearch:"bees honey toddlers preschoolers nature",res:"https://www.youtube.com/results?search_query=bees+honey+toddlers+preschoolers+nature",
 act:"Taste different kinds of honey — mild clover honey and strong manuka honey. How are they different in colour, smell and taste? Draw a beehive showing the hexagonal cells.",
 ff:"Orthodox monasteries have kept bees for hundreds of years. The beeswax candles from the monastery's own bees light the icons and the altar. The bee serves God!"},
{id:"fml9",title:"Thank You Farmers!",age:"2–5",dur:"15 min",
 content:"Farmers work so hard every single day — in rain, cold, mud and heat — so that we have food on our table. Without farmers there would be no breakfast, no lunch, no dinner. Let us say a great big thank you to farmers today and every day!",
 vsearch:"thank you farmers toddlers preschoolers appreciation",res:"https://www.youtube.com/results?search_query=thank+you+farmers+toddlers+preschoolers+appreciation",
 act:"Make a beautiful thank you card for farmers! Draw your favourite farm animal or a field of vegetables. Write or dictate inside: Thank you for working so hard to grow our food. We pray for you!",
 ff:"In the Old Testament God commanded the Israelites to leave the corners of their fields unharvested so that poor people could come and gather food. God built generosity right into the farming rules from the very beginning!"},
]},
{id:"construction",name:"Building and Making",emoji:"🔨",color:P.navy,tagline:"Making and fixing things with our hands!",
lessons:[
{id:"col1",title:"Tools are Helpers",age:"2–5",dur:"15 min",
 content:"Tools are designed to help us do one specific job really well! A hammer drives nails. A screwdriver turns screws. A paintbrush spreads paint. A saw cuts wood. Jesus was a carpenter — He used tools every single day for 30 years of His life!",
 vsearch:"tools for toddlers preschoolers names uses",res:"https://www.youtube.com/results?search_query=tools+for+toddlers+preschoolers+names+uses",
 act:"Tool tour! Go through your house and find as many tools as you can. Name each one and mime how it works — pretend to hammer, saw, sweep! Which tool is your favourite to mime?",
 ff:"Jesus was called a tekton in Greek — a craftsman and builder. He spent about 30 of His 33 years on earth working with His hands. All honest work with our hands is participation in God's ongoing creation!"},
{id:"col2",title:"Building with Blocks",age:"2–5",dur:"20 min",
 content:"Building with blocks is one of the most wonderful and important activities for young children — it develops the brain, teaches problem-solving, practises maths, and is enormously satisfying! God built the entire universe with perfect precision.",
 vsearch:"building blocks towers toddlers preschoolers benefits",res:"https://www.youtube.com/results?search_query=building+blocks+towers+toddlers+preschoolers",
 act:"Build the tallest tower you can before it falls! Count the blocks as you add them. Then build a bridge between two books. Then build a zoo or farm for your toy animals. Draw your favourite thing you built today.",
 ff:"The great Cathedral of Hagia Sophia in Constantinople was built in 537 AD and was the largest and most magnificent building in the world for nearly 1,000 years."},
{id:"col3",title:"Shapes Make Buildings",age:"2–5",dur:"15 min",
 content:"When you look at a building you can see it is made of shapes! Rectangles make walls. Triangles make roofs. Circles make domes. Orthodox churches often have a beautiful dome on top — a half-sphere representing the dome of heaven coming down to meet the earth!",
 vsearch:"shapes in buildings toddlers preschoolers architecture",res:"https://www.youtube.com/results?search_query=shapes+in+buildings+toddlers+preschoolers",
 act:"Look at your house from outside. Name every shape you can see — rectangle walls, triangle roof, square windows! Draw your house labelling each shape. Now look at a picture of an Orthodox church — what extra shapes can you spot?",
 ff:"The dome of an Orthodox church represents heaven — a perfect half-sphere curving overhead like the sky! In ancient Byzantine churches the dome often contains a mosaic of Christ as Pantocrator looking down in love."},
{id:"col4",title:"Painting Makes Things Beautiful",age:"2–5",dur:"20 min",
 content:"Painting transforms things! A grey wall becomes warm and welcoming. A piece of wood becomes an icon full of holiness and prayer. The people who paint icons in the Orthodox Church are called iconographers — they fast and pray before beginning!",
 vsearch:"painting for toddlers preschoolers creative art",res:"https://www.youtube.com/results?search_query=painting+for+toddlers+preschoolers+creative+art",
 act:"Paint something beautiful today! Try a church with a golden dome on dark blue paper, or a simple golden cross. After you finish, look at it and say: I made something beautiful — and God made me!",
 ff:"Orthodox iconographers never sign their icons with their own name — they sign the name of the saint depicted. They believe they are only the instrument through which God is working. All glory goes to God!"},
{id:"col5",title:"Fixing Things!",age:"2–5",dur:"15 min",
 content:"One of the most satisfying things in the world is fixing something that is broken! A torn page can be taped. A loose button can be sewn back on. A cracked flowerpot can be glued. Choosing to fix instead of throwing away shows gratitude for what we have!",
 vsearch:"fixing mending things toddlers preschoolers",res:"https://www.youtube.com/results?search_query=fixing+mending+things+toddlers+preschoolers",
 act:"Fix something small today with a parent's help! Tape a torn book page. Glue something that broke. Tighten a loose screw. Say: I fixed it! — and feel the satisfaction of a mended thing!",
 ff:"The Japanese art of kintsugi repairs broken pottery by filling the cracks with gold — making the broken places visible and beautiful. The broken repaired vessel is considered more beautiful than the perfect original. God does something similar with us!"},
{id:"col6",title:"Making a Bird Feeder",age:"2–5",dur:"30 min",
 content:"Building something for the birds is one of the kindest and most satisfying small projects a little child can do! Jesus said that God knows when even one sparrow falls to the ground. If God cares so carefully for birds, then we should care for them too!",
 vsearch:"bird feeder toddlers preschoolers simple making",res:"https://www.youtube.com/results?search_query=bird+feeder+toddlers+preschoolers+simple+making",
 act:"Make a pinecone bird feeder: roll a large pinecone in peanut butter or lard, then roll in wild birdseed. Tie a string to it and hang in a tree where you can watch from a window. Keep a log of which birds visit each day!",
 ff:"Many Orthodox saints had a remarkable relationship with birds and animals because of their great stillness and love. St Seraphim of Sarov fed a wild bear by hand from his forest cell every day for years."},
{id:"col7",title:"My Room My Space",age:"2–5",dur:"20 min",
 content:"Your bedroom is a very special small world that belongs to you — your turangawaewae! When your room is tidy and cared for, you feel calm and happy and free to play and sleep well. Learning to look after your small space is the beginning of looking after the whole big world!",
 vsearch:"tidying bedroom toddlers preschoolers routine",res:"https://www.youtube.com/results?search_query=tidying+bedroom+toddlers+preschoolers+routine",
 act:"Room tidy time! Toys in their basket, books on the shelf, clothes in the hamper. When done, stand in the middle and take a big breath: This is my beautiful clean room! Then place a small cross or icon in a corner — now it is a holy space!",
 ff:"Orthodox Christians often have a prayer corner in their bedroom — a beautiful corner with an icon and a small candle. This turns the ordinary bedroom into a little church — a place where heaven and home touch!"},
{id:"col8",title:"Hammering (With Help!)",age:"3–5",dur:"20 min",
 content:"Hammering a nail into wood is one of the most satisfying feelings! It requires concentration, good aim and just the right force — not too hard, not too soft. With adult supervision and safety glasses, even young children can try hammering nails into soft pine wood.",
 vsearch:"hammering nails young children supervised woodworking",res:"https://www.youtube.com/results?search_query=hammering+nails+young+children+supervised",
 act:"With a parent very close by and safety glasses on: hold a large nail upright in soft pine wood. Have the adult start it for you, then try a few careful gentle taps. Go slowly! Celebrate every nail you drive in.",
 ff:"Jesus, who was a carpenter and builder, held hammers and drove nails every working day of His working life. The same hands that hold the whole universe in prayer also held ordinary tools and made ordinary things!"},
{id:"col9",title:"Our Home: A Gift from God",age:"2–5",dur:"15 min",
 content:"Our home is one of God's greatest gifts to our family — a safe warm sheltered place where we belong! Not every person in the world has a home like ours. When we appreciate our home and look after it carefully, we are saying thank you to God.",
 vsearch:"home appreciation gratitude toddlers preschoolers",res:"https://www.youtube.com/results?search_query=home+appreciation+gratitude+toddlers+preschoolers",
 act:"Gratitude tour of your home! Walk through every room and find one thing in each room to say thank you for. Say thank you out loud! Draw your whole home with your whole family inside it. Write: Our home is God's gift!",
 ff:"The Book of Ruth in the Bible is a beautiful story about belonging, about home, and about making room for someone who has no home. Ruth was a foreigner who found a home through loyalty and love!"},
]},
{id:"orthodox",name:"Orthodox Bible Study",emoji:"☩",color:P.byz,tagline:"The Church the saints and knowing God.",
lessons:[
{id:"obl1",title:"God Made Everything!",age:"2–5",dur:"15 min",
 content:"In the very beginning God made everything! Light! Sky! Land and seas! Plants! Stars! Sun and moon! Animals! And people — made in His own image! After each day of creation God looked at what He had made and said: It is good! It is good! It is good! You are one of God's very best creations!",
 vsearch:"creation story God made everything toddlers preschoolers",res:"https://www.youtube.com/results?search_query=creation+story+God+made+everything+toddlers+preschoolers",
 act:"Draw the seven days of creation — one picture per day! Day 1: light. Day 2: sky and clouds. Day 3: land and plants. Day 4: sun moon and stars. Day 5: fish and birds. Day 6: animals and people. Day 7: God rested with a big happy smile!",
 ff:"After creating everything God did not just leave it and walk away — He loves it and looks after it every single moment of every day. Psalm 145 says: You give them their food at the proper time. God feeds every creature every day!"},
{id:"obl2",title:"Jesus Loves Me!",age:"2–5",dur:"15 min",
 content:"The most important thing in the whole world to know is this: Jesus loves you! He loved you before you were born. He loves you when you are happy and when you are sad. Nothing can ever make Him stop loving you!",
 vsearch:"Jesus loves me toddlers preschoolers song",res:"https://www.youtube.com/results?search_query=Jesus+loves+me+toddlers+preschoolers+song",
 act:"Sing Jesus Loves Me together. Then stretch your arms as wide as they will go — God's love is THIS big! And even bigger than that! Pray: Dear Jesus, thank you for loving me. I love you too. Amen!",
 ff:"The Bible says: God loved the world so much that He sent His only Son (John 3:16). God's love was so great that He came Himself — in the person of Jesus — to show us what love really looks like!"},
{id:"obl3",title:"Talking to God: Prayer",age:"2–5",dur:"15 min",
 content:"Prayer is simply talking to God — and He always listens to every single word! You can pray anywhere and any time. Before breakfast: thank You! Before sleep: help me and keep me safe! When something is scary: I need You! God loves hearing from you!",
 vsearch:"prayer for toddlers preschoolers talking to God",res:"https://www.youtube.com/results?search_query=prayer+for+toddlers+preschoolers+talking+to+God",
 act:"Learn a simple morning prayer: Good morning God, thank You for today. Keep me safe in every way. Help me learn and help me grow. Help me love the ones I know. Amen! Say it every single morning this week.",
 ff:"Jesus prayed all the time — in the early morning, in the evening, on mountain tops, in the garden. He prayed before meals and before miracles. If the Son of God prayed constantly, prayer must be the most important thing of all!"},
{id:"obl4",title:"The Sign of the Cross",age:"2–5",dur:"10 min",
 content:"Orthodox Christians make the sign of the cross by touching our forehead (mind), chest (heart), right shoulder, and left shoulder. We say: In the name of the Father and the Son and the Holy Spirit. Amen! Every time we cross ourselves we are saying: I belong to Jesus!",
 vsearch:"sign of the cross Orthodox children toddlers simple",res:"https://www.youtube.com/results?search_query=sign+of+the+cross+Orthodox+children+toddlers",
 act:"Practise the sign of the cross slowly together: forehead, chest, right shoulder, left shoulder. Say the words as you do it. Do it three times — once slowly, once at normal speed, once with a kiss at the end!",
 ff:"When Orthodox monks make the sign of the cross they use all five fingers pressed together — representing the Five Wounds of Christ. Even the smallest gesture can carry the most profound theology!"},
{id:"obl5",title:"Our Beautiful Church",age:"2–5",dur:"15 min",
 content:"The church building is a very special place — it is where heaven touches earth! When we walk through the doors we are walking into God's house! We see beautiful icons, hear beautiful singing, smell incense, and receive the Body and Blood of Jesus.",
 vsearch:"Orthodox church for little children toddlers beautiful",res:"https://www.youtube.com/results?search_query=Orthodox+church+for+little+children+toddlers",
 act:"Draw your church from memory or with a photo to help you. Include the dome, the icons, the candles, the beautiful colours! Talk about your favourite thing about going to church.",
 ff:"When the ambassadors of Prince Vladimir visited Hagia Sophia in 987 AD they said afterwards: We did not know whether we were in heaven or on earth. An Orthodox church is designed to make heaven and earth feel like one place!"},
{id:"obl6",title:"Holy Icons",age:"2–5",dur:"15 min",
 content:"An icon is a holy picture of Jesus, the Virgin Mary or a saint — and it is much more than just a pretty picture! Icons are windows into heaven. When we stand before an icon we are standing in the presence of the person it shows.",
 vsearch:"Orthodox icons for little children toddlers holy",res:"https://www.youtube.com/results?search_query=Orthodox+icons+for+little+children+toddlers",
 act:"Look at an icon together very carefully and quietly. Who is in the picture? What are they holding? Kiss the icon gently. Draw your favourite icon in your own way — it does not have to be perfect, just full of love!",
 ff:"Every Orthodox home has a prayer corner with icons — sometimes called the beautiful corner. The icons watch over the family while they sleep, eat, work and play. Icons are holy family members!"},
{id:"obl7",title:"The Theotokos: Mary Our Lady",age:"2–5",dur:"15 min",
 content:"Theotokos means the one who gave birth to God — the Virgin Mary, the mother of Jesus. She is the most beloved woman in all of history! When the angel Gabriel came to her she said yes — and that yes changed everything! She loves us and prays for us every single day!",
 vsearch:"Virgin Mary Theotokos for little children Orthodox",res:"https://www.youtube.com/results?search_query=Virgin+Mary+Theotokos+for+little+children+Orthodox",
 act:"Find an icon of the Theotokos and look at it together. She is often wearing blue and red and holding Jesus. Draw a picture of a mother holding a baby — the most basic image of love. Then say: Holy Theotokos, pray for us!",
 ff:"The prayer Theotokos and Virgin, rejoice, O Mary full of grace has been prayed in Orthodox churches every single day for over 1,500 years! Right now somewhere in the world an Orthodox Christian is praying those same words."},
{id:"obl8",title:"Fasting and Feasting",age:"2–5",dur:"15 min",
 content:"The Orthodox Church has special days when we eat very simply (fasting) and special days when we celebrate with beautiful food and great joy (feasting)! Pascha — Orthodox Easter — is the greatest feast of all! Waiting for something makes it even more wonderful when it arrives!",
 vsearch:"Orthodox fasting feasting toddlers little children",res:"https://www.youtube.com/results?search_query=Orthodox+fasting+feasting+toddlers+little+children",
 act:"Talk about the feast days your family celebrates — what special foods do you make? Draw a feast day table with all the special food and your whole family around it.",
 ff:"At Pascha (Orthodox Easter) after 40 days of fasting, Orthodox Christians break the fast at midnight with a special joyful meal! The joy of the feast is made so much sweeter by the waiting of the fast!"},
{id:"obl9",title:"Noah and the Rainbow",age:"2–5",dur:"15 min",
 content:"God asked Noah to build a big boat called an ark and put two of every animal inside — and Noah obeyed! When the water dried up God placed a beautiful rainbow in the sky as His promise: I will always love you and care for you. Every rainbow we ever see is that same promise still shining!",
 vsearch:"Noah's Ark rainbow toddlers preschoolers Bible story",res:"https://www.youtube.com/results?search_query=Noah%27s+Ark+rainbow+toddlers+preschoolers+Bible",
 act:"Make a rainbow together using all 7 colours! While you colour, tell the Noah story. Then line up toy animals in pairs going into a paper ark. Next time you see a real rainbow say: There is God's promise to us!",
 ff:"God said: I have set my rainbow in the clouds and it will be the sign of the covenant between me and the earth. A covenant is a promise so serious it can never be broken. God keeps every single one of His promises — always!"},
{id:"obl10",title:"The Good Shepherd",age:"2–5",dur:"15 min",
 content:"Jesus told a story about a shepherd who had 100 sheep. One went missing and the shepherd left the 99 safe sheep to search for the lost one. When he found it he put it on his shoulders and carried it home! Jesus says: I am the Good Shepherd. He will always come searching for you!",
 vsearch:"Good Shepherd story toddlers preschoolers animated",res:"https://www.youtube.com/results?search_query=Good+Shepherd+story+toddlers+preschoolers+animated",
 act:"Act out the Good Shepherd story: hide a stuffed animal somewhere in the house. The Good Shepherd goes searching everywhere until they find it! Then carry it home on your shoulders and celebrate!",
 ff:"In the catacombs of Rome where the very first Christians hid to pray, the image painted most often on the walls was a young man with a lamb on his shoulders — the Good Shepherd! This was the first Christians' favourite picture of Jesus."},
{id:"obl11",title:"Giving to Others",age:"2–5",dur:"15 min",
 content:"Almsgiving means giving to people who need help! In the Orthodox Church fasting, prayer and almsgiving always go together. Even very small children can give — sharing a toy, giving a coin, helping a smaller child, giving your last biscuit to a friend!",
 vsearch:"giving to others almsgiving toddlers preschoolers",res:"https://www.youtube.com/results?search_query=giving+to+others+almsgiving+toddlers+preschoolers",
 act:"The giving jar: decorate a small jar beautifully. Every week, put in some saved coins. When it is full, decide together where to give it — a church collection, a local food bank, or someone in need.",
 ff:"Jesus said: Whatever you did for one of the least of these brothers and sisters of mine, you did for me (Matthew 25:40). Every single time we help someone in need we are helping Jesus Himself! This changes how we see every person around us."},
{id:"obl12",title:"Thank You God!",age:"2–5",dur:"15 min",
 content:"Saying thank you to God — gratitude — is one of the most important and beautiful prayers we can ever pray! When we say thank you to God we are saying: I notice what You have given me. I know it comes from You. I receive it with joy! Psalm 136 says His love endures forever — and repeats it 26 times in a row!",
 vsearch:"gratitude prayer thankfulness toddlers preschoolers",res:"https://www.youtube.com/results?search_query=gratitude+prayer+thankfulness+toddlers+preschoolers",
 act:"Gratitude time! Name 5 things you are thankful for today. Draw each one. Tonight before bed, thank God for 3 specific things from today. God loves when we notice His little gifts!",
 ff:"St John Chrysostom's very last recorded words — even in exile, even as he was dying — were: Glory to God for all things. If the greatest preacher of the Church died with gratitude on his lips, then gratitude must be the most important prayer of all!"},
]},
];

// Storage: uses window.storage in Claude artifact env, falls back to localStorage elsewhere
const _store = typeof window !== 'undefined' && window.storage ? {
  get: async k => { try{ const r = await window.storage.get(k); return r?.value ? JSON.parse(r.value) : null; } catch{ return null; } },
  set: async (k,v) => { try{ await window.storage.set(k, JSON.stringify(v)); } catch{} },
} : {
  get: async k => { try{ const r = localStorage.getItem(k); return r ? JSON.parse(r) : null; } catch{ return null; } },
  set: async (k,v) => { try{ localStorage.setItem(k, JSON.stringify(v)); } catch{} },
};
const sGet = k => _store.get(k);
const sSet = (k,v) => _store.set(k,v);
const todayKey = () => new Date().toISOString().slice(0,10);

// ─── WEEKLY SCHEDULE BUILDER ────────────────────────────────────────────────
// Mon: English + Maths
// Tue: Orthodox Bible + Saint of the Week
// Wed: Nature Science + Greek
// Thu: NZ/Māori + Sports & Nutrition
// Fri: rotating practical (Cooking / Gardening / Farming / Construction)
// Returns SUBJECTS_LITTLE for ages 2-5, SUBJECTS for ages 6+
const getSubjectList = (childAge) => (childAge && childAge <= 5) ? SUBJECTS_LITTLE : SUBJECTS;

const PRACTICALS = ["cooking","gardening","farming","construction"];
function buildWeek(idx, childAge=6){
  const SL = getSubjectList(childAge);
  const saint = SAINTS[idx%12];
  const getL = sid => { const s=SL.find(s=>s.id===sid); return s?s.lessons[idx%s.lessons.length]:null; };
  const pId = PRACTICALS[idx%4];
  const pS = SL.find(s=>s.id===pId);
  const pL = pS?.lessons[Math.floor(idx/4)%pS.lessons.length];
  return {
    week:idx+1, saint,
    days:[
      {day:"Monday",   emoji:"📚",pairs:[
        {s:SL.find(s=>s.id==="english"),  l:getL("english")},
        {s:SL.find(s=>s.id==="maths"),    l:getL("maths")},
      ]},
      {day:"Tuesday",  emoji:"☩",  pairs:[
        {s:SL.find(s=>s.id==="orthodox"), l:getL("orthodox")},
        {s:{id:"saint",name:"Saint of the Week",emoji:"🕯️",color:P.byz},
         l:{id:"snt"+idx,title:"Life of "+saint.n,dur:"30 min",age:"All",
            content:saint.life, act:saint.lesson,
            vsearch:saint.vid, res:saint.res, ff:"☩ Prayer: "+saint.prayer}},
      ]},
      {day:"Wednesday",emoji:"🌿", pairs:[
        {s:SL.find(s=>s.id==="nature"),   l:getL("nature")},
        {s:SL.find(s=>s.id==="greek"),    l:getL("greek")},
      ]},
      {day:"Thursday", emoji:"🥝", pairs:[
        {s:SL.find(s=>s.id==="maori"),    l:getL("maori")},
        {s:SL.find(s=>s.id==="sports"),   l:getL("sports")},
      ]},
      {day:"Friday",   emoji:"🛠️", pairs:[
        {s:pS, l:pL},
      ]},
    ]
  };
}
const WEEK_PLANS = Array.from({length:36},(_,i)=>buildWeek(i));
const getWeekPlans=(childAge=6)=>Array.from({length:36},(_,i)=>buildWeek(i,childAge));

// ─── APP ROOT ───────────────────────────────────────────────────────────────
export default function App(){
  const [children, setChildren] = useState([]);
  const [childId,  setChildId]  = useState(null);
  const [section,      setSection]      = useState("dashboard"); // dashboard | schedule | resources | lessons | subject | lesson
  const [prevSection,  setPrevSection]  = useState("dashboard"); // where "Back" returns to
  const [subjId,       setSubjId]       = useState(null);
  const [lessonId,     setLessonId]     = useState(null);
  const [inlineLesson, setInlineLesson] = useState(null); // for saint/ad-hoc lessons not in SUBJECTS
  const [loading,      setLoading]      = useState(true);
  const [modal,        setModal]        = useState(false);
  const [editC,        setEditC]        = useState(null);

  useEffect(()=>{
    (async()=>{
      const c=await sGet("hh_c"); const lid=await sGet("hh_cid");
      if(c&&c.length>0){
        setChildren(c);
        const activeId = lid&&c.find(x=>x.id===lid)?lid:c[0].id;
        setChildId(activeId);
        // resume last lesson if one was saved
        const activeChild = c.find(x=>x.id===activeId);
        if(activeChild?.lastLesson){
          const {subjId:sId,lessonId:lId,section:sec,inlineLesson:il} = activeChild.lastLesson;
          setPrevSection(sec||"dashboard");
          setSubjId(sId);
          setLessonId(lId);
          setInlineLesson(il||null);
          setSection("lesson");
        }
      }
      else setModal(true);
      setLoading(false);
    })();
  },[]);
  useEffect(()=>{if(!loading)sSet("hh_c",children);},[children,loading]);
  useEffect(()=>{if(childId)sSet("hh_cid",childId);},[childId]);

  const child = useMemo(()=>children.find(c=>c.id===childId),[children,childId]);
  const addChild = (name,age,color)=>{
    const c={id:`c${Date.now()}`,name,age:parseInt(age)||6,color,progress:{},streak:0,lastDate:null,lastLesson:null};
    setChildren(p=>[...p,c]);setChildId(c.id);setModal(false);setEditC(null);
  };
  const updChild = (id,u)=>setChildren(p=>p.map(c=>c.id===id?{...c,...u}:c));
  const delChild = (id)=>{
    const next=children.filter(c=>c.id!==id);setChildren(next);
    if(childId===id){setChildId(next[0]?.id||null);if(!next.length)setModal(true);}
  };
  const toggleDone = lid => {
    if(!child) return;
    const prog={...child.progress};
    if(prog[lid]?.done) delete prog[lid]; else prog[lid]={done:true,date:todayKey()};
    const today=todayKey();let{streak=0,lastDate}=child;
    if(lastDate!==today){const y=new Date(Date.now()-86400000).toISOString().slice(0,10);streak=lastDate===y?streak+1:1;lastDate=today;}
    updChild(child.id,{progress:prog,streak,lastDate});
  };
  // openLesson(subjId, lessonId, inlineLessonObj?) — inlineLessonObj used for saints/ad-hoc
  const openLesson=(sId,lId,inline=null)=>{
    setPrevSection(section);
    setSubjId(sId);
    setLessonId(lId);
    setInlineLesson(inline);
    setSection("lesson");
    // persist last lesson so child resumes here on next login
    if(child){
      const updated = children.map(c=>c.id===child.id
        ? {...c, lastLesson:{subjId:sId,lessonId:lId,section,inlineLesson:inline}}
        : c);
      setChildren(updated);
    }
  };
  const openSubject=sId=>{setSubjId(sId);setSection("subject");};
  const weekPlans=getWeekPlans(child?.age);
  const curWeek=Math.min(Math.floor((Date.now()-new Date(new Date().getFullYear(),0,1))/(7*864e5)),35);

  if(loading) return <div style={{background:P.cream,minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center"}}><span style={{fontFamily:"serif",fontSize:"1.5rem",color:P.ink}}>☩ Hearth &amp; Home…</span></div>;

  const NAV=[{v:"dashboard",l:"Dashboard",e:"🏡"},{v:"schedule",l:"Weekly Plan",e:"📅"},{v:"resources",l:"Resources",e:"📖"},{v:"lessons",l:"All Lessons",e:"📚"}];

  return (
    <div style={{background:P.cream,minHeight:"100vh",fontFamily:"'Nunito',sans-serif",color:P.ink}}>
      <style>{FONT}</style>
      <style>{`
        .df{font-family:'Playfair Display',serif;font-weight:700}
        .sf{font-family:'Caveat',cursive;font-weight:600}
        .bi{border:2px solid ${P.ink}}
        .cs{box-shadow:3px 4px 0 ${P.ink}}
        .css{box-shadow:2px 2px 0 ${P.ink}}
        .lf{transition:transform .15s,box-shadow .15s}
        .lf:hover{transform:translate(-1px,-2px);box-shadow:5px 6px 0 ${P.ink}}
        .lf:active{transform:translate(1px,1px);box-shadow:1px 1px 0 ${P.ink}}
        button{font-family:inherit;cursor:pointer}*{box-sizing:border-box}
      `}</style>

      {/* ── HEADER / NAV ── */}
      <header style={{background:P.parch,borderBottom:`2px solid ${P.ink}`,position:"sticky",top:0,zIndex:40}}>
        <div style={{maxWidth:"960px",margin:"0 auto",padding:"8px 16px",display:"flex",alignItems:"center",gap:"10px",flexWrap:"wrap"}}>
          <button onClick={()=>setSection("dashboard")} style={{display:"flex",alignItems:"center",gap:"8px",background:"none",border:"none",padding:0,flexShrink:0}}>
            <div style={{width:"34px",height:"34px",borderRadius:"50%",background:P.byz,border:`2px solid ${P.ink}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:".95rem",color:P.cream}}>☩</div>
            <span className="df" style={{fontSize:"1.15rem"}}>Hearth &amp; Home</span>
          </button>
          <nav style={{display:"flex",gap:"4px",flex:1,flexWrap:"wrap"}}>
            {NAV.map(n=>(
              <button key={n.v} onClick={()=>setSection(n.v)}
                style={{padding:"5px 10px",borderRadius:"8px",border:`2px solid ${
                  section===n.v ||
                  (section==="lesson" && prevSection===n.v) ||
                  (section==="lesson" && n.v==="lessons" && prevSection==="subject") ||
                  (section==="subject" && n.v==="lessons")
                  ? P.ink:"transparent"}`,background:
                  section===n.v ||
                  (section==="lesson" && prevSection===n.v) ||
                  (section==="lesson" && n.v==="lessons" && prevSection==="subject") ||
                  (section==="subject" && n.v==="lessons")
                  ? P.ink:P.cream,color:
                  section===n.v ||
                  (section==="lesson" && prevSection===n.v) ||
                  (section==="lesson" && n.v==="lessons" && prevSection==="subject") ||
                  (section==="subject" && n.v==="lessons")
                  ? P.cream:P.ink,fontSize:".8rem",fontWeight:700,display:"flex",alignItems:"center",gap:"4px"}}>
                <span>{n.e}</span><span style={{display:"none"}} className="nlbl">{n.l}</span>
              </button>
            ))}
          </nav>
          {child && <ChildPicker child={child} children={children} onSwitch={setChildId} onAdd={()=>{setEditC(null);setModal(true);}} />}
        </div>
        <style>{`@media(min-width:480px){.nlbl{display:inline!important}}`}</style>
      </header>

      <main style={{maxWidth:"960px",margin:"0 auto",padding:"16px 16px 60px"}}>
        {section==="dashboard" && child && <Dashboard child={child} curWeek={curWeek} weekPlans={weekPlans} onLesson={openLesson} onSubject={openSubject} onToggle={toggleDone} onEdit={()=>{setEditC(child);setModal(true);}} />}
        {section==="schedule" && child && <ScheduleView child={child} curWeek={curWeek} weekPlans={weekPlans} onLesson={openLesson} onToggle={toggleDone} />}
        {section==="resources" && <ResourcesView />}
        {section==="lessons" && <AllLessonsView child={child} subjects={getSubjectList(child.age)} onSubject={openSubject} />}
        {section==="subject" && subjId && child && <SubjectView subj={getSubjectList(child.age).find(s=>s.id===subjId)} child={child} onBack={()=>setSection("lessons")} onLesson={lId=>openLesson(subjId,lId)} />}
        {section==="lesson" && child && (() => {
          // Resolve subj + lesson — works for both SUBJECTS lessons and inline (saint) lessons
          const resolvedSubj = subjId==="saint"
            ? {id:"saint",name:"Saint of the Week",emoji:"🕯️",color:P.byz,tagline:"The life and witness of an Orthodox saint."}
            : getSubjectList(child.age).find(s=>s.id===subjId);
          const resolvedLesson = inlineLesson
            ? inlineLesson
            : resolvedSubj?.lessons?.find(l=>l.id===lessonId);
          const backLabel = prevSection==="schedule" ? "Weekly Plan"
                          : prevSection==="dashboard" ? "Dashboard"
                          : resolvedSubj?.name || "Back";
          const goBack = ()=>{
            setSection(prevSection==="lesson" ? "schedule" : prevSection);
            if(prevSection!=="schedule" && prevSection!=="dashboard") {/* stay in subject */}
          };
          return resolvedLesson
            ? <LessonView subj={resolvedSubj} lesson={resolvedLesson} child={child} backLabel={backLabel} onBack={goBack} onToggle={toggleDone} />
            : null;
        })()}
      </main>

      {modal && <ProfileModal existing={editC} all={children} onClose={()=>{setModal(false);setEditC(null);}} onSave={(n,a,c)=>{if(editC){updChild(editC.id,{name:n,age:parseInt(a)||editC.age,color:c});setModal(false);setEditC(null);}else addChild(n,a,c);}} onDelete={id=>{delChild(id);setModal(false);setEditC(null);}} />}

      <footer style={{borderTop:`2px solid ${P.ink}`,background:P.parch,padding:"20px 16px",textAlign:"center"}}>
        <div className="df" style={{fontSize:"1.1rem",marginBottom:"4px"}}>Hearth &amp; Home</div>
        <div style={{opacity:.65,fontSize:".8rem"}}>Orthodox homeschool companion · 11 subjects · 36-week curriculum · ages 4–10</div>
        <div className="sf" style={{color:P.byz,fontSize:".95rem",marginTop:"4px"}}>"The glory of God is a human being fully alive." — St Irenaeus of Lyon</div>
      </footer>
    </div>
  );
}

// ─── CHILD PICKER ──────────────────────────────────────────────────────────
function ChildPicker({child,children,onSwitch,onAdd}){
  const [open,setOpen]=useState(false);
  return (
    <div style={{position:"relative",flexShrink:0}}>
      <button onClick={()=>setOpen(!open)} className="bi css lf"
        style={{background:child.color,color:P.cream,borderRadius:"999px",padding:"4px 10px",display:"flex",alignItems:"center",gap:"6px",border:"none"}}>
        <div style={{width:"22px",height:"22px",borderRadius:"50%",background:P.cream,color:P.ink,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,border:`2px solid ${P.ink}`,fontSize:".75rem",flexShrink:0}}>
          {child.name[0]?.toUpperCase()}
        </div>
        <span style={{fontWeight:700,fontSize:".82rem",maxWidth:"80px",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{child.name}</span>
        <ChevronRight size={11} style={{transform:open?"rotate(90deg)":"none",transition:"transform .2s"}}/>
      </button>
      {open&&(
        <div className="bi cs" style={{position:"absolute",right:0,top:"calc(100% + 6px)",background:P.cream,borderRadius:"14px",padding:"8px",minWidth:"190px",zIndex:50}}>
          {children.map(c=>(
            <button key={c.id} onClick={()=>{onSwitch(c.id);setOpen(false);}}
              style={{width:"100%",display:"flex",alignItems:"center",gap:"8px",padding:"6px 8px",borderRadius:"8px",background:child.id===c.id?"rgba(0,0,0,.06)":"transparent",border:"none"}}>
              <div style={{width:"26px",height:"26px",borderRadius:"50%",background:c.color,color:P.cream,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,border:`2px solid ${P.ink}`,fontSize:".75rem",flexShrink:0}}>{c.name[0]?.toUpperCase()}</div>
              <div style={{textAlign:"left",minWidth:0}}>
                <div style={{fontWeight:700,fontSize:".85rem",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{c.name}</div>
                <div style={{fontSize:".65rem",opacity:.6}}>Age {c.age}{c.age<=5?" 🌟 Little Learner":""} · {Object.keys(c.progress||{}).length} done</div>
              </div>
            </button>
          ))}
          <button onClick={()=>{onAdd();setOpen(false);}} className="bi css lf"
            style={{width:"100%",display:"flex",alignItems:"center",gap:"6px",padding:"6px 8px",borderRadius:"8px",background:P.gold,border:"none",fontWeight:700,fontSize:".82rem",marginTop:"6px"}}>
            <Plus size={14}/> Add a child
          </button>
        </div>
      )}
    </div>
  );
}

// ─── DASHBOARD ─────────────────────────────────────────────────────────────
function Dashboard({child,curWeek,weekPlans,onLesson,onSubject,onToggle,onEdit}){
  const SL = getSubjectList(child.age);
  const totalL = SL.reduce((s,sub)=>s+sub.lessons.length,0);
  const doneCount = Object.values(child.progress||{}).filter(p=>p.done).length;
  const pct = Math.round((doneCount/totalL)*100);
  const plan = weekPlans[curWeek];
  const monthSaint = SAINTS[new Date().getMonth()];

  // Next uncompleted lesson per today's day
  const todayLessons = useMemo(()=>{
    const dow = new Date().getDay();
    const sidMap = {1:["english","maths"],2:["orthodox"],3:["nature","greek"],4:["maori","sports"],5:[PRACTICALS[curWeek%4]]};
    const sids = sidMap[dow]||["english","maths"];
    const out=[];
    sids.forEach(sid=>{
      const s=SL.find(sub=>sub.id===sid);
      if(!s) return;
      const l=s.lessons.find(l=>!child.progress?.[l.id]?.done);
      if(l) out.push({s,l});
    });
    // fill up to 3 from any subject
    if(out.length<2) SL.forEach(s=>{
      if(out.length>=3) return;
      const l=s.lessons.find(l=>!child.progress?.[l.id]?.done);
      if(l&&!out.find(x=>x.s.id===s.id)) out.push({s,l});
    });
    return out.slice(0,3);
  },[child,curWeek]);

  const greeting=(()=>{const h=new Date().getHours();return h<12?"Good morning":h<18?"Kia ora":"Good evening";})();

  return (
    <div style={{display:"flex",flexDirection:"column",gap:"22px"}}>

      {/* Welcome banner */}
      <div className="bi cs" style={{borderRadius:"20px",padding:"18px 22px",background:child.color,color:P.cream}}>
        <div style={{display:"flex",flexWrap:"wrap",alignItems:"flex-start",justifyContent:"space-between",gap:"12px"}}>
          <div>
            <div className="sf" style={{fontSize:"1.2rem",opacity:.9}}>{greeting},</div>
            <h1 className="df" style={{fontSize:"2rem",lineHeight:1,margin:"2px 0 8px"}}>{child.name}!</h1>
            <p style={{margin:0,opacity:.95,maxWidth:"340px",fontSize:".88rem"}}>
              {child.streak>1?`🔥 ${child.streak}-day learning streak — keep it going!`:"Begin with prayer — then let's learn together."}
            </p>
          </div>
          <div style={{display:"flex",gap:"8px",flexWrap:"wrap",alignItems:"flex-start"}}>
            {[["✅","Done",doneCount],["📈","Progress",pct+"%"],["🔥","Streak",(child.streak||0)+"d"]].map(([e,l,v])=>(
              <div key={l} style={{background:P.cream,color:P.ink,borderRadius:"12px",padding:"7px 10px",textAlign:"center",border:`2px solid ${P.ink}`,boxShadow:`2px 2px 0 ${P.ink}`}}>
                <div>{e}</div>
                <div className="df" style={{fontSize:"1rem",lineHeight:1}}>{v}</div>
                <div style={{fontSize:".6rem",opacity:.65}}>{l}</div>
              </div>
            ))}
            <button onClick={onEdit} className="bi css lf" style={{background:P.cream,color:P.ink,borderRadius:"50%",width:"34px",height:"34px",display:"flex",alignItems:"center",justifyContent:"center",border:"none"}}>
              <Edit3 size={14}/>
            </button>
          </div>
        </div>
        {/* Progress bar */}
        <div style={{display:"flex",alignItems:"center",gap:"10px",marginTop:"14px"}}>
          <div style={{flex:1,height:"8px",borderRadius:"999px",background:"rgba(255,255,255,.25)",overflow:"hidden"}}>
            <div style={{height:"100%",background:P.cream,width:`${pct}%`,transition:"width .4s"}}/>
          </div>
          <span style={{fontSize:".75rem",fontWeight:700,opacity:.9,whiteSpace:"nowrap"}}>{doneCount}/{totalL} lessons</span>
        </div>
      </div>

      {/* Saint of the Month */}
      <div className="bi cs" style={{borderRadius:"16px",padding:"14px 16px",background:P.parch,display:"flex",gap:"12px",alignItems:"flex-start",flexWrap:"wrap"}}>
        <div style={{width:"44px",height:"44px",borderRadius:"10px",background:P.byz,color:P.cream,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.2rem",border:`2px solid ${P.ink}`,flexShrink:0}}>🕯️</div>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontSize:".65rem",fontWeight:700,textTransform:"uppercase",letterSpacing:".06em",opacity:.55,marginBottom:"2px"}}>Saint of the Month — {monthSaint.m}</div>
          <div className="df" style={{fontSize:"1rem",marginBottom:"4px"}}>{monthSaint.n}</div>
          <p style={{margin:"0 0 6px",fontSize:".82rem",opacity:.8,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical"}}>{monthSaint.life}</p>
          <div style={{fontSize:".75rem",fontStyle:"italic",color:P.byz}}>{monthSaint.prayer}</div>
          <a href={monthSaint.res} target="_blank" rel="noopener noreferrer" style={{display:"inline-flex",alignItems:"center",gap:"4px",fontSize:".72rem",fontWeight:700,color:P.byz,marginTop:"6px"}}>
            <ExternalLink size={11}/> Read full life at OCA.org
          </a>
        </div>
      </div>

      {/* Today's schedule */}
      <section>
        <h2 className="df" style={{fontSize:"1.3rem",marginBottom:"10px"}}>📋 Today's Lessons
          <span className="sf" style={{color:P.rose,fontSize:".95rem",fontWeight:400,marginLeft:"8px"}}>your next steps</span>
        </h2>
        <div style={{display:"flex",flexDirection:"column",gap:"8px"}}>
          {todayLessons.length===0
            ? <div className="bi" style={{borderRadius:"12px",padding:"14px",textAlign:"center",background:P.parch}}>🎉 All of today's lessons are done — wonderful work!</div>
            : todayLessons.map(({s,l})=>{
              const done=child.progress?.[l.id]?.done;
              return (
                <div key={l.id} className="bi cs lf" style={{borderRadius:"12px",padding:"10px 12px",background:done?P.parch:P.cream,display:"flex",alignItems:"flex-start",gap:"10px"}}>
                  <div style={{width:"38px",height:"38px",borderRadius:"10px",background:s.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.1rem",border:`2px solid ${P.ink}`,flexShrink:0}}>{s.emoji}</div>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:".65rem",fontWeight:700,textTransform:"uppercase",opacity:.55}}>{s.name}</div>
                    <div className="df" style={{fontSize:".95rem",margin:"2px 0"}}>{l.title}</div>
                    <div style={{fontSize:".72rem",opacity:.6}}>⏱ {l.dur} · Ages {l.age}</div>
                    {/* Watch link */}
                    {l.vsearch&&<a href={`https://www.youtube.com/results?search_query=${encodeURIComponent(l.vsearch)}`} target="_blank" rel="noopener noreferrer"
                      style={{display:"inline-flex",alignItems:"center",gap:"3px",fontSize:".72rem",fontWeight:700,color:P.rose,marginTop:"4px"}}>
                      <Play size={10}/> Watch on YouTube
                    </a>}
                    {/* Activity */}
                    {l.act&&<div style={{marginTop:"6px",padding:"6px 8px",borderRadius:"6px",background:"rgba(0,0,0,.04)",fontSize:".78rem"}}>
                      <span style={{fontWeight:700}}>✋ Do this: </span>{l.act.length>120?l.act.slice(0,120)+"…":l.act}
                    </div>}
                  </div>
                  <div style={{display:"flex",flexDirection:"column",gap:"4px",alignItems:"flex-end",flexShrink:0}}>
                    <button onClick={()=>onLesson(s.id,l.id)} className="bi css lf"
                      style={{background:s.color,color:P.cream,borderRadius:"8px",padding:"5px 10px",fontWeight:700,fontSize:".76rem",border:"none"}}>
                      Open →
                    </button>
                    <button onClick={()=>onToggle(l.id)} style={{background:"none",border:"none",color:done?P.forest:P.ink,opacity:done?1:.25}}>
                      {done?<CheckCircle2 size={20}/>:<Circle size={20}/>}
                    </button>
                  </div>
                </div>
              );
            })}
        </div>
      </section>

      {/* This week's plan compact */}
      <section>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"10px",flexWrap:"wrap",gap:"8px"}}>
          <h2 className="df" style={{fontSize:"1.3rem",margin:0}}>📅 Week {plan.week} Overview</h2>
          <span className="sf" style={{color:P.byz,fontSize:".9rem"}}>🕯️ {plan.saint.n}</span>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:"5px"}}>
          {plan.days.map(day=>(
            <div key={day.day} className="bi" style={{borderRadius:"10px",padding:"8px 12px",background:P.cream,display:"flex",alignItems:"flex-start",gap:"10px",flexWrap:"wrap"}}>
              <div style={{fontWeight:700,fontSize:".82rem",minWidth:"80px",display:"flex",alignItems:"center",gap:"5px"}}>{day.emoji} {day.day}</div>
              <div style={{display:"flex",gap:"5px",flex:1,flexWrap:"wrap"}}>
                {day.pairs.map(({s,l},i)=>{
                  if(!s||!l) return null;
                  const isDone=child.progress?.[l.id]?.done;
                  return (
                    <button key={i} onClick={()=>{
                        if(s.id==="saint") onLesson("saint",l.id,l);
                        else if(s.id) onLesson(s.id,l.id);
                      }}
                      style={{display:"flex",alignItems:"center",gap:"4px",padding:"3px 7px",borderRadius:"6px",background:isDone?"rgba(45,90,39,.12)":P.parch,border:`1.5px solid ${P.ink}`,fontSize:".74rem",cursor:"pointer",fontWeight:600}}>
                      <span>{s.emoji}</span>
                      <span style={{maxWidth:"110px",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{l.title}</span>
                      {isDone&&<CheckCircle2 size={11} style={{color:P.forest,flexShrink:0}}/>}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Progress by subject */}
      <section>
        <h2 className="df" style={{fontSize:"1.3rem",marginBottom:"10px"}}>📊 Progress by Subject</h2>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:"7px"}}>
          {SL.map(s=>{
            const sd=s.lessons.filter(l=>child.progress?.[l.id]?.done).length;
            const p=(sd/s.lessons.length)*100;
            return (
              <button key={s.id} onClick={()=>onSubject(s.id)} className="bi css lf"
                style={{borderRadius:"12px",padding:"10px",background:P.cream,textAlign:"left",border:"",cursor:"pointer",display:"flex",flexDirection:"column",gap:"5px"}}>
                <div style={{display:"flex",alignItems:"center",gap:"7px"}}>
                  <span>{s.emoji}</span>
                  <span style={{fontWeight:700,fontSize:".82rem",flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{s.name}</span>
                  <span style={{fontSize:".68rem",opacity:.55,flexShrink:0}}>{sd}/{s.lessons.length}</span>
                </div>
                <div style={{height:"5px",borderRadius:"999px",background:P.parch,border:`1.5px solid ${P.ink}`,overflow:"hidden"}}>
                  <div style={{height:"100%",background:s.color,width:`${p}%`}}/>
                </div>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
}

// ─── SCHEDULE VIEW ──────────────────────────────────────────────────────────
function ScheduleView({child,curWeek,weekPlans,onLesson,onToggle}){
  const [selWk,setSelWk]=useState(curWeek);
  const plan=weekPlans[selWk];

  return (
    <div style={{display:"flex",flexDirection:"column",gap:"18px"}}>
      <div className="bi cs" style={{borderRadius:"18px",padding:"16px 20px",background:P.navy,color:P.cream}}>
        <h1 className="df" style={{fontSize:"1.6rem",margin:"0 0 4px"}}>📅 36-Week Curriculum Planner</h1>
        <p className="sf" style={{fontSize:"1rem",margin:0,opacity:.9}}>Monday–Friday · 30–45 min per subject · 1–2 subjects per day</p>
      </div>

      {/* Week selector */}
      <div>
        <div style={{marginBottom:"8px",fontWeight:700,fontSize:".85rem"}}>Select a week:</div>
        <div style={{display:"flex",flexWrap:"wrap",gap:"4px"}}>
          {weekPlans.map((p,i)=>(
            <button key={i} onClick={()=>setSelWk(i)}
              style={{width:"30px",height:"30px",borderRadius:"7px",border:`2px solid ${P.ink}`,background:i===selWk?P.byz:i===curWeek?"rgba(112,41,99,.15)":P.cream,color:i===selWk?P.cream:P.ink,fontWeight:i===selWk?700:400,fontSize:".75rem",cursor:"pointer"}}>
              {i+1}
            </button>
          ))}
        </div>
      </div>

      {/* Week detail */}
      <div className="bi cs" style={{borderRadius:"16px",padding:"16px",background:P.parch}}>
        <div style={{display:"flex",alignItems:"baseline",gap:"10px",marginBottom:"6px",flexWrap:"wrap"}}>
          <h2 className="df" style={{fontSize:"1.3rem",margin:0}}>Week {plan.week}</h2>
          {selWk===curWeek&&<span style={{background:P.byz,color:P.cream,borderRadius:"999px",padding:"2px 8px",fontSize:".72rem",fontWeight:700}}>← This week</span>}
        </div>

        {/* Saint of the week */}
        <div className="bi" style={{borderRadius:"12px",padding:"12px",background:P.cream,marginBottom:"12px"}}>
          <div style={{fontWeight:700,color:P.byz,marginBottom:"4px",display:"flex",alignItems:"center",gap:"6px",fontSize:".85rem"}}>
            🕯️ Saint of the Week: {plan.saint.n} — Feast: {plan.saint.f}
          </div>
          <p style={{margin:"0 0 6px",fontSize:".82rem",opacity:.85,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:3,WebkitBoxOrient:"vertical"}}>{plan.saint.life}</p>
          <div style={{fontStyle:"italic",color:P.byz,fontSize:".78rem",marginBottom:"6px"}}>{plan.saint.prayer}</div>
          <a href={plan.saint.res} target="_blank" rel="noopener noreferrer"
            style={{display:"inline-flex",alignItems:"center",gap:"4px",fontSize:".75rem",fontWeight:700,color:P.byz}}>
            <ExternalLink size={11}/> Read full life at OCA.org
          </a>
        </div>

        {/* Days */}
        <div style={{display:"flex",flexDirection:"column",gap:"10px"}}>
          {plan.days.map(day=>(
            <div key={day.day} style={{borderRadius:"10px",border:`2px solid ${P.ink}`,background:P.cream,overflow:"hidden"}}>
              <div style={{background:P.ink,color:P.cream,padding:"5px 10px",display:"flex",alignItems:"center",gap:"6px"}}>
                <span>{day.emoji}</span><span className="df" style={{fontSize:".9rem"}}>{day.day}</span>
              </div>
              <div style={{padding:"10px",display:"flex",flexDirection:"column",gap:"8px"}}>
                {day.pairs.map(({s,l},i)=>{
                  if(!s||!l) return null;
                  const isDone=child?.progress?.[l.id]?.done;
                  const isSaint=s.id==="saint";
                  return (
                    <div key={i} style={{borderRadius:"8px",border:`1.5px solid ${P.ink}`,background:isDone?"rgba(45,90,39,.1)":P.parch,padding:"9px 10px"}}>
                      <div style={{display:"flex",alignItems:"flex-start",gap:"8px",flexWrap:"wrap"}}>
                        <span style={{fontSize:"1rem"}}>{s.emoji}</span>
                        <div style={{flex:1,minWidth:0}}>
                          <div style={{fontSize:".65rem",fontWeight:700,textTransform:"uppercase",opacity:.55}}>{isSaint?"Saint of the Week":s.name}</div>
                          <div style={{fontWeight:700,fontSize:".88rem",margin:"2px 0"}}>{l.title}</div>
                          <p style={{margin:"0 0 6px",fontSize:".8rem",opacity:.8,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical"}}>{l.content}</p>
                          {/* Activity */}
                          {l.act&&<div style={{marginBottom:"6px",padding:"6px 8px",borderRadius:"6px",background:"rgba(0,0,0,.04)",fontSize:".78rem"}}>
                            <span style={{fontWeight:700}}>✋ Do this: </span>{l.act}
                          </div>}
                          {/* Fun fact */}
                          {l.ff&&<div style={{marginBottom:"6px",fontSize:".76rem",fontStyle:"italic",color:P.byz}}>💡 {l.ff}</div>}
                          <div style={{display:"flex",gap:"5px",flexWrap:"wrap",alignItems:"center"}}>
                            {l.vsearch&&(
                              <a href={`https://www.youtube.com/results?search_query=${encodeURIComponent(l.vsearch)}`} target="_blank" rel="noopener noreferrer"
                                style={{display:"inline-flex",alignItems:"center",gap:"3px",background:P.rose,color:P.cream,borderRadius:"7px",padding:"3px 8px",fontSize:".72rem",fontWeight:700,textDecoration:"none"}}>
                                <Play size={10}/> Watch
                              </a>
                            )}
                            {l.res&&(
                              <a href={l.res} target="_blank" rel="noopener noreferrer"
                                style={{display:"inline-flex",alignItems:"center",gap:"3px",background:P.sky,color:P.cream,borderRadius:"7px",padding:"3px 8px",fontSize:".72rem",fontWeight:700,textDecoration:"none"}}>
                                <BookMarked size={10}/> Resource
                              </a>
                            )}
                            {!isSaint&&s.id&&(
                              <button onClick={()=>onLesson(s.id,l.id)}
                                style={{background:s.color,color:P.cream,borderRadius:"7px",padding:"3px 8px",fontSize:".72rem",fontWeight:700,border:"none"}}>
                                Full lesson →
                              </button>
                            )}
                            {isSaint&&(
                              <button onClick={()=>onLesson("saint",l.id,l)}
                                style={{background:P.byz,color:P.cream,borderRadius:"7px",padding:"3px 8px",fontSize:".72rem",fontWeight:700,border:"none"}}>
                                Full saint story →
                              </button>
                            )}
                          </div>
                        </div>
                        {!isSaint&&child&&(
                          <button onClick={()=>onToggle(l.id)} style={{background:"none",border:"none",color:isDone?P.forest:P.ink,opacity:isDone?1:.25,flexShrink:0}}>
                            {isDone?<CheckCircle2 size={20}/>:<Circle size={20}/>}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── RESOURCES VIEW ─────────────────────────────────────────────────────────
function ResourcesView(){
  const [tab,setTab]=useState("saints");
  const TABS=[{k:"saints",l:"🕯️ Saints"},{k:"together",l:"🎧 Together"},{k:"books",l:"📖 Books"},{k:"links",l:"🔗 Links"},{k:"prayers",l:"☩ Prayers"}];

  const TOGETHER=[
    {cat:"☩ Orthodox Faith",col:P.byz,items:[
      {type:"podcast",emoji:"🎙️",t:"Ancient Faith Radio — Podcasts",a:"Various Orthodox speakers",
       note:"Hundreds of free podcasts on Orthodox theology, saints, family life and prayer. The Ancient Faith Parenting and Ancient Faith Today shows are excellent for family listening during meals or car trips.",
       link:"https://www.ancientfaith.com/podcasts",age:"All ages"},
      {type:"podcast",emoji:"🎙️",t:"Orthodoxy and the World (Pravmir)",a:"Pravmir.com",
       note:"Short readable articles and audio on Orthodox saints, feasts, and everyday Christian life. Great for reading aloud at dinner.",
       link:"https://www.pravmir.com",age:"Ages 8+"},
      {type:"video",emoji:"▶️",t:"Saddest Music in the World: Holy Week Hymns",a:"Various Orthodox Choirs (YouTube)",
       note:"Search YouTube for 'Orthodox Holy Week hymns' and listen to the Bridegroom Canon, the Lamentations, and the Paschal Canon as a family during Holy Week. The music teaches theology more deeply than any lesson.",
       link:"https://www.youtube.com/results?search_query=Orthodox+Holy+Week+hymns+Bridegroom+Canon",age:"All ages"},
      {type:"read",emoji:"📖",t:"Prolog of Ohrid: A Saint for Each Day",a:"St Nikolai Velimirovic",
       note:"One short saint's life plus a reflection and poem for every day of the year. Read the day's entry at breakfast or dinner. Free online. Even young children love the stories.",
       link:"https://www.westsrbdio.org/prolog/prolog.htm",age:"All ages"},
      {type:"video",emoji:"▶️",t:"Father Barnabas Powell: Faith Encouraged",a:"Ancient Faith Radio",
       note:"Short 5-minute daily video reflections on Orthodox Christian living. Warm, wise and practical for the whole family. Watch one together each morning.",
       link:"https://www.ancientfaith.com/podcasts/faithencouraged",age:"Ages 7+"},
      {type:"read",emoji:"📖",t:"My Life in Christ (excerpts)",a:"St John of Kronstadt",
       note:"Open to any page and read one paragraph aloud at dinner. St John wrote it as a journal — every entry is a compressed jewel of spiritual wisdom. Free online.",
       link:"https://www.orthodox.net/johlkron/my-life-in-christ.html",age:"Ages 10+"},
    ]},
    {cat:"🏛️ History",col:P.navy,items:[
      {type:"podcast",emoji:"🎙️",t:"Stuff You Missed in History Class",a:"iHeartRadio / How Stuff Works",
       note:"Two hosts explore overlooked, surprising and fascinating episodes from world history. Episodes are 20-30 minutes — perfect for lunch or a car trip. Hundreds of free episodes available.",
       link:"https://www.iheart.com/podcast/stuff-you-missed-in-history-class-21588042/",age:"Ages 9+"},
      {type:"podcast",emoji:"🎙️",t:"Brains On! Science and History for Kids",a:"American Public Media",
       note:"Award-winning podcast for children on science, history and big questions. Episodes run 20-30 minutes. A child co-hosts each episode. Over 200 episodes free.",
       link:"https://www.brainson.org",age:"Ages 6-12"},
      {type:"video",emoji:"▶️",t:"Overly Sarcastic Productions: History",a:"YouTube",
       note:"Witty, well-researched animated summaries of world history, mythology and literature. Episodes are 10-20 minutes. Suitable for ages 10+ with parents. Excellent for history supplements.",
       link:"https://www.youtube.com/results?search_query=Overly+Sarcastic+Productions+history",age:"Ages 10+"},
      {type:"podcast",emoji:"🎙️",t:"The British History Podcast",a:"Jamie Jeffers",
       note:"The most detailed narrative history of Britain from Roman times onward. Start at Series 1. Excellent for parents — summarise an episode at dinner and let it spark conversation.",
       link:"https://www.thebritishhistorypodcast.com",age:"Parents + 12+"},
      {type:"read",emoji:"📖",t:"A Child's History of the World",a:"V.M. Hillyer (1924)",
       note:"Written specifically for children — reads like a wonderful story from the first humans to the modern age. Free on Project Gutenberg. Read one chapter per week aloud at dinner.",
       link:"https://www.gutenberg.org/ebooks/63220",age:"Ages 7-12"},
      {type:"video",emoji:"▶️",t:"Horrible Histories (BBC)",a:"BBC / CBBC YouTube",
       note:"The best history TV ever made for children. Genuinely funny, historically accurate dramatisations of every era. Watch one episode together weekly. Available on YouTube.",
       link:"https://www.youtube.com/results?search_query=Horrible+Histories+BBC+full+episode",age:"Ages 7+"},
      {type:"read",emoji:"📖",t:"NZ History Online: This Week in NZ History",a:"NZ Ministry for Culture",
       note:"Each week, read about one significant event that happened in NZ history on that date. Roots your family's calendar in the land you live on.",
       link:"https://nzhistory.govt.nz/this-week-in-history",age:"All ages"},
    ]},
    {cat:"🌿 Nature & Science",col:P.forest,items:[
      {type:"podcast",emoji:"🎙️",t:"Short Wave: Science News for Everyone",a:"NPR",
       note:"Short (10-15 min) science news episodes covering biology, physics, space, climate and discovery. New episodes several times weekly. Perfect for breakfast listening.",
       link:"https://www.npr.org/podcasts/510351/short-wave",age:"Ages 10+"},
      {type:"podcast",emoji:"🎙️",t:"But Why: A Podcast for Curious Kids",a:"Vermont Public Radio",
       note:"Children send in their hardest questions about the natural world and a journalist finds the world's best experts to answer them. 'Why do we dream?' 'Why do leaves change colour?' 20-30 minutes each.",
       link:"https://www.npr.org/podcasts/474377890/but-why-a-podcast-for-curious-kids",age:"Ages 4-12"},
      {type:"video",emoji:"▶️",t:"SciShow Kids (YouTube)",a:"Complexly / SciShow",
       note:"Short 3-5 minute science videos covering every topic imaginable, presented clearly and engagingly for children. Over 400 free episodes. Watch one together each day during lunch.",
       link:"https://www.youtube.com/@SciShowKids",age:"Ages 5-10"},
      {type:"video",emoji:"▶️",t:"Sir David Attenborough Documentaries",a:"BBC / Netflix",
       note:"Planet Earth, Blue Planet, Our Planet — the greatest nature documentaries ever made. Watch one episode per week together. The beauty of creation on screen. God's handiwork made visible.",
       link:"https://www.youtube.com/results?search_query=David+Attenborough+nature+documentary+full",age:"All ages"},
      {type:"podcast",emoji:"🎙️",t:"Tumble Science Podcast for Kids",a:"Lindsay Patterson",
       note:"Stories about how scientific discoveries are actually made. Each episode follows a real scientist on their research journey. Shows children that science is adventurous and human.",
       link:"https://www.sciencepodcastforkids.com",age:"Ages 6-12"},
      {type:"read",emoji:"📖",t:"NatureWatch NZ: What's in Season",a:"NatureWatch NZ",
       note:"Each week, check what native species are active in your region and read about them together. Connects your family to the natural rhythms of Aotearoa.",
       link:"https://inaturalist.nz",age:"All ages"},
    ]},
    {cat:"💪 Health & Wellness",col:P.ochre,items:[
      {type:"podcast",emoji:"🎙️",t:"Zoe Science & Nutrition",a:"Prof Tim Spector, Dr Federica Amati",
       note:"The world's leading nutrition scientists explain in plain language how food affects health, mood, gut bacteria and children's development. Parents listen and summarise key ideas for the family.",
       link:"https://zoe.com/learn/category/podcast",age:"Parents"},
      {type:"video",emoji:"▶️",t:"Cosmic Kids Yoga (YouTube)",a:"Jamie from Cosmic Kids",
       note:"Story-based yoga and mindfulness sessions for children aged 3-10. Each episode tells a story through yoga poses. 15-20 minutes each. Perfect for morning movement or an afternoon reset.",
       link:"https://www.youtube.com/@CosmicKidsYoga",age:"Ages 3-10"},
      {type:"podcast",emoji:"🎙️",t:"Feel Better, Live More",a:"Dr Rangan Chatterjee",
       note:"Practical, evidence-based conversations on sleep, movement, nutrition and mental wellbeing. Episodes are 1-2 hours but are excellent on walks or drives. Parents listen and bring home insights.",
       link:"https://drchatterjee.com/podcast/",age:"Parents"},
      {type:"video",emoji:"▶️",t:"Khan Academy: Health and Medicine",a:"Khan Academy",
       note:"Free video series on the human body — digestive system, immune system, cardiovascular system, brain and nervous system. Watch the relevant video the week your curriculum covers that body system.",
       link:"https://www.khanacademy.org/science/health-and-medicine",age:"Ages 9+"},
      {type:"read",emoji:"📖",t:"The Orthodox Way of Fasting (articles)",a:"Ancient Faith Radio",
       note:"A short readable introduction to why and how Orthodox Christians fast, with practical guidance for families with young children. Read and discuss one section per month.",
       link:"https://www.ancientfaith.com/search?q=fasting+for+families",age:"Parents + 10+"},
      {type:"video",emoji:"▶️",t:"Go Noodle: Movement & Mindfulness",a:"Go Noodle",
       note:"Free 2-5 minute movement and mindfulness videos for young children. Singing, dancing, stretching and breathing exercises. Perfect for a brain break between lessons.",
       link:"https://www.gonoodle.com",age:"Ages 3-9"},
    ]},
    {cat:"📚 Read-Alouds & Stories",col:P.rose,items:[
      {type:"video",emoji:"▶️",t:"Storyline Online — Celebrity Read-Alouds",a:"SAG-AFTRA Foundation",
       note:"Award-winning actors read beautifully illustrated children's books aloud. Every book includes an activity guide. Completely free. Watch one together each week as a family movie night.",
       link:"https://www.storylineonline.net",age:"Ages 3-10"},
      {type:"podcast",emoji:"🎙️",t:"Stories Podcast — A Bedtime Show",a:"Starglow Media",
       note:"Original and classic children's stories read aloud in soothing voices. Perfect for bedtime. Over 400 free episodes. Fairy tales, fables, original adventures and myths from around the world.",
       link:"https://storiespodcast.com",age:"Ages 3-10"},
      {type:"podcast",emoji:"🎙️",t:"Book Club for Kids",a:"Kitty Felde",
       note:"Children discuss real books with authors and other young readers. Motivates children to read independently and think critically about what they read. Great for literature-focused families.",
       link:"https://bookclubforkids.org",age:"Ages 8-14"},
      {type:"video",emoji:"▶️",t:"The Rabbit Room: Tolkien & Lewis Readings",a:"Various Authors",
       note:"Read-alongs, discussions and explorations of The Chronicles of Narnia, The Lord of the Rings, and other works where faith and imagination meet. For older children and parents together.",
       link:"https://www.youtube.com/results?search_query=Narnia+read+aloud+CS+Lewis",age:"Ages 8+"},
      {type:"podcast",emoji:"🎙️",t:"Circle Round (WBUR)",a:"Rebecca Sheir / WBUR",
       note:"Folk tales and myths from around the world — including Maori, Greek and Slavic stories — retold as radio plays with full sound design. 20-30 minutes each. Exceptional quality.",
       link:"https://www.wbur.org/circleround",age:"Ages 4-10"},
      {type:"read",emoji:"📖",t:"Project Gutenberg: Read-Aloud Classics",a:"Various",
       note:"Treasure Island, Robin Hood, Just So Stories, The Wind in the Willows, Heidi, Black Beauty — all completely free. Read one chapter aloud at dinner or bedtime every night for a year.",
       link:"https://www.gutenberg.org/browse/scores/top",age:"Ages 7+"},
    ]},
    {cat:"🎵 Music & Language",col:P.byz,items:[
      {type:"video",emoji:"▶️",t:"Byzantine Chant for the Liturgical Year",a:"Various Orthodox Choirs",
       note:"Listen to a Byzantine chant recording as a family during the relevant liturgical season: Lenten chant during Great Lent, Paschal Canon after Pascha, Christmas troparion in December. Let the music teach the feasts.",
       link:"https://www.youtube.com/results?search_query=Byzantine+chant+playlist+liturgical+year",age:"All ages"},
      {type:"podcast",emoji:"🎙️",t:"Te Reo Maori Podcasts: He Kōrero Māori",a:"RNZ / Te Māngai Pāho",
       note:"Short news bulletins and conversations entirely in te reo Māori. Listen together — even children who know very little will begin to recognise words and rhythms. RNZ has free audio.",
       link:"https://www.rnz.co.nz/programmes/te-reo",age:"All ages"},
      {type:"video",emoji:"▶️",t:"Classical Music for Children (Naxos)",a:"Naxos / YouTube",
       note:"Play one piece of classical music during lunch each week. Start with Vivaldi's Four Seasons (connects to seasons lessons), then Beethoven, Mozart, Bach. Music builds attention span and emotional intelligence.",
       link:"https://www.youtube.com/results?search_query=classical+music+for+children+Vivaldi+Four+Seasons",age:"All ages"},
      {type:"video",emoji:"▶️",t:"Duolingo Greek (app + YouTube)",a:"Duolingo",
       note:"Free Greek language learning app and YouTube channel. Use alongside your Greek lessons. Even 5 minutes per day of Duolingo reinforces vocabulary. Set a family streak goal.",
       link:"https://www.duolingo.com/course/el/en/Learn-Greek",age:"Ages 7+"},
    ]},
  ];

  const BOOKS=[
    {t:"The Orthodox Faith (4 vols)",a:"Fr Thomas Hopko",note:"The best introduction to Orthodox Christianity for families. Free online at OCA.org.",link:"https://www.oca.org/orthodoxy/the-orthodox-faith"},
    {t:"The Sayings of the Desert Fathers",a:"Various (4th–5th cent)",note:"Short, piercing wisdom. Accessible for older children. Timeless.",link:"https://www.goodreads.com/book/show/255011"},
    {t:"The Way of a Pilgrim",a:"Anonymous Russian",note:"A peasant learns to pray the Jesus Prayer without ceasing. Beautifully readable.",link:"https://www.gutenberg.org"},
    {t:"Everyday Saints",a:"Archimandrite Tikhon Shevkunov",note:"Modern Russian stories of faith and miracles. Bestseller across the Orthodox world."},
    {t:"The Chronicles of Narnia",a:"C.S. Lewis",note:"Lewis clothed Christian truth in story. A child who loves Aslan is prepared to love Christ."},
    {t:"The Hobbit & The Lord of the Rings",a:"J.R.R. Tolkien",note:"Tolkien was a devout Catholic. His works are saturated with Christian themes of sacrifice, grace and resurrection."},
    {t:"Little Britches",a:"Ralph Moody",note:"One of the best books ever written about character, work and a father's love."},
    {t:"Anne of Green Gables",a:"L.M. Montgomery",note:"Free on Project Gutenberg. Anne finds home and belonging. Beautiful writing.",link:"https://www.gutenberg.org/ebooks/45"},
    {t:"Swiss Family Robinson",a:"Johann Wyss",note:"Free on Gutenberg. Every practical survival and building skill imaginable.",link:"https://www.gutenberg.org/ebooks/11707"},
    {t:"Charlotte's Web",a:"E.B. White",note:"Friendship, sacrifice and the cycles of life. A timeless classic for all ages."},
  ];

  const LINKS=[
    {c:"Orthodox Faith",items:[
      {t:"OCA.org — Orthodox Church in America",l:"https://www.oca.org",n:"Lives of saints, Orthodox Faith series, feast days — all free."},
      {t:"Bible Gateway (Orthodox Study Bible)",l:"https://www.biblegateway.com",n:"Free online Bible in multiple translations including NKJV."},
      {t:"Project Gutenberg — Free Classic Books",l:"https://www.gutenberg.org",n:"Thousands of classic books free online: Fathers, literature, science."},
      {t:"LibriVox — Free Audiobooks",l:"https://www.librivox.org",n:"Free audio recordings of public domain books. Great for car trips."},
    ]},
    {c:"Education Resources",items:[
      {t:"Khan Academy NZ (free maths & science)",l:"https://www.nz.khanacademy.org",n:"World-class free maths instruction from basic counting to calculus."},
      {t:"Numberblocks (BBC, free on YouTube)",l:"https://www.youtube.com/results?search_query=Numberblocks+full+episode",n:"Best early maths resource for ages 4–7."},
      {t:"Alphablocks (BBC, free on YouTube)",l:"https://www.youtube.com/results?search_query=Alphablocks+full+episode",n:"Best early phonics resource for ages 4–7."},
      {t:"Storyline Online — Free Read-Alouds",l:"https://www.storylineonline.net",n:"Actors reading children's picture books aloud. Beautiful for all ages."},
      {t:"NZ History Online",l:"https://nzhistory.govt.nz",n:"Comprehensive NZ and Māori history for all levels, free."},
    ]},
    {c:"NZ & Māori",items:[
      {t:"Te Ara — Encyclopedia of New Zealand",l:"https://www.teara.govt.nz",n:"Comprehensive NZ history, Māori history, and natural world."},
      {t:"Māori Television",l:"https://www.maoritelevision.com",n:"Te reo Māori content including language learning resources."},
      {t:"DOC — Predator Free NZ 2050",l:"https://www.doc.govt.nz/predator-free-2050",n:"NZ conservation resources and how to help."},
    ]},
  ];

  const PRAYERS=[
    {n:"Morning Prayer (short)",t:"O Lord, grant me to pass this day in peace. Preserve me from all evil. Guide me to do Thy holy will. Through the intercessions of the Theotokos, have mercy on me. Amen."},
    {n:"Meal Blessing",t:"O Christ our God, bless the food and drink of Thy servants, for Thou art holy always, now and ever and unto ages of ages. Amen. ✦ Give bread to those who hunger, and hunger for righteousness to those who have bread."},
    {n:"Evening Prayer (short)",t:"O Lord my God, if in this day I have sinned in word, deed or thought, forgive me all, for Thou art good and lovest mankind. Grant me peaceful and sinless sleep. Amen."},
    {n:"The Jesus Prayer",t:"Lord Jesus Christ, Son of God, have mercy on me, a sinner."},
    {n:"Paschal Troparion",t:"Christ is risen from the dead, trampling down death by death, and upon those in the tombs bestowing life! (×3) ✦ Χριστὸς Ἀνέστη ἐκ νεκρῶν, θανάτῳ θάνατον πατήσας, καὶ τοῖς ἐν τοῖς μνήμασι ζωὴν χαρισάμενος!"},
    {n:"Theotokion",t:"It is truly meet to bless thee, O Theotokos, ever-blessed and most pure, and the Mother of our God. More honourable than the Cherubim, and beyond compare more glorious than the Seraphim, who without corruption didst bear God the Word — the very Theotokos: thee do we magnify."},
    {n:"Before Study",t:"O Heavenly King, Comforter, Spirit of Truth, Who art everywhere present and fillest all things, Treasury of good things and Giver of life: come and dwell in us, cleanse us from all impurity, and save our souls, O Good One. Amen."},
    {n:"Nicene Creed (opening)",t:"I believe in one God, the Father Almighty, Maker of heaven and earth, and of all things visible and invisible. And in one Lord Jesus Christ, the Son of God, the Only-begotten, begotten of the Father before all ages..."},
    {n:"Glory to God for All Things (St John Chrysostom)",t:"Glory to God for all things. Always. In all circumstances. For all things. Amen."},
  ];

  return (
    <div style={{display:"flex",flexDirection:"column",gap:"18px"}}>
      <div className="bi cs" style={{borderRadius:"16px",padding:"16px 20px",background:P.byz,color:P.cream}}>
        <h1 className="df" style={{fontSize:"1.6rem",margin:"0 0 2px"}}>📖 Resources</h1>
        <p className="sf" style={{fontSize:"1rem",margin:0,opacity:.9}}>Saints · Books · Links · Prayers</p>
      </div>

      <div style={{display:"flex",gap:"5px",flexWrap:"wrap"}}>
        {TABS.map(t=>(
          <button key={t.k} onClick={()=>setTab(t.k)}
            style={{padding:"6px 12px",borderRadius:"8px",border:`2px solid ${P.ink}`,background:tab===t.k?P.ink:P.cream,color:tab===t.k?P.cream:P.ink,fontWeight:700,fontSize:".82rem",cursor:"pointer"}}>
            {t.l}
          </button>
        ))}
      </div>

      {tab==="together"&&(
        <div style={{display:"flex",flexDirection:"column",gap:"18px"}}>
          <p style={{margin:0,fontSize:".85rem",opacity:.75,lineHeight:1.6}}>
            Curated daily family listening, reading and watching — Orthodox, history, nature, health and stories. Pick one from any category each day.
          </p>
          {TOGETHER.map(cat=>(
            <div key={cat.cat}>
              <div className="df" style={{fontSize:"1rem",color:cat.col,marginBottom:"8px",fontWeight:700}}>{cat.cat}</div>
              <div style={{display:"flex",flexDirection:"column",gap:"8px"}}>
                {cat.items.map(item=>(
                  <div key={item.t} className="bi" style={{borderRadius:"12px",padding:"12px",background:P.cream,borderLeft:`4px solid ${cat.col}`}}>
                    <div style={{display:"flex",alignItems:"flex-start",gap:"8px"}}>
                      <span style={{fontSize:"1.1rem",flexShrink:0,marginTop:"1px"}}>{item.emoji}</span>
                      <div style={{flex:1}}>
                        <div style={{display:"flex",alignItems:"center",gap:"6px",flexWrap:"wrap",marginBottom:"2px"}}>
                          <span style={{fontWeight:700,fontSize:".87rem"}}>{item.t}</span>
                          <span style={{fontSize:".68rem",background:cat.col,color:P.cream,borderRadius:"999px",padding:"1px 6px",fontWeight:700,flexShrink:0}}>{item.type}</span>
                          <span style={{fontSize:".68rem",opacity:.6,fontStyle:"italic"}}>{item.age}</span>
                        </div>
                        <div style={{fontSize:".75rem",opacity:.55,marginBottom:"5px"}}>— {item.a}</div>
                        <div style={{fontSize:".8rem",lineHeight:1.6,opacity:.85,marginBottom:"6px"}}>{item.note}</div>
                        {item.link&&<a href={item.link} target="_blank" rel="noopener noreferrer"
                          style={{display:"inline-flex",alignItems:"center",gap:"3px",fontSize:".74rem",fontWeight:700,color:cat.col,textDecoration:"none"}}>
                          <ExternalLink size={10}/> Open
                        </a>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {tab==="saints"&&(
        <div style={{display:"flex",flexDirection:"column",gap:"10px"}}>
          {SAINTS.map(s=>(
            <div key={s.m} className="bi cs" style={{borderRadius:"14px",padding:"14px",background:P.cream}}>
              <div style={{display:"flex",alignItems:"baseline",gap:"8px",flexWrap:"wrap",marginBottom:"6px"}}>
                <div className="df" style={{fontSize:"1rem"}}>{s.n}</div>
                <span style={{fontSize:".72rem",background:P.byz,color:P.cream,borderRadius:"999px",padding:"2px 7px",fontWeight:700}}>{s.m} · {s.f}</span>
              </div>
              <p style={{margin:"0 0 8px",fontSize:".82rem",opacity:.85,lineHeight:1.6}}>{s.life}</p>
              <div style={{background:P.parch,borderRadius:"8px",padding:"8px",marginBottom:"8px"}}>
                <div style={{fontWeight:700,fontSize:".76rem",color:P.byz,marginBottom:"3px"}}>☩ This week's lesson:</div>
                <p style={{margin:"0 0 4px",fontSize:".78rem"}}>{s.lesson}</p>
                <div style={{fontStyle:"italic",fontSize:".75rem",color:P.byz}}>{s.prayer}</div>
              </div>
              <a href={s.res} target="_blank" rel="noopener noreferrer"
                style={{display:"inline-flex",alignItems:"center",gap:"4px",fontSize:".75rem",fontWeight:700,color:P.byz}}>
                <ExternalLink size={11}/> Full life at OCA.org
              </a>
            </div>
          ))}
        </div>
      )}

      {tab==="books"&&(
        <div style={{display:"flex",flexDirection:"column",gap:"8px"}}>
          {BOOKS.map(b=>(
            <div key={b.t} className="bi" style={{borderRadius:"12px",padding:"12px",background:P.cream}}>
              <div style={{fontWeight:700,marginBottom:"2px"}}>{b.t}</div>
              <div style={{fontSize:".74rem",opacity:.55,marginBottom:"4px"}}>— {b.a}</div>
              <div style={{fontSize:".8rem",opacity:.8}}>{b.note}</div>
              {b.link&&<a href={b.link} target="_blank" rel="noopener noreferrer"
                style={{display:"inline-flex",alignItems:"center",gap:"3px",fontSize:".74rem",fontWeight:700,color:P.sky,marginTop:"4px"}}>
                <ExternalLink size={10}/> Open free online
              </a>}
            </div>
          ))}
        </div>
      )}

      {tab==="links"&&(
        <div style={{display:"flex",flexDirection:"column",gap:"14px"}}>
          {LINKS.map(cat=>(
            <div key={cat.c}>
              <h3 className="df" style={{fontSize:"1rem",marginBottom:"6px"}}>{cat.c}</h3>
              <div style={{display:"flex",flexDirection:"column",gap:"6px"}}>
                {cat.items.map(l=>(
                  <a key={l.t} href={l.l} target="_blank" rel="noopener noreferrer"
                    className="bi lf" style={{borderRadius:"10px",padding:"10px",background:P.cream,display:"flex",alignItems:"flex-start",gap:"8px",textDecoration:"none",color:P.ink}}>
                    <ExternalLink size={16} style={{color:P.sky,flexShrink:0,marginTop:"2px"}}/>
                    <div>
                      <div style={{fontWeight:700,fontSize:".85rem",marginBottom:"2px"}}>{l.t}</div>
                      <div style={{fontSize:".78rem",opacity:.7}}>{l.n}</div>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {tab==="prayers"&&(
        <div style={{display:"flex",flexDirection:"column",gap:"8px"}}>
          {PRAYERS.map(p=>(
            <div key={p.n} className="bi cs" style={{borderRadius:"12px",padding:"12px 14px",background:P.parch}}>
              <div className="df" style={{fontSize:".95rem",color:P.byz,marginBottom:"6px"}}>☩ {p.n}</div>
              <p style={{margin:0,fontSize:".85rem",lineHeight:1.7,fontStyle:"italic"}}>{p.t}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── ALL LESSONS VIEW ────────────────────────────────────────────────────────
function AllLessonsView({child,subjects,onSubject}){
  const SL = subjects || SUBJECTS;
  return (
    <div style={{display:"flex",flexDirection:"column",gap:"18px"}}>
      <div className="bi cs" style={{borderRadius:"16px",padding:"16px 20px",background:P.rose,color:P.cream}}>
        <h1 className="df" style={{fontSize:"1.6rem",margin:"0 0 2px"}}>📚 All Lessons</h1>
        <p className="sf" style={{fontSize:"1rem",margin:0,opacity:.9}}>browse and explore every subject</p>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(185px,1fr))",gap:"8px"}}>
        {SL.map(s=>{
          const sd=s.lessons.filter(l=>child?.progress?.[l.id]?.done).length;
          const pct=(sd/s.lessons.length)*100;
          return (
            <button key={s.id} onClick={()=>onSubject(s.id)} className="bi cs lf"
              style={{borderRadius:"16px",padding:"14px",background:s.color,color:P.cream,textAlign:"left",display:"flex",flexDirection:"column",gap:"6px",border:""}}>
              <div style={{fontSize:"1.8rem"}}>{s.emoji}</div>
              <div className="df" style={{fontSize:".95rem",lineHeight:1.2}}>{s.name}</div>
              <div style={{fontSize:".72rem",opacity:.85,flex:1}}>{s.tagline}</div>
              <div>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:"3px",fontSize:".68rem",fontWeight:700,opacity:.9}}>
                  <span>{sd}/{s.lessons.length}</span><span>{Math.round(pct)}%</span>
                </div>
                <div style={{height:"4px",borderRadius:"999px",background:"rgba(255,255,255,.25)",overflow:"hidden"}}>
                  <div style={{height:"100%",background:P.cream,width:`${pct}%`}}/>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─── SUBJECT VIEW ────────────────────────────────────────────────────────────
function SubjectView({subj,child,onBack,onLesson}){
  if(!subj) return null;
  const done=subj.lessons.filter(l=>child.progress?.[l.id]?.done).length;
  return (
    <div style={{display:"flex",flexDirection:"column",gap:"14px"}}>
      <button onClick={onBack} style={{display:"flex",alignItems:"center",gap:"5px",fontWeight:700,background:"none",border:"none",padding:0,fontSize:".9rem"}}>
        <ChevronLeft size={18}/> Back to All Lessons
      </button>
      <div className="bi cs" style={{borderRadius:"18px",padding:"18px",background:subj.color,color:P.cream}}>
        <div style={{display:"flex",alignItems:"center",gap:"12px",flexWrap:"wrap"}}>
          <div style={{fontSize:"2.8rem"}}>{subj.emoji}</div>
          <div>
            <h1 className="df" style={{fontSize:"1.7rem",margin:"0 0 4px"}}>{subj.name}</h1>
            <p className="sf" style={{fontSize:"1rem",margin:0,opacity:.9}}>{subj.tagline}</p>
          </div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:"10px",marginTop:"12px"}}>
          <div style={{flex:1,height:"8px",borderRadius:"999px",background:"rgba(255,255,255,.25)",overflow:"hidden"}}>
            <div style={{height:"100%",background:P.cream,width:`${(done/subj.lessons.length)*100}%`}}/>
          </div>
          <span style={{fontWeight:700,whiteSpace:"nowrap",fontSize:".85rem"}}>{done}/{subj.lessons.length}</span>
        </div>
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:"7px"}}>
        {subj.lessons.map((l,i)=>{
          const isDone=child.progress?.[l.id]?.done;
          return (
            <button key={l.id} onClick={()=>onLesson(l.id)} className="bi cs lf"
              style={{borderRadius:"12px",padding:"11px 13px",background:isDone?P.parch:P.cream,display:"flex",alignItems:"flex-start",gap:"10px",textAlign:"left",border:""}}>
              <div style={{width:"32px",height:"32px",borderRadius:"50%",background:isDone?P.forest:P.cream,color:isDone?P.cream:P.ink,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,border:`2px solid ${P.ink}`,flexShrink:0,fontSize:isDone?undefined:".8rem"}}>
                {isDone?<CheckCircle2 size={16}/>:i+1}
              </div>
              <div style={{flex:1,minWidth:0}}>
                <div className="df" style={{fontSize:".95rem",lineHeight:1.2}}>{l.title}</div>
                <div style={{fontSize:".7rem",opacity:.55,display:"flex",gap:"10px",marginTop:"3px",flexWrap:"wrap"}}>
                  <span>⏱ {l.dur}</span><span>Ages {l.age}</span>
                </div>
                <p style={{margin:"4px 0 0",fontSize:".8rem",opacity:.7,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical"}}>{l.content}</p>
              </div>
              <ChevronRight size={15} style={{flexShrink:0,marginTop:"4px",opacity:.4}}/>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─── LESSON VIEW ─────────────────────────────────────────────────────────────
function LessonView({subj,lesson,child,backLabel,onBack,onToggle}){
  if(!lesson||!subj) return null;
  const isDone=child.progress?.[lesson.id]?.done;
  const ytUrl=lesson.vsearch?`https://www.youtube.com/results?search_query=${encodeURIComponent(lesson.vsearch)}`:null;
  return (
    <div style={{display:"flex",flexDirection:"column",gap:"12px"}}>
      <button onClick={onBack} style={{display:"flex",alignItems:"center",gap:"5px",fontWeight:700,background:"none",border:"none",padding:0,fontSize:".9rem"}}>
        <ChevronLeft size={18}/> Back to {backLabel || subj.name}
      </button>
      <div className="bi cs" style={{borderRadius:"18px",padding:"18px",background:subj.color,color:P.cream}}>
        <div style={{fontSize:".68rem",fontWeight:700,textTransform:"uppercase",letterSpacing:".06em",opacity:.9,marginBottom:"4px"}}>{subj.emoji} {subj.name}</div>
        <h1 className="df" style={{fontSize:"1.5rem",margin:"0 0 10px",lineHeight:1.2}}>{lesson.title}</h1>
        <div style={{display:"flex",gap:"6px",flexWrap:"wrap"}}>
          {[["⏱",lesson.dur],["👤","Ages "+lesson.age]].map(([e,l])=>(
            <span key={l} style={{background:P.cream,color:P.ink,borderRadius:"999px",padding:"3px 9px",fontSize:".76rem",fontWeight:600,border:`2px solid ${P.ink}`}}>{e} {l}</span>
          ))}
        </div>
      </div>

      {/* Content card */}
      {[
        {t:"What we're learning",e:"🌟",c:P.navy,  body:lesson.content},
        ytUrl&&{t:"Watch & learn",   e:"🎬",c:P.rose,  body:null, vid:true},
        lesson.act&&{t:"Try this activity", e:"✋",c:P.forest, body:lesson.act},
        lesson.ff&&{t:"Fun fact / Prayer",  e:"💡",c:P.gold,   body:lesson.ff},
      ].filter(Boolean).map(card=>(
        <div key={card.t} className="bi cs" style={{borderRadius:"14px",padding:"14px",background:P.cream}}>
          <div style={{display:"flex",alignItems:"center",gap:"8px",marginBottom:"10px"}}>
            <div style={{width:"32px",height:"32px",borderRadius:"50%",background:card.c,color:P.cream,display:"flex",alignItems:"center",justifyContent:"center",fontSize:".9rem",border:`2px solid ${P.ink}`,flexShrink:0}}>
              {card.e}
            </div>
            <h3 className="df" style={{fontSize:"1rem",margin:0}}>{card.t}</h3>
          </div>
          {card.vid?(
            <div style={{display:"flex",alignItems:"center",gap:"10px",background:P.parch,borderRadius:"10px",padding:"10px",flexWrap:"wrap"}}>
              <div style={{width:"40px",height:"40px",borderRadius:"10px",background:P.rose,color:P.cream,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,border:`2px solid ${P.ink}`}}>
                <Play size={18}/>
              </div>
              <div style={{flex:1}}>
                <div style={{fontWeight:700,fontSize:".85rem"}}>{lesson.vsearch}</div>
                <div style={{fontSize:".72rem",opacity:.6}}>Free on YouTube — click to search</div>
              </div>
              <a href={ytUrl} target="_blank" rel="noopener noreferrer" className="bi css lf"
                style={{background:P.ochre,color:P.ink,borderRadius:"10px",padding:"7px 14px",fontWeight:700,textDecoration:"none",fontSize:".82rem",flexShrink:0}}>
                Open
              </a>
            </div>
          ):(
            <p style={{margin:0,fontSize:".88rem",lineHeight:1.7,fontStyle:card.e==="💡"?"italic":"normal"}}>{card.body}</p>
          )}
          {card.res&&(
            <a href={card.res} target="_blank" rel="noopener noreferrer"
              style={{display:"inline-flex",alignItems:"center",gap:"4px",fontSize:".75rem",fontWeight:700,color:P.sky,marginTop:"8px"}}>
              <ExternalLink size={11}/> Resource link
            </a>
          )}
        </div>
      ))}

      {/* Complete button */}
      <div style={{position:"sticky",bottom:"12px",zIndex:10}}>
        <button onClick={()=>onToggle(lesson.id)} className="bi cs lf"
          style={{width:"100%",padding:"14px",borderRadius:"16px",fontWeight:700,fontSize:"1rem",display:"flex",alignItems:"center",justifyContent:"center",gap:"8px",background:isDone?P.forest:P.ochre,color:isDone?P.cream:P.ink,border:""}}>
          {isDone?<CheckCircle2 size={22}/>:<Circle size={22}/>}
          {isDone?"Completed — Glory to God!":"Mark as complete"}
        </button>
      </div>
    </div>
  );
}

// ─── PROFILE MODAL ───────────────────────────────────────────────────────────
function ProfileModal({existing,all,onClose,onSave,onDelete}){
  const [name,setName]=useState(existing?.name||"");
  const [age,setAge]=useState(existing?.age||6);
  const [color,setColor]=useState(existing?.color||P.byz);
  const colors=[P.byz,P.ochre,P.forest,P.navy,P.rose,P.sky,P.terra,P.sage];
  const canClose=existing||all.length>0;
  return (
    <div style={{position:"fixed",inset:0,zIndex:50,display:"flex",alignItems:"center",justifyContent:"center",padding:"16px",background:"rgba(28,9,28,.6)"}}>
      <div className="bi cs" style={{width:"100%",maxWidth:"400px",borderRadius:"20px",padding:"22px",background:P.cream}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"14px"}}>
          <h2 className="df" style={{fontSize:"1.5rem",margin:0}}>{existing?"Edit Profile":"Welcome!"}</h2>
          {canClose&&<button onClick={onClose} style={{background:"none",border:"none",cursor:"pointer",padding:"4px",borderRadius:"50%"}}><X size={18}/></button>}
        </div>
        {!existing&&<p style={{margin:"0 0 14px",opacity:.7,fontSize:".85rem"}}>Set up a learning profile for your child. You can add more children later.</p>}
        <label style={{display:"block",marginBottom:"10px"}}>
          <span style={{fontSize:".82rem",fontWeight:700,display:"block",marginBottom:"4px"}}>Child's name</span>
          <input value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Tama"
            style={{width:"100%",padding:"9px 12px",borderRadius:"10px",border:`2.5px solid ${P.ink}`,background:P.parch,fontFamily:"inherit",fontSize:"1rem"}} autoFocus/>
        </label>
        <label style={{display:"block",marginBottom:"10px"}}>
          <span style={{fontSize:".82rem",fontWeight:700,display:"block",marginBottom:"4px"}}>Age</span>
          <input type="number" min="3" max="14" value={age} onChange={e=>setAge(e.target.value)}
            style={{width:"100%",padding:"9px 12px",borderRadius:"10px",border:`2.5px solid ${P.ink}`,background:P.parch,fontFamily:"inherit",fontSize:"1rem"}}/>
        </label>
        <div style={{marginBottom:"18px"}}>
          <span style={{fontSize:".82rem",fontWeight:700,display:"block",marginBottom:"7px"}}>Choose a colour</span>
          <div style={{display:"flex",gap:"7px",flexWrap:"wrap"}}>
            {colors.map(c=>(
              <button key={c} onClick={()=>setColor(c)}
                style={{width:"34px",height:"34px",borderRadius:"50%",background:c,border:`3px solid ${color===c?P.ink:"transparent"}`,cursor:"pointer",outline:color===c?`2px solid ${P.cream}`:"none",outlineOffset:"2px"}}/>
            ))}
          </div>
        </div>
        <div style={{display:"flex",gap:"7px"}}>
          <button disabled={!name.trim()} onClick={()=>onSave(name.trim(),age,color)} className="bi cs lf"
            style={{flex:1,padding:"11px",borderRadius:"12px",fontWeight:700,fontSize:".95rem",background:P.forest,color:P.cream,border:"",cursor:name.trim()?"pointer":"not-allowed",opacity:name.trim()?1:.4}}>
            {existing?"Save changes":"Begin learning"}
          </button>
          {existing&&all.length>1&&(
            <button onClick={()=>{if(window.confirm(`Remove ${existing.name}? All progress will be lost.`))onDelete(existing.id);}}
              className="bi css lf"
              style={{padding:"11px",borderRadius:"12px",background:P.rose,color:P.cream,border:"",cursor:"pointer"}}>
              <Trash2 size={16}/>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
